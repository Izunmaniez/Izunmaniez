<?= $this-> extend('administrator/template/index'); ?>


<?= $this-> section('content'); ?>



          <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Blog Editor</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item active">last updated</li>
              <li class="breadcrumb-item"><a href="#"><?= date('d M Y'); ?></a></li>            
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

<?php if(session()->getFlashdata('pesan')) : ?>

<div class="alert alert-success" role="alert">

<?= session()->getFlashdata('pesan');?>

</div>
  
<?php endif; ?>

<form action="/administrator/update_blog/<?= $blogs['id']; ?>" method="post" enctype="multipart/form-data">

<?= csrf_field(); ?>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="card card-outline card-info">
            <div class="card-header">
              <div class="card-title">
                Judul :
                <input type="text" class="form-control"  id="judul" name="judul"  value="<?= $blogs['judul']; ?>"  autofocus>
              </div>
              <div class="card-title">
                Blogger :
          <input type="text" class="form-control"  id="blogger" name="blogger"  value="<?= $blogs['blogger']; ?>" >
              </div>
              
              <div class="card-tools">
                <button type="button" class="btn btn-tool btn-sm" data-card-widget="collapse" data-toggle="tooltip"
                        title="Collapse">
                  <i class="fas fa-minus"></i></button>
                <button type="button" class="btn btn-tool btn-sm" data-card-widget="remove" data-toggle="tooltip"
                        title="Remove">
                  <i class="fas fa-times"></i></button>
              </div><!-- /. tools -->                                                
            </div> <!-- /.card-header -->          
            
            <div class="card-body pad">
              <div class="mb-3">               
                <textarea class="textarea" id="isi_blog" name="isi_blog" value="<?= $blogs['isi_blog']; ?>">                                                                           
                </textarea>               
              </div>             
              <a href="/administrator/list_blog" class="btn btn-secondary btn-md float-right mr-1">Back</a>                               
              <button class="btn btn-primary" type="submit" name="submit">
                Submit           
              </button>                   
            </div><!-- /.card-body pad-->
            
          </div><!-- /.card-outline-->
        </div><!-- /.col-->
      </div><!-- ./row -->     
    </section>
    <!-- /.content -->
  </div>    
  
  </form>
  

<?= $this-> endSection(); ?>
  
     