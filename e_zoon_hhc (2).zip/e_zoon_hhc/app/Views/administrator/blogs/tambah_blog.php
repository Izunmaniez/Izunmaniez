<?= $this-> extend('administrator/template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this-> include('administrator/template/topbar'); ?>

<?= $this-> include('administrator/template/sidebar'); ?>


          <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Blog Editors</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item active">last updated</li>
              <li class="breadcrumb-item"><a href="#"><?= date('d M Y'); ?></a></li>            
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

<?php if(session()->getFlashdata('pesan')) : ?>

<div class="alert alert-success" role="alert">

<?= session()->getFlashdata('pesan');?>

</div>
  
<?php endif; ?>
 
  <form action="/administrator/save_blog" method="post" enctype="multipart/form-data" >

<?= csrf_field(); ?> 

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="card card-outline card-info">
            <div class="card-header">
              <div class="card-title mr-5">
                Judul :
                <input type="text" class="form-control"  id="judul" name="judul" autofocus>
              </div>
              
              <div class="card-title">
                Blogger :
                <input type="text" class="form-control"  id="blogger" name="blogger">
              </div>
                         
              
            </div>
            <!-- /.card-header -->
            <div class="card-body pad">
            <b>Konten Blog</b>
              <div class="mb-3">
              
                <textarea class="textarea" id="isi_blog" name="isi_blog"  placeholder="Place some text here"
                          style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;">
                         
                </textarea>
                
              </div>
              <a href="/administrator/list_blog" class="btn btn-secondary btn-md float-right mr-1">Back</a>
                    
              <button class="btn btn-primary" type="submit" name="submit">
                Submit           
              </button>
  </form>            
       
            </div>
          </div>
        </div>
        <!-- /.col-->
      </div>
      <!-- ./row -->
      
    </section>
    <!-- /.content -->
  </div>    

<?= $this-> endSection(); ?>
  
     