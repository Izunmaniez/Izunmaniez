<?= $this-> extend('administrator/template/index'); ?>

<?= $this-> section('content'); ?>

           
<div class="modal-content">
   <div class="modal-header">
      <h4 class="modal-title">Detail Member</h4>              
   </div>
      <div class="modal-body">           
         <!-- Profile Image -->
         <div class="card card-info card-outline">
            <div class="card-body box-profile">
               <div class="text-center">                                
                  <img class="profile-user-img img-fluid img-circle bg-info"
                  <img src="<?= base_url('foto_profile/' .$user->foto); ?>" alt="User profile picture">
               </div>
               <center>
                <?php if ($user->fullname) : ?>
                <h3 class="profile-username text-center"><?= $user->fullname; ?></b></h3>
                <?php endif; ?>
                
               <small>Member since <?= $user->created_at; ?></small>
               <h6 class="widget-user-desc">Stage : 
               <span class="badge badge-info">FM</span></h6>
              </center>
                <ul class="list-group list-group-unbordered mb-3">
                  <li class="list-group-item">
                  <i class="fas fa-user text-info mr-1"></i>
                    <b>Username</b> <a class="float-right"><?= $user->username; ?></b></a>
                  </li>                  
                  <li class="list-group-item">
                    <i class="fas fa-mobile-alt text-info mr-1"></i>
                    <b>Telepon</b>  
                    <?php if ($user->telp) : ?>                                  
                    <a class="float-right"><?= $user->telp; ?></b></a>  
                    <?php endif; ?>            
                  </li>                 
                  <li class="list-group-item">
                  <i class="fas fa-envelope-open-text text-info mr-1"></i>
                    <b>Email</b> <a class="float-right"><?= $user->email; ?></b></a>
                  </li>                                
                </ul>
              </div><!-- /.card-body -->            
            </div><!-- /.card -->
                      
            <!-- About Me Box -->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">More Detile</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <strong><i class="fas fa-user text-info mr-1"></i>Gender</strong>
                <?php if ($user->jenkel) : ?>   
                <a class="float-right">
                <?= $user->jenkel; ?></a>
                <?php endif; ?>
                <hr>
                <strong><i class="fas fa-map-marker-alt text-info mr-1"></i>Alamat</strong>
                <?php if ($user->alamat) : ?>   
                <a class="float-right"><?= $user->alamat; ?></a>
                <?php endif; ?>               
               </div>             
            </div><!-- /.card-info-->
                       
            <!-- Bank Account -->
            <div class="card card-info">
               <div class="card-header">
                  <i class="fas fa-money-check-alt text-info mr-1"></i>
                  <h3 class="card-title">Bank Account</h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                <strong><i class="fas fa-sort-numeric-up text-info mr-1"></i>Nomor Rekening</strong>
                <?php if ($user->norek) : ?> 
                <a class="float-right">
                <?= $user->norek; ?></a>
                <?php endif; ?>
                <hr>
                <strong><i class="fas fa-user text-info mr-1"></i> Pemilik Rekening</strong>
                <?php if ($user->an) : ?>
                <a class="float-right"><?= $user->an; ?></a>
                <?php endif; ?>
                <hr>
                <strong><i class="fas fa-university text-info mr-1"></i> Nama Bank</strong>
                 <?php if ($user->norek) : ?>
                <a class="float-right">
                <?= $user->mabank; ?></a>               
                <?php endif; ?>
               </div><!-- /.card-body -->            
            </div><!-- /.card-info-->
                        
    <!-- Inviter Data -->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Data Sponsor</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <strong><i class="fas fa-user text-info mr-1"></i>Nama Sponsor</strong>
                <?php if ($user->sponsor) : ?>
                <a class="float-right">
                <?= $user->sponsor; ?></a>
                <?php endif; ?>
                
               </div><!-- /.card-body -->            
            </div><!-- /.card-info-->
                       
            <center> 
               <a class="btn btn-info mb-3" href="/administrator/list_member"><b>Udah..?</b></a>
            </center>
            
   </div><!-- /.modal-body -->
</div><!-- /.modal-content -->
          
      

<?= $this-> endSection(); ?>

