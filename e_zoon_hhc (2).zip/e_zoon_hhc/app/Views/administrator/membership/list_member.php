<?= $this-> extend('administrator/template/index'); ?>


<?= $this-> section('content'); ?>
<?= $this-> include('administrator/template/topbar'); ?>
<?= $this-> include('administrator/template/sidebar'); ?>


 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
  <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">       
        <div class="row mb-2">
        <?= $this-> include('administrator/template/time'); ?>
          <div class="col-sm-6">
            <h1>DATA MEMBER</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
           <div class="card">
              <div class="card-body" style="overflow:auto;">
                <table id="example1" class="table table-bordered table-stripped">
                  <thead class="table-primary">
                  <tr>
                    <th>#</th>
                    <th>Nama_Lengkap</th>  
                    <th>Telepon</th>       
                    <th>Peringkat</th>  
                    <th>Sponsor</th>  
                    <th>Toko</th>
                    <th>Detail</th>
                   
                  </tr>
                  </thead>
                  <tbody>
 
 
 <?php $i=1; ?>
  <?php foreach ($users as $user) : ?>   
  <?php if ($user->userid >=24) : ?> 
  
                  <tr>
                    <td><?= $user->userid; ?></td>
                    <td><?= $user->fullname; ?></td>
                   <td> <a class="d-flex" href="https://api.whatsapp.com/send?phone=62<?= $user->telp; ?>&text=Hallo..%20Assalamu'alaikum <?= $user->telp; ?> "><span class="badge badge-light"><?= $user->telp; ?></span>
                <i class="fab fa-whatsapp-square text-success"></i></a>   
                 </td>
                   <td><span class="badge badge-info">FM</span></td>
                   <td><?= $user->sponsor; ?></td>
                   <td>Null</td>
                   <td><a href="<?= base_url ('administrator/member_detail/' . $user->userid); ?>" class="img">
                  <img class="img-circle" style="width:33px; height:33px;" src="/foto_profile/<?= $user->foto; ?>"></a>
                    </td>                                      
                  </tr>                 
  <?php endif; ?> 
  <?php endforeach; ?>   
 
      
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
</div>
</div>
</div>
</section>
</div>

<?= $this-> endSection(); ?>



                   
 
