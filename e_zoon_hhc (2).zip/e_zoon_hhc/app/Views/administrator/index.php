<?= $this-> extend('administrator/template/index'); ?>
<?= $this-> section('content'); ?>
<?= $this-> include('administrator/template/topbar'); ?>
<?= $this-> include('administrator/template/sidebar'); ?>

 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper"> 
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mt-17 mb-2">
        <?= $this-> include('administrator/template/time'); ?>
          <div class="col-sm-6">
            <h3 class="m-0 text-dark"><b>Data Real Time Hapee</b></h3>
          </div><!-- /.col -->         
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
        
        <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-primary">
              <div class="inner">
                <h5>1.045</h5>
                <p>Jumlah Pendaftar Baru</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div><!-- ./col -->         
          
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-primary">
              <div class="inner">
                <h5>1.500</h5>
                <p>Jumlah Transaksi Belanja</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div><!-- ./col -->         
                   
        <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h5>1.507.<sup style="font-size: 13px">570.900</sup></h5>
                <p>Total Omset</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>   <!-- ./col -->     
                   
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h5>908.<sup style="font-size: 13px">910.700</sup></h5>
                <p>Total PV</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>   <!-- ./col -->  
          
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h5>908.<sup style="font-size: 13px">910.700</sup></h5>
                <p>Total Bonus Member</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>   <!-- ./col -->  
          
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h5>908.<sup style="font-size: 13px">910.700</sup></h5>
                <p>SURPLUS </p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>   <!-- ./col -->  
                                              
        </div>   <!-- ./row --> 
      </div>   <!-- ./container-fluid --> 
   </section>   
        
 <br>
 <div class="content-header">
      <div class="container-fluid">
        <div class="row mt-17 mb-2">
          <div class="col-sm-6">
            <h3 class="m-0 text-dark"><b>Data Real Time Swizh</b></h3>
          </div><!-- /.col -->         
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
        
        <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-primary">
              <div class="inner">
                <h5>1.045</h5>
                <p>Member Upgrade</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div><!-- ./col -->         
                 
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h5>908.<sup style="font-size: 13px">910.700</sup></h5>
                <p>Total Omset</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>   <!-- ./col -->  
          
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h5>908.<sup style="font-size: 13px">910.700</sup></h5>
                <p>Total Bonus Member</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>   <!-- ./col -->  
          
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h5>908.<sup style="font-size: 13px">910.700</sup></h5>
                <p>SURPLUS </p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>   <!-- ./col -->                   
                                              
        </div>   <!-- ./row --> 
      </div>   <!-- ./container-fluid --> 
   </section>   
     
  <br>   
                   
  <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mt-17">
          <div class="col">
            <!-- small box -->
            <div class="small-box bg-secondary">
              <div class="inner">
                 <center><h4>Global Histori Transaksi</4></center>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>   <!-- ./col -->  
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
        
        <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h5>7.<sup style="font-size: 17px">000.909</sup></h5>
                <p>Total Omset</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-primary">
              <div class="inner">
                <h5>7.<sup style="font-size: 17px">000.909</sup></h5>
                <p>Total PV</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h5>15.<sup style="font-size: 17px">000.000</h5>
                <p>Pembayaran Bonus</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h5>15.<sup style="font-size: 17px">000.000</h5>
                <p>Pembayaran Reward</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h5>150.<sup style="font-size: 13px">559.990.600</sup></h5>
                <p>Bonus Pending</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>        
          <!-- ./col -->
                   
        <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h5>150.<sup style="font-size: 13px">559.990.600</sup></h5>
                <p>Piutang Bonus</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>        
          <!-- ./col -->
          
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h5>150.<sup style="font-size: 13px">559.990.600</sup></h5>
                <p>Piutang Reward</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>        
          <!-- ./col -->
          
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h5>63.<sup style="font-size: 13px">491.910.700</sup></h5>
                <p>Operasional, Tax, dll</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>        
          <!-- ./col -->
          
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h5>63.<sup style="font-size: 13px">491.910.700</sup></h5>
                <p>Pendapatan Lainnya</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>        
          <!-- ./col -->
          
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h5>63.<sup style="font-size: 13px">491.910.700</sup></h5>
                <p>SURPLUS</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>        
          <!-- ./col -->
          
          <div class="col">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h5>63.<sup style="font-size: 13px">491.910.700</sup></h5>
                <p>KAS</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>        
          <!-- ./col -->
        
        </div>   <!-- ./row --> 
      </div>   <!-- ./container-fluid --> 
   </section>   
</div>   <!-- ./content-wrapper -->      
      

<?= $this-> endSection(); ?>