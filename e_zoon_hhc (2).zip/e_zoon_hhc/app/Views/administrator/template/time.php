<div class="container-fluid">
    <div class="row">
        <div class="col">
            <div class="breadcrumb-item text-primary">             
               <div id="date-and-clock">
               <span id="datenow"></span> <i class="fas fa-clock"></i>	
               <span id="clocknow"></span>        
	       </div>	       
	    </div>                      
        </div><!-- /.col -->                      	         
     </div><!-- /.row -->
</div><!-- /.container -->