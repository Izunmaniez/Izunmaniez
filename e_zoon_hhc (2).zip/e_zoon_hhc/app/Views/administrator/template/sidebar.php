<aside class="main-sidebar sidebar-dark-purple elevation-4">
   
 <?php if (in_groups('super_admin')) : ?>
     
    <!-- Brand Logo -->
    <a class="brand-link" href="/administrator">
      <img src="/aset/img/bar/logohhc.png" alt="hhc-icon" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light"><b>ADMINISTRATOR</b></span>
    </a>
    <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">   
              <i class="nav-icon fas fa-paste"></i>
              <p>
                Blogs
                 <i class="right fas fa-angle-double-left"></i>                 
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/hapee/blogs" class="nav-link">   
                  <i class="fas fa-eye text-warning"></i>
                <p>Lihat Blogs</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="/administrator/list_blog" class="nav-link">   
                  <i class="fas fa-edit text-warning"></i>
                <p>Blog Editor</p>
                </a>
              </li>
            </ul>
          </li>
        </nav>
        
        <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">   
              <i class="nav-icon fas fa-paste"></i>
              <p>
                Vichar
                 <i class="right fas fa-angle-double-left"></i>                
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/platform/vichar" class="nav-link">   
                  <i class="fas fa-eye text-warning"></i>
                <p>Lihat Video</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="/administrator/list_vichar" class="nav-link">   
                  <i class="fas fa-edit text-warning"></i>
                <p>Video Editor</p>
                </a>
              </li>              
            </ul>
          </li>
        </nav> 
<?php endif; ?>

<?php if (in_groups('admin_keuangan')) : ?>
<!-- Admin Keuangan -->
<!-- Brand Logo -->
    <a class="brand-link bg-secondary" href="/administrator/adminKeuangan">
      <img src="/aset/img/bar/logohhc.png" alt="hhc-icon" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light"><b>Admin Keuangan</b></span>
    </a>

      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">           
              <i class="nav-icon fas fa-money-check-alt"></i>
              <p>
                Keuangan per Platform
                 <i class="right fas fa-angle-double-left"></i>                
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="#" class="nav-link ">       
                  <i class="fas fa-money-check-alt text-info"></i>
                  <p>Hapee</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="fas fa-money-check-alt text-info"></i>
                  <p>Swizh</p>
                </a>
              </li>             
               <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="fas fa-money-check-alt text-info"></i>
                  <p>Empathy</p>
                </a>
              </li>  
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="fas fa-money-check-alt text-info"></i>
                  <p>Vichar</p>
                </a>
              </li> 
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="fas fa-money-check-alt text-info"></i>
                  <p>Charger</p>
                </a>
              </li>                                                                                      
            </ul>
          </li>
        </nav>
        
        <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
            
              <i class="nav-icon fas fa-money-check-alt"></i>
              <p>
                Bonus Member
                 <i class="right fas fa-angle-double-left"></i>                 
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="#" class="nav-link ">       
                  <i class="fas fa-money-check-alt text-info"></i>
                  <p>Bonus Mingguan</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="fas fa-money-check-alt text-info"></i>
                  <p>Bonus Bulanan</p>
                </a>
              </li>  
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="fas fa-money-check-alt text-info"></i>
                  <p>Bonus Tahunan</p>
                </a>
              </li>  
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="fas fa-money-check-alt text-info"></i>
                  <p>Reward</p>
                </a>
              </li>  
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="fas fa-money-check-alt text-info"></i>
                  <p>Rekapitulasi</p>
                </a>
              </li>                                                                                                      
            </ul>
          </li>
        </nav>
        
        <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
            
              <i class="nav-icon fas fa-money-check-alt"></i>
              <p>
                Global Rekap
                 <i class="right fas fa-angle-double-left"></i>
                 
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="#" class="nav-link ">       
                  <i class="fas fa-money-check-alt text-info"></i>
                  <p>Total Masuk</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="fas fa-money-check-alt text-info"></i>
                  <p>Total Keluar</p>
                </a>
              </li>  
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="fas fa-money-check-alt text-info"></i>
                  <p>Management Fee</p>
                </a>
              </li>  
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="fas fa-money-check-alt text-info"></i>
                  <p>Rekapitulasi</p>
                </a>
              </li>                                                                                                      
            </ul>
          </li>
        </nav>
                
 <?php endif; ?>
 
<?php if (in_groups('admin_hapee')) : ?>
<!-- Admin Hapee -->
<!-- Brand Logo -->
    <a class="brand-link bg-secondary" href="/administrator/adminHapee">
      <img src="/aset/img/bar/logohhc.png" alt="hhc-icon" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light"><b>Admin Hapee</b></span>
    </a>
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">           
              <i class="nav-icon fas fa-store"></i>
              <p>
                Daftar Toko
                 <i class="right fas fa-angle-double-left"></i>                 
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="" class="nav-link ">       
                  <i class="fas fa-store text-success"></i>
                  <p>Toko Prioritas</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="penjualan/index" class="nav-link">
                  <i class="fas fa-store text-info"></i>
                  <p>Toko Regular</p>
                </a>
              </li>             
             <div class="dropdown-divider"></div>                     
             <li class="nav-item">
                <a href="" class="nav-link">                  
                  <i class="fas fa-store-slash"></i>
                  <p>Toko Blokir</p>
                </a>
              </li>                           
            </ul>
          </li>
        </nav>
        
        <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">           
              <i class="nav-icon fas fa-store"></i>
              <p>
                Produk Hapee
                 <i class="right fas fa-angle-double-left"></i>                 
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/" class="nav-link ">       
                  <i class="fas fa-store text-success"></i>
                  <p>Lihat Market Place</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="/adminHapee/listProduk" class="nav-link ">       
                  <i class="fas fa-store text-success"></i>
                  <p>Produk Editor</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="fas fa-store text-info"></i>
                  <p>Produk Tunggu</p>
                </a>
              </li>             
             <div class="dropdown-divider"></div>                     
             <li class="nav-item">
                <a href="" class="nav-link">                  
                  <i class="fas fa-store-slash"></i>
                  <p>Produk Blokir</p>
                </a>
              </li>                           
            </ul>
          </li>
        </nav>
        
        <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">           
              <i class="nav-icon fas fa-store"></i>
              <p>
                Status Kirim
                 <i class="right fas fa-angle-double-left"></i>               
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="" class="nav-link ">       
                  <i class="fas fa-store text-primary"></i>
                  <p>List Order</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="fas fa-store text-warning"></i>
                  <p>Sedang Dikirim</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="fas fa-store text-success"></i>
                  <p>Selesai Dikirim</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="fas fa-store text-secondary"></i>
                  <p>Order Batal</p>
                </a>
              </li>                                                 
            </ul>
          </li>
        </nav>
        
        <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">           
              <i class="nav-icon fas fa-store"></i>
              <p>
                Produk Swizh
                 <i class="right fas fa-angle-double-left"></i>                 
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/swizh" class="nav-link ">       
                  <i class="fas fa-store text-success"></i>
                  <p>Lihat Produk</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="#" class="nav-link ">       
                  <i class="fas fa-store text-success"></i>
                  <p>Produk Editor</p>
                </a>
              </li>              
              </ul>
          </li>
        </nav>
<?php endif; ?>

<?php if (in_groups('admin_empathy')) : ?>
  <!-- Sidebar Admin Empathy -->
 <!-- Brand Logo -->
    <a class="brand-link bg-secondary" href="/adminEmpathy">
      <img src="/aset/img/bar/logohhc.png" alt="hhc-icon" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light"><b>Admin Empathy</b></span>
    </a> 
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item" has-treeview menu-open >
            <a href="#" class="nav-link active">          
              <i class="nav-icon fas fa-tasks text-light"></i>
              <p>
                Cashflow Empathy
                 <i class="right fas fa-angle-double-left"></i>               
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/platform/publishEmpathy" class="nav-link ">       
                  <i class="fas fa-eye text-light"></i>                 
                  <p>Lihat Cashflow</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="/adminEmpathy/listCashflow" class="nav-link ">       
                  <i class="fas fa-edit text-light"></i>                 
                  <p>Cashflow Editor</p>
                </a>
              </li>
             </ul>
           </li>      
         </ul>       
      </nav>
      
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item" has-treeview menu-open >
            <a href="#" class="nav-link active">            
              <i class="nav-icon fas fa-tasks text-light"></i>
              <p>
                Galery Empathy
                 <i class="right fas fa-angle-double-left"></i>                 
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/platform/galeryEmpathy" class="nav-link">
                  <i class="fas fa-eye text-light"></i>
                  <p>Lihat Galery</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="/adminEmpathy/listGalery" class="nav-link">
                  <i class="fas fa-edit text-light"></i>
                  <p>Galery Editor</p>
                </a>
              </li>              
            </ul>
          </li>      
        </ul>       
      </nav>
<?php endif; ?>     

          <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
            
              <i class="nav-icon fas fa-users"></i>
              <p>
                Data Member
                 <i class="right fas fa-angle-double-left"></i>              
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/administrator/list_member" class="nav-link active">       
                  <i class="fas fa-address-card nav-icon"></i>
                  
                  <p>Semua Member</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="/membership" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-info"></i>
                  <p>Free Member</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-light"></i>
                  <p>WHITE MANAGER</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-warning"></i>
                  
                  <p>YELLOW MANAGER</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-success"></i>
                  <p>GREEN MANAGER</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-primary"></i>
                  <p>BLUE MANAGER</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-danger"></i>
                  <p>RED MANAGER</p>
                </a>
              </li>
                 <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-secondary"></i>
                  <p>BLACK MANAGER</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-light"></i>
                  <p>DIRECTOR</p>
                </a>
              </li>
                                 
      <div class="dropdown-divider"></div>    
                 
     <li class="nav-item">
                <a href="" class="nav-link">
                  
                  <i class="fas fa-user-times"></i>
                  <p>Member Blokir</p>
                </a>
              </li>
         </ul>
          </li>     
       </nav>   
                                
 <div class="dropdown-divider"></div>
                 
<a href="/logout" class="brand-link" onclick="return confirm('Yakin ingin keluar dari halaman dashboard?');"  style="background-color:#800517; color:white;">
      <img src="/aset/img/bar/logout.png" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light"><b>Logout</b></span>
    </a>
          
          </ul>
        
      </nav>
              
      <!-- /.sidebar-menu -->
    
    <!-- /.sidebar -->
  </aside>
  
  
        
        