<?= $this-> extend('administrator/template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this-> include('administrator/template/topbar'); ?>

<?= $this-> include('administrator/template/sidebar'); ?>

<div class="container">
   <div class="row">   
      <div class="col">
      
<p>   

<h3>Edit Produk Hapee</h3>


<form action="/adminHapee/updateProduk/<?= $produk['id']; ?>" method="post" enctype="multipart/form-data">

<?= csrf_field(); ?>

<input type="hidden" name="imageLama" value="<?= $produk['image']; ?>" >            
 
<div class="form-group row">  
   <label for="image" class="col-sm-2 col-form-label">Gambar Produk</label>  
        <div class="col-sm-2 ">
           <img src="/aset/img/produkHome/<?= $produk['image']; ?>" class="img-thumbnail img-preview">
        </div>   
<div class="col-sm-8">   
  <div class="custom-file">                         
   <input type="file" class="custom-file-input <?= ($validation->hasError('image')) ? 'is-invalid' : ''; ?>" id="image" name="image" onchange="previewImg()">
  <div class="invalid-feedback">
     <?= $validation->getError('image'); ?>
  </div>  
<label class="custom-file-label" for="image"><?= $produk['image']; ?></label>
                           </div>
                        </div>  
                    </div>
<p>

<div class="form-grup row">
    <label for="nama_produk" class="col-sm-2 col-form-label">Nama Produk</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" id="nama_produk" name="nama_produk" value="<?= $produk['nama_produk']; ?>" >            
</div>
</div>
<p>

<div class="form-grup row">
    <label for="kategori" class="col-sm-2 col-form-label">Kategori</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" id="kategori" name="kategori" value="<?= $produk['kategori']; ?>" >            
</div>
</div>
<p>

<div class="form-grup row">
    <label for="brand" class="col-sm-2 col-form-label">Brand</label>
    <div class="col-sm-10">
<input type="text" class="form-control" id="brand" name="brand" value="<?= $produk['brand']; ?>" >            
</div>
</div>
<p>

<div class="form-grup row">
    <label for="nama_toko" class="col-sm-2 col-form-label">Nama Toko</label>
    <div class="col-sm-10">
<input type="text" class="form-control" id="nama_toko" name="nama_toko" value="<?= $produk['nama_toko']; ?>" >            
</div>
</div>
<p>

<div class="form-grup row">
    <label for="produsen" class="col-sm-2 col-form-label">Produsen</label>
    <div class="col-sm-10">
<input type="text" class="form-control" id="produsen" name="produsen" value="<?= $produk['produsen']; ?>" >            
</div>
</div>
<p>

<div class="form-grup row">
    <label for="berat" class="col-sm-2 col-form-label">Berat</label>
    <div class="col-sm-10">
<input type="integer" class="form-control" id="berat" name="berat" value="<?= $produk['berat']; ?>" >            
</div>
</div>
<p>

<div class="form-grup row">
    <label for="harga" class="col-sm-2 col-form-label">Harga</label>
    <div class="col-sm-10">
<input type="integer" class="form-control" id="harga" name="harga" value="<?= $produk['harga']; ?>" >            
</div>
</div>
<p>

<div class="form-grup row">
    <label for="pv" class="col-sm-2 col-form-label">Point Value</label>
    <div class="col-sm-10">
<input type="integer" class="form-control" id="pv" name="pv" value="<?= $produk['pv']; ?>" >            
</div>
</div>
<p>

<div class="form-grup row">
    <label for="deskripsi" class="col-sm-2 col-form-label">Deskripsi</label>
    <div class="col-sm-10">
<input type="text" class="form-control" id="deskripsi" name="deskripsi" value="<?= $produk['deskripsi']; ?>" >            
</div>
</div>
<p>

<div class="row">
                <label for="kondisi" class="col-sm-2 col-form-label">Kondisi</label>
                    <div class="col-sm-12">
                      <!-- select -->
                      <div class="form-group">                       
                        <select class="form-control mb-2" id="kondisi" name="kondisi">
                          <option><?= $produk['kondisi']; ?></option>
                          <option>Baru</option>
                          <option>Bekas</option>                      
                        </select>
                      </div>
                    </div>                   
            </div>

<div class="form-grup row">
    <label for="min_order" class="col-sm-2 col-form-label">Minimal Order</label>
    <div class="col-sm-10">
<input type="integer" class="form-control" id="min_order" name="min_order" value="<?= $produk['min_order']; ?>" >            
</div>
</div>
<p>


<p>
<a href="/adminHapee/listProduk" class="btn btn-secondary btn-md float-right mr-1">Back</a>
                  
  <button type="submit" class="btn btn-warning">Simpan</button>
 
</form>

</p>

</div>
</div>
</div>

<?= $this-> endSection(); ?>
