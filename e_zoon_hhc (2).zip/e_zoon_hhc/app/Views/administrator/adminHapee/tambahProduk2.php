<?= $this-> extend('administrator/template/index'); ?>

<?= $this-> section('content'); ?>

<?= $this-> include('administrator/template/topbar'); ?>

<?= $this-> include('administrator/template/sidebar'); ?>

 <div class="container-wrapper">  
    <div class="col">
      <div class="card card-primary card-outline mt-5">     
         <div class="card-body">
      

<h3>Form Tambah Produk</h3>
<br>
<form action="/adminHapee/saveProduk" method="post" enctype="multipart/form-data" >
<?= csrf_field(); ?>

<div class="form-group">
   <div class="col-sm-12">                   
       <label class="custom-file-label" for="image">Pilih Gambar</label>
       <input type="file" class="custom-file-input <?= ($validation->hasError('image')) ? 'is-invalid' : ''; ?>" id="image" name="image" onchange="previewImg()" autofocus>
          <div class="invalid-feedback">
          <?= $validation->getError('image'); ?>
          </div>                       
              <div class="col-sm-2 ">
              <img src="/aset/img/produkHome/defaultImage.png" class="img-thumbnail img-preview">
              </div>
   </div>
</div>                                  
<p>

<div class="form-grup row mt-4">
   <div class="col-sm-12">
<input type="text" class="form-control" id="nama_produk" name="nama_produk" placeholder="Nama produknya apa..">            
  </div>
</div>
<p>

<div class="form-grup row mt-4">
   <div class="col-sm-12">
<input type="text" class="form-control" id="kategori" name="kategori" placeholder="Kategori">            
  </div>
</div>
<p>

<div class="form-grup row mt-4">
   <div class="col-sm-12">
<input type="varchar" class="form-control" id="brand" name="brand" placeholder="Brand produknya apa.." >            
  </div>
</div>
<p>

<div class="form-grup row mt-4">
   <div class="col-sm-12">
<input type="varchar" class="form-control" id="produsen" name="produsen" placeholder="Nama Produsen" >            
  </div>
</div>
<p>

<div class="form-grup row mt-4">
   <div class="col-sm-12">
<input type="integer" class="form-control" id="berat" name="berat" placeholder="Berate Piro Bro?">            
  </div>
</div>
<p>

<div class="form-grup row mt-4">
   <div class="col-sm-12">
<input type="integer" class="form-control" id="harga" name="harga" placeholder="Hargane Piro Mas?">            
  </div>
</div>
<p>

<div class="form-grup row mt-4">
   <div class="col-sm-12">
<input type="integer" class="form-control" id="pv" name="pv" placeholder="PV ne Pirang Persen?">            
  </div>
</div>
<p>

<div class="form-grup row mt-4">
   <div class="col-sm-12">
<input type="text" class="form-control" id="nama_toko" name="nama_toko" placeholder="Nama Toko">            
  </div>
</div>
<p>

<div class="form-grup row mt-4">
   <div class="col-sm-12">
<input type="integer" class="form-control" id="min_order" name="min_order" placeholder="Minimal Order">            
  </div>
</div>
<p>

<div class="row">
    <div class="col-sm-12">
       <!-- select -->
       <div class="form-group">                       
          <select class="form-control mb-2" id="kondisi" name="kondisi">
             <option>Kondisi</option>
             <option>Baru</option>
             <option>Bekas</option>                      
          </select>
       </div>
    </div>                
</div>
<p>

<div class="card-header card-outline card-info">
    <div class="card-title">
        Deskripsi Produk 
       </div>             
          <div class="card-tools">   
             <button type="button" class="btn btn-tool btn-sm" data-card-widget="collapse" data-toggle="tooltip" title="Collapse"> <i class="fas fa-minus"></i>
             </button>
             <button type="button" class="btn btn-tool btn-sm" data-card-widget="remove" data-toggle="tooltip" title="Remove"> <i class="fas fa-times"></i>
             </button>
          </div> <!-- /. tools -->                                             
     </div><!-- /.card-header -->
                      
         <textarea class="textarea" id="isi_blog" name="isi_blog"  placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;">                       
         </textarea>                  

<p>
<a href="/adminHapee/listProduk" class="btn btn-secondary btn-md float-right mr-1">Back</a>                  
<button type="submit" class="btn btn-primary">Tambah Produk</button>

</form>

</div><!-- /. card-outline -->

        </div>
      </div>
   </div>
</div>

<?= $this-> endSection(); ?>


