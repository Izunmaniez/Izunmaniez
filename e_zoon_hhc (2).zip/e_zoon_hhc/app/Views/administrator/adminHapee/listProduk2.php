<?= $this-> extend('administrator/template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this->include('administrator/template/topbar');?>

<?= $this->include('administrator/template/sidebar');?>

<div class="container">
    <div class="row">
        <div class="col">
 <p>   

 <?php if(session()->getFlashdata('pesan')) : ?>

<div class="alert alert-success" role="alert">

<?= session()->getFlashdata('pesan');?>

</div>
  
<?php endif; ?>
<form action="" method="post">
 <?= csrf_field(); ?> 
 

<a href="/administrator/adminHapee" class="btn btn-secondary btn-md float-right mr-1"><i class="fas fa-angle-double-left"></i> Back</a>
                  
<a class="btn btn-primary mb-4" href="/adminHapee/tambahProduk"><i class="fas fa-plus"></i> Tambah Produk</a>

 <hr>

 <?php foreach ($produk as $prod) : ?>
 
 <div class="card-body p-0">
 <div class="products-list product-list-in-card pl-2 pr-2">                  
  <div class="item">
                    <div class="product-img">
                      <img src="/aset/img/produkHome/<?=$prod['image']; ?>" >
                    </div>
                    <div class="product-info">
                    <span class="product-description">
                        <h6>Nama Produk : <?=$prod['nama_produk']; ?></h6>
                      </span>
                      <span class="product-description">
                        <h6>Brand : <?=$prod['nama_toko']; ?></h6>
                      </span>
                                         
                     <small> <i>uploaded : <span>
                         <?=$prod['created_at']; ?>
                      </span></i></small>   
                                                  
                      
                    </div>
                  </div>
                  </div>
                  </div>
                       

<p>
<table>
<tr>
<td class="project-actions text-right">   
<a href="/adminHapee/editProduk/<?= $prod['id']; ?> " class="btn btn-warning btn-sm">
<i class="fas fa-pencil-alt"></i> Edit </a>
</td>

<td>
<form action="/adminHapee/deleteProduk/<?= $prod['id']; ?>" method="post">
<?= csrf_field(); ?>
<input type="hidden" name="_method" value="delete">

 <button type="submit" class="btn btn-danger btn-sm ml-2" onclick="return confirm('Yakin ingin menghapus produk ini?');">
   <i class="fas fa-trash"></i> Delete</button>
                          
</form>
</td>
</tr>        
</table>                  
 <hr>
 <hr>
  
 
   <?php endforeach; ?>
       
    </form>
  
   </div>
    </div>
</div> 


<?= $this-> endSection(); ?>


