<?= $this-> extend('administrator/template/index'); ?>


 <?= $this-> extend('administrator/template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this-> include('administrator/template/topbar'); ?>

<?= $this-> include('administrator/template/sidebar'); ?>


          <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Form Tambah Produk</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item active">last updloaded</li>
              <li class="breadcrumb-item"><a href="#"><?= date('d M Y'); ?></a></li>            
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

<?php if(session()->getFlashdata('pesan')) : ?>

<div class="alert alert-success" role="alert">

<?= session()->getFlashdata('pesan');?>

</div>
  
<?php endif; ?>
 
<form action="/adminHapee/saveProduk" method="post" enctype="multipart/form-data" >

<?= csrf_field(); ?> 

    <!-- Main content -->
  <section class="content">
    <div class="card card-outline card-primary">
       <div class="card-header">             
         <div class="row">
            <div class="col-md-12">        
              <div class="card-title ml-5">
                Nama Produsen
               <input type="varchar" class="form-control"  id="nama_produsen" name="nama_produsen" autofocus>
              </div>
              <div class="card-title ml-5">
                Alamat Produsen
                <input type="varchar" class="form-control"  id="alamat_produsen" name="alamat_produsen">
              </div>                                                                   
              <div class="card-title ml-5">
                Brand
                <input type="varchar" class="form-control"  id="brand" name="brand">
              </div> 
              <div class="card-title ml-5">
                Nama Toko
                <input type="varchar" class="form-control"  id="nama_toko" name="nama_toko">
              </div> 
              <div class="card-title ml-5">    
                Kategori/Jenis Produk
                    <!-- select -->
                  <select class="form-control" id="kategori" name="kategori" >
                      <option></option>
                      <option>Makanan</option>
                      <option>Minuman</option>
                      <option>Herbal</option>
                      <option>Fashion</option>     
                      <option>Kosmetik</option>
                      <option>Alat Kecantikan</option>
                      <option>Perabot</option>
                      <option>Alat Dapur</option>
                      <option>Toiletris</option>
                      <option>Kenderaan</option>
                      <option>Pertanian</option>
                      <option>Peternakan</option>
                      <option>Elektronik</option>     
                      <option>Smart Phone</option>
                      <option>Musik</option>
                      <option>Olah Raga</option>
                      <option>Souvenir</option>
                      <option>Lainnya</option>                   
                  </select>
              </div>                                                                                
              <div class="card-title ml-5">
                Nama Produk
                <input type="varchar" class="form-control"  id="nama_produk" name="nama_produk">
              </div> 
              <div class="card-title ml-5">
                Harga <small class="text-danger">(Rp.) input hanya angka</small>
               <input type="integer" class="form-control"  id="harga" name="harga">
              </div> 
              <div class="card-title ml-5">
                Point Value <small class="text-danger">(%) input hanya angka</small>
                <input type="integer" class="form-control"  id="pv" name="pv">
              </div> 
              <div class="card-title ml-5">
                Berat <small class="text-danger">(gram) input hanya angka</small>
              <input type="integer" class="form-control"  id="berat" name="berat">
              </div> 
              <div class="card-title ml-5">
                Minimal Order <small class="text-danger">input hanya angka</small>
                <input type="integer" class="form-control"  id="min_order" name="min_order" >
              </div> 
              <div class="card-title ml-5">
                 Satuan Produk
                    <!-- select -->
                  <select class="form-control" id="satuan_produk" name="satuan_produk">
                      <option></option>
                      <option></option>
                      <option>Box</option>
                      <option>Bungkus</option>
                      <option>Unit</option>
                      <option>Buah</option>
                      <option>Rol</option> 
                      <option>Lusin</option>
                      <option>Kodi</option>
                      <option>Pack</option>
                      <option>Tabung</option>  
                      <option>Botol</option> 
                      <option>Pasang</option> 
                      <option>Karung</option>  
                      <option>Kaleng</option>      
                  </select>
               </div> 
               <div class="card-title ml-5">
                 Kondisi Produk
                    <!-- select -->
                  <select class="form-control" id="kondisi" name="kondisi">
                      <option></option>
                      <option>Baru</option>
                      <option>Bekas</option>                      
                  </select>
               </div>     
               <div class="card-title ml-5">
                 Cara Bayar
                    <!-- select -->
                  <select class="form-control" id="sistem_bayar" name="sistem_bayar">          
                      <option></option>
                      <option>C O D</option>
                      <option>Transfer</option>                      
                  </select>
               </div>           
          
         </div><!-- /.col-->      
      </div><!-- ./row -->           
                                             
            <div class="row">
               <div class="col-sm-12">
                   <!-- textarea -->
                  <div class="form-group">
                        <label>Deskripsi Produk</label>                       
                        <textarea type="varchar" class="form-control" rows="5"  id="deskripsi" name="deskripsi">
                        
                        </textarea>
                    </div>
                </div>
             </div>
                                                                     

       <div class="form-group">
                 <div class="col-sm-12 my-5">                   
                    <label class="custom-file-label bg-olive" for="image">Pilih Gambar</label>
                    <input type="file" class="custom-file-input <?= ($validation->hasError('image')) ? 'is-invalid' : ''; ?>" id="image" name="image" onchange="previewImg()" autofocus>
                    <div class="invalid-feedback">
                       <?= $validation->getError('image'); ?>
                    </div>                       
                       <div class="col-sm-2 ">
                          <img src="/aset/img/produkHome/defaultImage.png" class="img-thumbnail img-preview">
                       </div>
                    </div>
                </div>
                
             <div class="col-12-sm-6">           
             <a href="/adminHapee/listProduk" class="btn btn-secondary btn-md ml-5 mt-3">Back</a>                  
             <button class="btn btn-primary mt-3 mr-5 float-right" type="submit" name="submit">
                Tambah Produk           
              </button> 
             </div>               
           </div>
         </div>
      </div>       
   </section><!-- /.content -->  
   </form>
</div>    

<?= $this-> endSection(); ?>
  

                                      