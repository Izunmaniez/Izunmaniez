<?= $this-> extend('administrator/template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this->include('administrator/template/topbar');?>

<?= $this->include('administrator/template/sidebar');?>


 <?php if(session()->getFlashdata('pesan')) : ?>

<div class="alert alert-success" role="alert">
<?= session()->getFlashdata('pesan');?>
</div>
  
<?php endif; ?>

<form action="" method="post">
 <?= csrf_field(); ?> 

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Produk Hape</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <?= $this->include('administrator/template/time');?>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

        <div class="row">
          <div class="col-12">
           <div class="card">
              <div class="card-header">             
                <a href="/administrator/adminHapee" class="btn btn-secondary btn-md float-right mr-1"><i class="fas fa-angle-double-left"></i> Back</a>
                <a class="btn btn-primary mb-4" href="/adminHapee/tambahProduk"><i class="fas fa-plus"></i> Tambah Produk</a>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-responsive">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Image</th>
                    <th>Kategori</th>
                    <th>Nama_Toko</th>
                    <th>Nama_Produk</th>                
                    <th>Harga_Rp.</th>
                    <th>PV_%</th>                  
                    <th>Berat_gram</th>
                    <th>MOQ</th>
                    <th>Sistem_Pembayaran</th>
                    <th>Kondisi</th>                
                    <th>Deskripsi</th>
                    <th>Tanggal_Upload</th>
                    <th><center></center></th>
                  </tr>
                  </thead>
                  <tbody>  
 <?php $i=1; ?>                
 <?php foreach ($produk as $prod) : ?>              <img class="img-circle" style="width:33px; height:33px;"   
                  <tr>
                    <td><?=$i++; ?></td>
                    <td><img class="img-circle" style="width:33px; height:33px;" src="/aset/img/produkHome/<?=$prod['image']; ?>"></td>
                    <td><?=$prod['kategori']; ?></td>
                    <td><?=$prod['nama_toko']; ?></td>
                    <td><?=$prod['nama_produk']; ?></td>                
                    <td> <?=number_format ($prod['harga'], 0, ".", "."); ?>,-</td>
                    <td> <?=$prod['pv']; ?></td>                  
                    <td> <?=number_format ($prod['berat'], 0, ".", "."); ?> </td>
                    <td> <?=number_format ($prod['min_order'], 0, ".", "."); ?></td>
                    <td><?=$prod['sistem_bayar']; ?></td>
                    <td><?=$prod['kondisi']; ?></td>                
                    <td><?=$prod['deskripsi']; ?></td>
                    <td><?=$prod['updated_at']; ?></td>
                    <td class="project-actions">   
    <div class="row justify-content-center">                    
      <a class="btn btn-info btn-sm mb-1 ml-2 pl-3 pr-3" href="<?= base_url ('hapee/produk_detail/' . $prod['id']); ?>">
      <i class="fas fa-eye"></i><br>
      Look
      </a>
      <a class="btn btn-warning btn-sm mb-1 ml-2 pl-3 pr-3" href="/adminHapee/editProduk/<?= $prod['id']; ?>">
      <i class="fas fa-pencil-alt"></i><br>
      Edit
      </a>                      
      <form action="/adminHapee/deleteProduk/<?= $prod['id']; ?>" method="post">
      <?= csrf_field(); ?>

      <input type="hidden" name="_method" value="delete">
      <button type="submit" class="btn btn-danger btn-sm mb-1 ml-2" onclick="return confirm('Yakin ingin menghapus data ini?');">
      <i class="fas fa-trash"></i><br>
      Delete
      </button>
      </form>
    </div></td>
                  </tr>

 <?php endforeach; ?>     
                  
                  </tbody>
                  <tfoot>
                  <tr>
                    <th>#</th>
                    <th>Image</th>
                    <th>Kategori</th>
                    <th>Nama_Toko</th>
                    <th>Nama_Produk</th>                
                    <th>Harga_Rp.</th>
                    <th>PV_%</th>                  
                    <th>Berat</th>
                    <th>MOQ</th>
                    <th>Sistem_Pembayaran</th>
                    <th>Kondisi</th>                
                    <th>Deskripsi</th>
                    <th>Tanggal_Upload</th>
                    <th></th>
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
<?= $this-> endSection(); ?>