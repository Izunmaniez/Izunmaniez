<?= $this-> extend('administrator/template/index'); ?>

<?= $this-> section('content'); ?>

<?= $this-> include('administrator/template/topbar'); ?>

<?= $this-> include('administrator/template/sidebar'); ?>

 <div class="container-wrapper">  
    <div class="col">
      <div class="card card-primary card-outline mt-5">     
         <div class="card-body">
      
<p>   

<h3>Form Tambah Galery</h3>


<form action="/adminEmpathy/saveGalery" method="post" enctype="multipart/form-data" >

<?= csrf_field(); ?>

<div class="form-grup row mt-4">
   <div class="col-sm-12">
<input type="text" class="form-control" id="judul" name="judul" placeholder="Judulnya apa.." autofocus>            
  </div>
</div>
<p>

<div class="form-group">
   <div class="col-sm-10">                   
       <label class="custom-file-label" for="foto">Pilih Gambar</label>
       <input type="file" class="custom-file-input <?= ($validation->hasError('foto')) ? 'is-invalid' : ''; ?>" id="foto" name="foto" onchange="previewImg()">
          <div class="invalid-feedback">
          <?= $validation->getError('foto'); ?>
          </div>                       
              <div class="col-sm-2 ">
              <img src="/aset/img/dokumenDjos/default_profile.png" class="img-thumbnail img-preview">
              </div>
   </div>
</div>                                  
<p>

<div class="form-grup row my-5">  
   <div class="col-sm-12">              
      <textarea class="form-control" rows="3" id="ket" name="ket" placeholder="Deskripsine opo.."></textarea> 
   </div>
</div>
<p>
<p>
<a href="/adminEmpathy/listGalery" class="btn btn-secondary btn-md float-right mr-1">Back</a>                  
<button type="submit" class="btn btn-primary">Tambah</button>

</form>


        </div>
      </div>
   </div>
</div>


<?= $this-> endSection(); ?>
