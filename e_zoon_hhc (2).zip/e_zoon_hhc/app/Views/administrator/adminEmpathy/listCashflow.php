<?= $this-> extend('administrator/template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this-> include('administrator/template/topbar'); ?>

<?= $this-> include('administrator/template/sidebar'); ?>


 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
        
<?= $this-> include('administrator/template/time'); ?>

          <div class="col-sm-6">
            <h3>Cash Flow Empathy HHC</h3>           
          </div>        
        </div>      
     <p>
     
<a href="/adminEmpathy" class="btn btn-secondary btn-md float-right mr-1"><i class="fas fa-angle-double-left"></i>  Back</a>                   
   
<a class="btn btn-primary ml-1" href="/adminEmpathy/tambahCashflow"><i class="fas fa-plus"></i> Tambah</a>
    
</div><!-- /.container-fluid -->


<?php if(session()->getFlashdata('pesan')) : ?>

<div class="alert alert-success" role="alert">

<?= session()->getFlashdata('pesan');?>

</div>
  
<?php endif; ?>



  </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              
              <!-- /.card-header -->
              <div class="card-body" style="overflow:auto; ">
                <table id="example1" class="table table-bordered table-hover" style="text-align:center;">
                  <thead class="table-info">
                  <tr>
                    <th>#</th>
                    <th>Tanggal</th>
                    <th>Donatur</th>
                    <th>Donasi Rp. </th>
                    <th>Disalurkan Rp. </th>
                    <th>Volunteer</th>
                    <th>Keterangan</th>
                    <th>E/D</th>                                  
                  </tr>
                  </thead>
                  <tbody>
                  

<?php $i=1; ?>                

 <?php foreach ($djos as $dj) : ?>     
 
 <?php 

  $donasi[] =$dj['masuk'];
  $disalurkan[] =$dj['keluar'];
?> 
                   <tr>
                    <td><?=$i++; ?>  </td>
                    <td><?=$dj['tanggal']; ?>  </td>
                    <td><?=$dj['donatur']; ?>  </td>
                    <td><?=number_format ($dj['masuk'], 0, ".", "."); ?>,-  </td>
                    <td><?=number_format ($dj['keluar'], 0, ".", "."); ?>,-  </td>
                    <td><?=$dj['volunteer']; ?>  </td>
                    <td>
<div class="container">      
<div class="vmvm-item"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="ket" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i> lihat </i></a>

  <div class="dropdown-menu" style="background-color:#808000; color:white; text-align:center; padding:15px 15px 15px 35px;"  aria-labelledby="ket">
<p>
<p>
   
<?=$dj['keterangan']; ?>

<p><p><p><p>

<div class="btn btn-success">Aye..ðŸ˜„</div>
<p><p>
</div>
</div>
</div>


 </td>
 


<td class="project-actions">   
<div class="row justify-content-center">                    
                          <a class="btn btn-warning btn-sm mb-1 ml-2 pl-3 pr-3" href="/adminEmpathy/editCashflow/<?= $dj['id']; ?>">
                              <i class="fas fa-pencil-alt">
                              </i><br>
                              Edit
                          </a>
                         
<form action="/adminEmpathy/deleteCashflow/<?= $dj['id']; ?>" method="post">
<?= csrf_field(); ?>

<input type="hidden" name="_method" value="delete">

 <button type="submit" class="btn btn-danger btn-sm mb-1 ml-2" onclick="return confirm('Yakin ingin menghapus data ini?');">
                              <i class="fas fa-trash">
                              </i><br>
                              Delete
                          </button>
</form>
</div>
                      </td>

</tr> 



 <?php endforeach; ?>     
       
                  </tbody>     
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
            
            <?php
    //total
    $total_donasi =array_sum($donasi);
    $total_disalurkan   =array_sum($disalurkan);
    $saldo =$total_donasi-$total_disalurkan;
?>

<!-- Content Wrapper. Contains page content -->

    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h3 class="m-0 text-dark">Total Cashflow</h3>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Hari ini <?= date("d-m-Y"); ?>  </a></li>            
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

  <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
        
        <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-primary">
              <div class="inner">
                <p>Total Donasi Rp.</p>
                <h5><sup style="font-size: 17px"><?=number_format ($total_donasi, 0, ".", "."); ?></sup></h5>               
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
               </div>
          </div>
          <!-- ./col -->
          
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <p>Total Disalurkan Rp.</p>
                <h5><sup style="font-size: 17px"><?=number_format ($total_disalurkan, 0, ".", "."); ?></h5>               
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
               </div>
          </div>
          <!-- ./col -->
          
          <div class="col-lg-3 col-12">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <p>Saldo Rp.</p>
                <h5><sup style="font-size: 17px"><?=number_format ($saldo, 0, ".", "."); ?></h5>               
              </div>
              <div class="icon">
               <i class="ion ion-bag"></i>
               </div>
               </div>
          </div>
          <!-- ./col -->                          
        </section>       
            
</div>
</div>
</div>
</section>
            
</div>

<?= $this-> endSection(); ?>
