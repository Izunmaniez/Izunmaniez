<?= $this-> extend('administrator/template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this-> include('administrator/template/topbar'); ?>

<?= $this-> include('administrator/template/sidebar'); ?>


 <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
        
<?= $this-> include('administrator/template/time'); ?>

          <div class="col-sm-6">
            <h3>Vichar Editor</h3>           
          </div>        
        </div>      
     <p>
     
<a href="/administrator" class="btn btn-secondary btn-md float-right mr-1"><i class="fas fa-angle-double-left"></i>  Back</a>                   
   
<a class="btn btn-primary ml-1" href="/administrator/tambah_vichar"><i class="fas fa-plus"></i> Tambah</a>
    
    </div><!-- /.container-fluid -->


<?php if(session()->getFlashdata('pesan')) : ?>

       <div class="alert alert-success" role="alert">

<?= session()->getFlashdata('pesan');?>

       </div>
  
<?php endif; ?>

  </section>


  <section class="content">
    <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">             
              <!-- /.card-header -->
              <div class="card-body" style="overflow:auto; ">
                <table id="example1" class="table table-bordered table-hover" style="text-align:center;">
                  <thead class="table-info">
                  <tr>
                    <th>#</th>
                    <th>Judul_Video</th>
                    <th>Tanggal_Upload</th>
                    <th>E/D</th>
                  </tr>
                  </thead>
                  <tbody>
                 
<?php $i=1; ?>                

 <?php foreach ($vichar as $vic) : ?>     
 
                  <tr>
                    <td><?=$i++; ?>  </td>
                    <td><?=$vic['judul']; ?>  </td>
                    <td><?=$vic['updated_at']; ?>  </td>                                
                    <td class="project-actions">   
    <div class="row justify-content-center">                    
      <a class="btn btn-warning btn-sm mb-1 ml-2 pl-3 pr-3" href="/administrator/edit_vichar/<?= $vic['id']; ?>">
      <i class="fas fa-pencil-alt"></i><br>
      Edit
      </a>
                         
      <form action="/administrator/delete_vichar/<?= $vic['id']; ?>" method="post">
      <?= csrf_field(); ?>

      <input type="hidden" name="_method" value="delete">
      <button type="submit" class="btn btn-danger btn-sm mb-1 ml-2" onclick="return confirm('Yakin ingin menghapus video ini?');">
      <i class="fas fa-trash"></i><br>
      Delete
      </button>
      </form>
    </div>
                      </td>
                    </tr> 

 <?php endforeach; ?>     
       
                  </tbody>     
                </table>
              </div><!-- /.card-body -->             
            </div><!-- /.card -->                                  
          </div>
        </div>
      </div>
   </section>           
</div>

<?= $this-> endSection(); ?>
