<?= $this-> extend('administrator/template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this-> include('users/template/topbar'); ?>

<?= $this-> include('users/template/sidebar'); ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
   <!-- Content Wrapper. Contains page content -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row">
         <div class="col-sm-12">
          <div class="card card-header">
            <div class="post-clearfix">
              <div class="user-block">
                <img class="img-circle img-bordered-sm" src="/foto_profile/<?= user()->foto; ?>" alt="user image">
                  <span class="username">
            
            <h1><b> <?= user()->nama_produk; ?></b></h1>
                  </span>   
                  <span class="description text-info"><?= user()->fullname; ?>
                  </span>                                     
            </div>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    
   <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
        
        <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-primary">
              <div class="inner">
                <h3>1.045</h3>
                <p>Jumlah Pelanggan</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3>1.500</h3>
                <p>Jumlah Transaksi Belanja</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
                   
        <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h4>1.507.<sup style="font-size: 13px">570.900</sup></h4>
                <p>Total Omset</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>        
          <!-- ./col -->
          
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h4>908.<sup style="font-size: 13px">910.700</sup></h4>
                <p>Total pH</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Lihat Detail<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>        
          <!-- ./col -->
                         
        </div>
     
    </section>   


<!-- Main content -->
  <div class="col-sm-12 mt-1">    
    <div class="content">            
          <div class="card">
              <div class="card-header border-0">
                <div class="d-flex justify-content-between">
                  <h3 class="card-title text-info"><b>Pengunjung Toko</b></h3>
                  <a href="javascript:void(0);">View Report</a>
                </div>
              </div>
              <hr>
              <div class="card-body">
                <div class="d-flex">
                  <p class="d-flex flex-column text-success">
                    <span class="text-bold text-lg">820</span>
                    <span>Total Pengunjung</span>
                  </p>
                  <p class="ml-auto d-flex flex-column text-right">
                    <span class="text-success">
                      <i class="fas fa-arrow-up"></i> 12.5%
                    </span>
                    <span class="text-muted">Sejak Minggu Lalu</span>
                  </p>
                </div>
                <!-- /.d-flex -->

                <div class="position-relative mb-4">
                  <canvas id="visitors-chart" height="200"></canvas>
                </div>

                <div class="d-flex flex-row justify-content-end">
                  <span class="mr-2">
                    <i class="fas fa-square text-primary"></i> Minggu ini
                  </span>

                  <span>
                    <i class="fas fa-square text-gray"></i> Minggu Lalu
                  </span>
                </div>
              </div>
            </div>
            <!-- /.card -->      
          </div>
        </div>
         
      <!-- Produk -->        
  <div class="content-wrapper">
     <!-- Content Header (Page header) -->
 <section class="container-fluid">   
    <div class="card">    
      <div class="row ml-2 mt-2">
         <div class="col-sm-12">
             <div class="post-clearfix">
            <a class="btn btn-primary img-circle img-bordered elevation-2 float-right mr-2" href="/users/tambahProduk"><strong><i class="fas fa-plus"></i></strong> <small>item</small></a>
                
              <div class="user-block">
                 <img class="img-circle img-bordered-sm" src="/foto_profile/<?= user()->foto; ?>" alt="user image">
                  <span class="username">
            <h5>List Produk</h5>  
                  </span>  
                  <span class="description text-info mb-3"><?= user()->username; ?>
                  </span>              
             </div>
          </div>
        </div>
     </div>

  <hr>

<div class="row">
 <div class="col-12 col-sm-6 mb-3">           
     <div class="user-block ml-1 mb-1">         
      <a href="">                                
       <img src="/aset/img/produkHome/swizhOil.jpg" class="img-thumbnail img-bordered" style="border-radius:5px; width:150px; height:150px;" alt="">  
      <center class="small-box-footer bg-info" style="border-radius:5px;"><i class="fas fa-eye"></i>Lihat di etalase</center> 
      </a>                      
    </div> 
<div class="card-body" style="overflow:auto;">  

<table>  
    <tr>
    <td colspan="3">
    <span class="description text-info">
      <h6><b>SWIZ Perfume</b></h6>  
      </span> 
      </td>   
      </tr>  
    <tr>
    <td><b>Rp</b> </td>   
    <td> : </td>   
    <td>
      <?= user()->telp; ?>
    </td>   
    </tr> 
    <tr>
    <td><b>PV</b> </td>    
    <td> : </td>    
    <td>
       <?= user()->norek; ?> <b>%</b>
    </td>   
    </tr>    
    </table>
       </div>      
      <a class="btn btn-sm btn-warning ml-3" type="button" data-toggle="modal" data-target="#produk_detail">
      <i class="fas fa-edit"></i> Edit</a>    
       <a href="" class="btn btn-sm btn-danger ml-3 text-light">
      <i class="fas fa-trash text-light"></i>Hapus</a>                                                                                                  
</div> 
   
       <div class="col-12 col-sm-6 mb-3">           
     <div class="user-block ml-1 mb-1">         
      <a href="">                                
       <img src="/aset/img/produkHome/swizh.jpg" class="img-thumbnail img-bordered" style="border-radius:5px; width:150px; height:150px;" alt="">  
      <center class="small-box-footer bg-info" style="border-radius:5px;"><i class="fas fa-eye"></i>Lihat di etalase</center> 
      </a>                      
    </div> 
<div class="card-body" style="overflow:auto;">    
<table>  
    <tr>
    <td colspan="3">
    <span class="description text-info">
      <h6><b>Swizh Coffee</b></h6>  
      </span> 
      </td>   
      </tr>  
    <tr>
    <td><b>Rp</b> </td>   
    <td> : </td>   
    <td>
      <?= user()->telp; ?>
    </td>   
    </tr> 
    <tr>
    <td><b>PV</b> </td>    
    <td> : </td>    
    <td>
       <?= user()->norek; ?> <b>%</b>
    </td>   
    </tr>    
    </table>
       </div>      
      <a class="btn btn-sm btn-warning ml-3" type="button" data-toggle="modal" data-target="#produk_detail">
      <i class="fas fa-edit"></i> Edit</a>    
       <a href="" class="btn btn-sm btn-danger ml-3 text-light">
      <i class="fas fa-trash text-light"></i>Hapus</a>                                                                                                  
</div> 
      
  <div class="col-12 col-sm-6 mb-3">           
     <div class="user-block ml-1 mb-1">         
      <a href="">                                
       <img src="/aset/img/produkHome/swizhOil.jpg" class="img-thumbnail img-bordered" style="border-radius:5px; width:150px; height:150px;" alt="">  
      <center class="small-box-footer bg-info" style="border-radius:5px;"><i class="fas fa-eye"></i>Lihat di etalase</center> 
      </a>                      
    </div> 
<div class="card-body" style="overflow:auto;">    
<table>  
    <tr>
    <td colspan="3">
    <span class="description text-info">
      <h6><b>Swizh Oil</b></h6>  
      </span> 
      </td>   
      </tr>  
    <tr>
    <td><b>Rp</b> </td>   
    <td> : </td>   
    <td>
      <?= user()->telp; ?>
    </td>   
    </tr> 
    <tr>
    <td><b>PV</b> </td>    
    <td> : </td>    
    <td>
       <?= user()->norek; ?> <b>%</b>
    </td>   
    </tr>    
    </table>
       </div>      
      <a class="btn btn-sm btn-warning ml-3" type="button" data-toggle="modal" data-target="#produk_detail">
      <i class="fas fa-edit"></i> Edit</a>    
       <a href="" class="btn btn-sm btn-danger ml-3 text-light">
      <i class="fas fa-trash text-light"></i>Hapus</a>                                                                                                  
</div> 


 <div class="modal fade" id="produk_detail">
        <div class="modal-dialog">
          <div class="modal-content bg-light">
            <div class="modal-header">
              <h2 class="modal-title"><strong>SWIZ Shop</strong></h2>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
            
    <section class="slider-section pt-4 pb-4">
<div class="container">
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner shadow-sm rounded ">
    <div class="carousel-item active">
      <img src="/aset/img/produkHome/swizh.jpg" class="d-block w-100" style="height:190px; margin-bottom:13px;">
    </div>
    <div class="carousel-item">
      <img src="/aset/img/produkHome/swizhOil.jpg" class="d-block w-100"  style="height:190px; margin-bottom:13px;">
    </div>
  <div class="carousel-item">
      <img src="/aset/img/produkHome/swizh.jpg" class="d-block w-100"  style="height:190px; margin-bottom:13px;">
    </div>
  <div class="carousel-item">
      <img src="/aset/img/produkHome/swizhOil.jpg" class="d-block w-100"  style="height:190px; margin-bottom:13px;">
    </div>
    
   
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>
</section>        
            
              <div class="card-body" style="overflow:auto;">
    <table> 
    <tr>
    <td>Merk</td>
    <td>:</td>
    <td>     
      <?= user()->fullname; ?> 
    </td>   
    </tr> 
    <tr>
    <td>Kategori</td>
    <td>:</td>
    <td>    
      <?= user()->username; ?>
    </td>   
    </tr> 
    <tr>
    <td>Harga</td>
    <td>:</td>
    <td>
    <?= user()->telp; ?>
    </td>   
    </tr> 
    <tr>
    <td>PV</td>
    <td>:</td>
    <td>
    <?= user()->norek; ?>
    </td>   
    </tr> 
    </table>                                                                                          
    </div>    
            <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-warning">Simpan</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
             
            </div>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal --> 



      </div>
    <!-- /.card --> 
    </section>
    <!-- /.fluid -->      
  </div>
  <!-- /.content-wrapper -->
  

    </div>
  <!-- /.content-wrapper -->
  
 
 <?= $this-> endSection(); ?>
 
