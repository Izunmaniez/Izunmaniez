<?= $this-> extend('administrator/template/index'); ?>


<?= $this-> section('content'); ?>

 <?= $this-> include('users/template/topbar'); ?>
 
 <?= $this-> include('users/template/sidebar'); ?>

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Invoice</h1>
          </div>
         
          <?= $this-> include('administrator/template/time'); ?>

        </div>
      </div><!-- /.container-fluid -->
    </section>

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="callout callout-info">
              <h5><i class="fas fa-info"></i> Note :</h5>
              Yok Semuanya..!!!! Every body hands up..!!! pok ame-ame.. belalang kupu-kupu.. lanjutin dech..?😂😂😂
            </div>


            <!-- Main content -->
            <div class="invoice p-3 mb-3">
              <!-- title row -->
              <div class="row">
                <div class="col-12">
                  <h4>
                    <div class="user-block">
                <img class="img-circle img-bordered-sm" src="/foto_profile/<?= user()->foto; ?>">
                    </div>  
                 Tagihan Belanja Saya
                    <small class="float-right">Date: 2/06/2021</small>
                  </h4>
                </div>
                <!-- /.col -->
              </div>
              <br>
              <!-- info row -->
              <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                  <u>Dari</u>
                  <address>
                    <strong>PT. HHC INDONESIA</strong><br>
                    Asahan<br>
                    Sumatera Utara, Indonesia<br>
                    Phone: (061) 55432<br>
                    Email: invoice@hhc.co.id
                  </address>
                </div>
                <!-- /.col -->
                <div class="col-sm-4 invoice-col">
                  <u>Kepada</u>
                  <address>  
                  <table>
                  
                  <tr>
                  <td>              
                    Username
                  </td>
                  <td>:</td>
                  <td>
                  <b><?= user()->username; ?></b>
                  </td>
                  </tr>
                  <tr>
                  <td>              
                    Nama Lengkap
                  </td>
                  <td>:</td>
                  <td>
                  <b><?= user()->fullname; ?></b>
                  </td>
                  </tr>
                  <tr>
                  <td>              
                    Alamat
                  </td>
                  <td>:</td>
                  <td>
                  <?= user()->alamat; ?>
                  </td>
                  </tr>
                  <tr>
                  <td>              
                    Phone
                  </td>
                  <td>:</td>
                  <td>
                  <?= user()->telp; ?>
                  </td>
                  </tr>
                  <tr>
                  <td>              
                    Email
                  </td>
                  <td>:</td>
                  <td>
                  <?= user()->email; ?>
                  </td>
                  </tr>                 
                  </table>                                     
                  </address>
                </div>
                <!-- /.col -->
                <div class="col-sm-4 invoice-col">
                  <b>Invoice #007612</b><br>                  
                  <b>Order ID:</b> 4F3S8J<br>
                  <b>Payment Due:</b> 2/22/2021<br>
                  </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <!-- Table row -->
              <div class="row">
                <div class="col-12 table-responsive">
                  <table class="table table-striped">
                    <thead>
                    <tr>
                      <th>Qty</th>
                      <th>Product</th>
                      <th>Serial #</th>
                      <th>Description</th>
                      <th>Subtotal</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                      <td>1</td>
                      <td>Call of Duty</td>
                      <td>455-981-221</td>
                      <td>El snort testosterone trophy driving gloves handsome</td>
                      <td>$64.50</td>
                    </tr>
                    <tr>
                      <td>1</td>
                      <td>Need for Speed IV</td>
                      <td>247-925-726</td>
                      <td>Wes Anderson umami biodiesel</td>
                      <td>$50.00</td>
                    </tr>
                    <tr>
                      <td>1</td>
                      <td>Monsters DVD</td>
                      <td>735-845-642</td>
                      <td>Terry Richardson helvetica tousled street art master</td>
                      <td>$10.70</td>
                    </tr>
                    <tr>
                      <td>1</td>
                      <td>Grown Ups Blue Ray</td>
                      <td>422-568-642</td>
                      <td>Tousled lomo letterpress</td>
                      <td>$25.99</td>
                    </tr>
                    </tbody>
                  </table>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <div class="row">
                <!-- accepted payments column -->
                <div class="col-6">
                  <p class="lead">Metode Pembayaran:</p>
                 
                  <img style="width:50px; height:50px; border-radius:9px;" src="/aset/img/gold/bca.jpg">
                  <img style="width:50px; height:50px; border-radius:9px;" src="/aset/img/gold/bni.jpg">
                  <img style="width:50px; height:50px; border-radius:9px;" src="/aset/img/gold/bri.jpg">
                  <img style="width:50px; height:50px; border-radius:9px;" src="/aset/img/gold/bsi.jpg">                  
                  <br>
                  <img style="width:100px; height:50px; border-radius:7px;" src="/aset/img/gold/mandiri.jpg" alt="bank-mandiri-hhc">
                  
                  <img style="width:100px; height:50px; border-radius:7px;" src="/aset/img/gold/ovo.jpg" alt="ovo-hhc">
                  <br>
                  <img style="width:100px; height:50px; border-radius:7px;" src="/aset/img/gold/dana.jpg" alt="dana-hhc">
                  
                  <img style="width:100px; height:50px; border-radius:7px;" src="/aset/img/gold/gopay.jpg" alt="gopay-hhc">  
                  <br>
                  <p class="text-muted well well-sm shadow-none text-sm" style="margin-top: 10px;">
                  Silahkan hubungi Admin jika ada kesulitan akses pembayaran.</p>
                </div>
                <!-- /.col -->
                <div class="col-6">
                  <p class="lead">Wajib Bayar 3/06/2021</p>

                  <div class="table-responsive">
                    <table class="table">
                      <tr>
                        <th style="width:50%">Subtotal:</th>
                        <td>Rp. 250.000</td>
                      </tr>
                      <tr>
                        <th>Pajak (10%)</th>
                        <td>Rp. 25.000</td>
                      </tr>
                      <tr>
                        <th>Ongkir:</th>
                        <td>Rp. 25.000</td>
                      </tr>
                      <tr>
                        <th>Total:</th>
                        <td>Rp. 300.000</td>
                      </tr>
                    </table>
                  </div>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <!-- this row will not appear when printing -->
              <div class="row">
                <div class="col-12">
                  <a href="invoice-print.html" target="_blank" type="button" class="btn-sm btn-light mt-1" style="font-size:13px;"><i class="fas fa-print"></i> Print<br>to Excel</a>
                  <a href="" type="button" class="btn-sm btn-secondary mt-1" style="font-size:13px;">
                    <i class="fas fa-download"></i> Print<br>to PDF
                  </a>
                  <a href="" type="button" class="btn-sm btn-primary mt-1" style="font-size:13px;"><i class="far fa-credit-card"></i> Bayar<br>Sekarang
                  </a>
                  <a href="/" type="button" class="btn-sm btn-success mt-1" style="font-size:13px;"><i class="fas fa-shopping-cart"></i> Lanjut<br>Belanja
                  </a>
                </div>             
              </div>
            </div>
            <!-- /.invoice -->
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  

 <?= $this-> endSection(); ?>
  