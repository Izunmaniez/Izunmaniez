<!-- Default box -->
      <div class="card card-solid">
        <div class="card-body">
          <div class="row">
          
            <div class="col-12 col-sm-6 mt-3">                                                 
            <!-- Widget: user widget style 1 -->          
            <div class="card card-widget widget-user">
              <!-- Add the bg color to the header using any of the bg-* classes -->
              <div class="widget-user-header text-light"
                   style="background: url('../aset/img/userDashboard/bg.jpg') center center;">
                <h4 class="widget-user-desc text-right"><b>HHC</b></h4><small><i>The Pioneer of Integrated Global Business</i></small>
                </div>
              <div class="widget-user-image">              
              <img class="user-image img-circle elevation-2 style="width:200px; height:200px;" src="/foto_profile/<?= user()->foto; ?>">                                
               </div>
               <p>
               <div class="card-footer text-info">                                                        
                <center>
                <b><?= user()->fullname; ?></b><br>
                <b><?= user()->username; ?></b><br>
                <small>Member since <?= user()->created_at; ?></small>
                <h6 class="widget-user-desc"><i>On Stage</i> : <b>FM</b></h6>            
                
               <p>
   <button type="button" class="btn btn-info mt-3" data-toggle="modal" data-target="#modal-xl">Detail Profile</button>
   </p>
             </center>                
               </div> 
               <!-- /.footer -->  
               </div>
                  </div>         
               <!-- /.col -->                 
               
       <div class="modal fade" id="modal-xl">
        <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">My Profile</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
            
            <!-- Profile Image -->
            <div class="card card-info card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                  <img class="profile-user-img img-fluid img-circle bg-info"
                       src="<?= base_url('foto_profile/' .user()->foto); ?>"
                       alt="User profile picture">
           </div>
                <center>
                <h3 class="profile-username text-center text-info">
                <?= user()->fullname; ?></h3>
                <h4><?= user()->username; ?>  </h4>                             
                <small>Member since <?= user()->created_at; ?></small>
              <h6 class="widget-user-desc">Stage : 
              <span class="badge badge-info">FM</span></h6>
                </center>

                <ul class="list-group list-group-unbordered mb-3">
                 <li class="list-group-item">
                  <i class="fas fa-mobile-alt text-info mr-1"></i>
                    <b>Telepon</b> <a class="float-right"><?= user()->telp; ?></b></a>
                  </li>
                  <li class="list-group-item">
                  <i class="fas fa-envelope-open-text text-info mr-1"></i>
                    <b>Email</b> <a class="float-right"><?= user()->email; ?></b></a>
                  </li>                  
                </ul>

                </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

            
    <!-- Data Sponsor-->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Your Sponsor</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <strong><i class="fas fa-user text-info mr-1"></i>Sponsor Anda</strong>
                <a class="float-right">
                <?= user()->sponsor; ?>
                </a>
                <hr>
                <strong><i class="fas fa-mobile-alt text-info mr-1"></i>
                   Telp/WA Sponsor</strong>
                <a class="float-right"><?= user()->telp_sponsor; ?></a>             
                
               </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card-info-->
            
    <center>
   
    <button class="btn btn-info mb-3" data-dismiss="modal" aria-label="Close"><b>Cocok..?</b></button>
    <a href="/users/edit/<?= user()->id; ?>" class="btn btn-warning mb-3"><b>Edit?</b></a>
    </center>
            
            </div> 
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->
      