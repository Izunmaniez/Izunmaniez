<?= $this-> extend('administrator/template/index'); ?>

<?= $this-> section('content'); ?>  

               
<?= $this-> include('users/template/topbar'); ?>

<?= $this-> include('users/template/sidebar'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
  
<center><img src="/aset/img/userDashboard/pin.png" style="width:150px;"><br>
<button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-xl-orderPin"><b>ORDER PIN</b></button>
</center>
   
  <br>
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <h1>PIN UPGRADE</h1>
          </div>
          </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">  
               <div class="card-header bg-info">
                 <h2 class="card-title">WOOD</h2>
               </div>               
              <div class="card-body">
                <table class="table table-bordered table-responsive">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Tanggal</th>
                    <th>Kode PIN</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>1</td>
                    <td>1 Jan 2022</td>                   
                    <td>UWAbc1234567xyz</td>
                    <td><a class="badge badge-success text-light">Ready</td>
                  </tr>                
                  </tbody>
                  </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->                        
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  
       <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">  
               <div class="card-header bg-info">
                 <h2 class="card-title">SILVER</h2>
               </div>               
              <div class="card-body">
                <table class="table table-bordered table-responsive">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Tanggal</th>
                    <th>Kode PIN</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>1</td>
                    <td>1 Jan 2022</td>                   
                    <td>USAbc1234567xyz</td>
                    <td><a class="badge badge-danger text-light">Used</td>
                  </tr>                
                  </tbody>
                  </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->                        
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">  
               <div class="card-header bg-info">
                 <h2 class="card-title">GOLD</h2>
               </div>               
              <div class="card-body">
                <table class="table table-bordered table-responsive">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Tanggal</th>
                    <th>Kode PIN</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>1</td>
                    <td>1 Jan 2022</td>                   
                    <td>UGAbc1234567xyz</td>
                    <td><a class="badge badge-danger text-light">Used</td>
                  </tr>                
                  </tbody>
                  </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->                        
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">  
               <div class="card-header bg-info">
                 <h2 class="card-title">PLATINUM</h2>
               </div>               
              <div class="card-body">
                <table class="table table-bordered table-responsive">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Tanggal</th>
                    <th>Kode PIN</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>1</td>
                    <td>1 Jan 2022</td>                   
                    <td>UPAbc1234567xyz</td>
                    <td><a class="badge badge-danger text-light">Used</td>
                  </tr>                
                  </tbody>
                  </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->                        
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">  
               <div class="card-header bg-info">
                 <h2 class="card-title">DIAMOND</h2>
               </div>               
              <div class="card-body">
                <table class="table table-bordered table-responsive">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Tanggal</th>
                    <th>Kode PIN</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>1</td>
                    <td>1 Jan 2022</td>                   
                    <td>UDAbc1234567xyz</td>
                    <td><a class="badge badge-danger text-light">Used</td>
                  </tr>                
                  </tbody>
                  </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->                        
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    
    <br>
  <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <h1>PIN RO</h1>
          </div>
          </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">  
               <div class="card-header bg-info">
                 <h2 class="card-title">PIN RO</h2>
               </div>               
              <div class="card-body">
                <table class="table table-bordered table-responsive">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Tanggal</th>
                    <th>Kode PIN</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>1</td>
                    <td>1 Jan 2022</td>                   
                    <td>ROAbc1234567xyz</td>
                    <td><a class="badge badge-success text-light">Ready</td>
                  </tr>                
                  </tbody>
                  </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->                        
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
      
<div class="modal fade" id="modal-xl-orderPin">
        <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Form Order PIN</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
           
<table>

<tr><td>Username</td>
<td>
<input type="text" class="form-control mb-2" id="username" name="username" value="<?= user()->username; ?>" readonly >
</td>
</tr> 

<tr><td>Pilih PIN</td>
<td>
                 <div class="row">
                    <div class="col-sm-12">
                      <!-- select -->
                      <div class="form-group">                       
                        <select class="form-control mb-2" id="" name="">
                          <option>PIN RO</option>
                          <option>PIN WOOD</option>
                          <option>PIN SILVER</option>
                          <option>PIN GOLD</option>  
                          <option>PIN PLATINUM</option>  
                          <option>PIN DIAMOND</option>           
                        </select>
                      </div>
                    </div>                   
                 </div>
</td>
</tr> 


<tr><td>Jumlah</td>
<td>
                 <div class="row">
                    <div class="col-sm-12">
                      <!-- select -->
                      <div class="form-group">                       
                        <select class="form-control mb-2" id="" name="">
                          <option>Pilih Jumlah PIN</option>
                          <option>1</option>
                          <option>2</option>
                          <option>3</option>  
                          <option>4</option>  
                          <option>5</option>
                          <option>6</option>
                          <option>7</option>
                          <option>8</option>  
                          <option>9</option>  
                          <option>10</option> 
                          <option>11</option>
                          <option>12</option>
                          <option>13</option>  
                          <option>14</option>  
                          <option>15</option>        
                        </select>
                      </div>
                    </div>                   
                 </div>
</td>
</tr> 

<tr><td>Total Bayar</td>
<td>
<input type="text" class="form-control mb-2">
</td>
</tr> 


</table>                    
      
  <p><p>
                 <div class="modal-footer justify-content-around">
  <button class="btn btn-secondary pl-7" data-dismiss="modal" aria-label="Close"><b>Cancel</b></button>
  <a href="" type="button" class="btn btn-primary"><b>ORDER NOW</b></a>
                  </div>        
                </div>
            </div>
              <!-- /.card -->          
      </div><!-- /.container-fluid -->
  </div>

  </div>
  <!-- /.content-wrapper -->
 

<?= $this-> endSection(); ?>  

    
