<?= $this-> extend('administrator/template/index'); ?>

<?= $this-> section('content'); ?>  

               
<?= $this-> include('users/template/topbar'); ?>

<?= $this-> include('users/template/sidebar'); ?>

  <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
       <center> <img src="/aset/img/userDashboard/sedekah2.png" style="width:300px;"> <br>
            <div class="btn btn-info" data-toggle="modal" data-target="#sedekah">Sedekah Sekarang</div>
            <a href="/platform/empathy" class="btn btn-info">Empathy Page</a>
          </center> <br> 
    
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">  
               <div class="card-header bg-info">
                 <h2 class="card-title">History Sedekah Saya</h2>
               </div>               
              <div class="card-body">
                <table id="example1" class="table table-bordered table-stripped">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Tanggal</th>
                    <th>Nominal</th>                   
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>1</td>
                    <td>1 Jan 2022</td>                   
                    <td>Rp. 5.000.000,-</td>
                    </tr>
                  <tr>
                    <td>2</td>
                    <td>1 Jan 2022</td>                   
                    <td>Rp. 5.000.000,-</td>
                    </tr>                 
                  </tbody>
                  <tfoot>
                  <tr>
                    <th colspan="2" class="text-center">Total</th>
                    <th>Rp. 10.000.000,-</th>                   
                  </tr>
                  </tfoot>
                </table>
              </div><!-- /.card-body -->             
            </div><!-- /.card -->          
          </div><!-- /.col -->                                 
        </div><!-- /.row -->       
      </div><!-- /.container-fluid -->    
    </section><!-- /.container-fluid -->    
  </div><!-- /.container-fluid -->    


        
<div class="modal fade" id="sedekah" tabindex="-1" role="dialog" aria-labelledby="sedekah" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content modal-content-bg">
                <div class="modal-header">
                <h1>Form Sedekah</h1>
                    <strong class="modal-title method-name text-white" id="exampleModalLabel"></strong>
                    <a href="javascript:void(0)" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </a>
                </div>
                <?= $this-> include('administrator/template/time'); ?>
                <div class="modal-body text-primary"><?= user()->fullname; ?></div>                     
                    
                <form action="#" method="post" class="register">
                    <input type="hidden" name="" value="">                    
                    <div class="modal-body">
                        <div class="form-group">
                            <input type="hidden" name="" class="edit-currency" value="">
                            <input type="hidden" name="" class="edit-method-code" value="">
                        </div>                            
                        <div class="form-group">
                                <label>Bonus Real Time</label>
                            <div class="input-group">
                                <input id="" type="text" class="form-control form-control-lg" name="" placeholder="0.00" required" readonly>
                            </div>
                        </div>
                    
                        <div class="form-group">
                                <label>Nominal Sedekah</label>
                            <div class="input-group">
                                <input id="" type="text" class="form-control form-control-lg" name="" placeholder="0.00" required autocomplete="off">
                            </div>
                        </div>
                        </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-md btn-danger" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-md btn-primary">Excute</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


<?= $this-> endSection(); ?>  