<aside class="main-sidebar sidebar-dark-info elevation-4">
    <!-- Brand Logo -->
    <a class="brand-link" href="/hhc">
      <img src="/aset/img/bar/logohhc.png" alt="Logo HHC" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light"><b>PT. HHC Indonesia</b></span>
    </a>
   
           <!-- Sidebar Platform HHC -->
          <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
            
              <i class="fas fa-window-restore"></i>
              <p>
               Platform HHC
                 <i class="right fas fa-angle-double-left"></i>              
              </p>
            </a>
            <ul class="nav nav-treeview">
              
              <li class="nav-item">
                <a href="/" class="nav-link">
                  <i class="nav-icon fas fa-home text-info"></i>
                  <p class="text-info"><b>Hapee</b></p>
                </a>
              </li>
              <li class="nav-item">
                <a href="/platform/swizh" class="nav-link">
                  <i class="nav-icon fas fa-home text-info"></i>
                  
                  <p class="text-info"><b>Swizh</b></p><b>
                </a>
              </li>
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="nav-icon fas fa-home text-info"></i>
                  <p>Shotoo</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="nav-icon fas fa-home text-info"></i>
                  <p>HeroPort</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="nav-icon fas fa-home text-info"></i>
                  <p>HeroAds</p>
                </a>
              </li>
                 <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="nav-icon fas fa-home text-info"></i>
                  <p>HeroMoX</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="nav-icon fas fa-home text-info"></i>
                  <p>HeroCX</p></b>
                </a>
              </li>
              <li class="nav-item">
                <a href="/platform/empathy" class="nav-link">
                  <i class="nav-icon fas fa-home text-info"></i>
                  <p class="text-info"><b>Empathy</b></p>
                </a>
              </li>
              <li class="nav-item">
                <a href="/platform/charger" class="nav-link">
                  <i class="nav-icon fas fa-home text-info"></i>
                  <p class="text-info"><b>Charger</b></p>
                </a>
              </li>
              <li class="nav-item">
                <a href="/platform/vichar" class="nav-link">
                  <i class="nav-icon fas fa-home text-info"></i>
                  <p class="text-info"><b>Vichar</p></b>
                </a>
              </li>
              </li>
            </ul>
          </nav>
   
        <!-- Sidebar Jenjang Karir -->
          <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
            
              <i class="fas fa-users"></i>
              <p>
                 Jenjang Karir
                 <i class="right fas fa-angle-double-left"></i>              
              </p>
            </a>
            <ul class="nav nav-treeview">
              
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-light"></i>
                  <p>WHITE MANAGER</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-warning"></i>
                  
                  <p>YELLOW MANAGER</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-success"></i>
                  <p>GREEN MANAGER</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-primary"></i>
                  <p>BLUE MANAGER</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-danger"></i>
                  <p>RED MANAGER</p>
                </a>
              </li>
                 <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-secondary"></i>
                  <p>BLACK MANAGER</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-light"></i>
                  <p>DIRECTOR</p>
                </a>
              </li>
              </li>
            </ul>
          </nav>
<!-- Sidebar Logout -->
  <div class="dropdown-divider"></div>
                 
<a href="/logout" class="brand-link" onclick="return confirm('Yakin ingin keluar dari halaman dashboard?');"  style="background-color:#800517; color:white;">
      <img src="/aset/img/bar/logout.png" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light"><b>Logout</b></span>
    </a>
               
              
      <!-- /.sidebar-menu -->
    
    <!-- /.sidebar -->

        </aside>
               
      
            
            
             