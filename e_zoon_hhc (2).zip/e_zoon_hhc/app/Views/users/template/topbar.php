<!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-info navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars text-light "></i></a>      
      </li>
    <li class="nav-item">
      <a class="nav-link" href="/users">
          <i class="fas fa-home text-light "></i>         
      </a>
     </li>
    </ul>


    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
     <!-- Messages Dropdown Menu -->
      <!-- Shopping Notifications Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" href="/hapee/invoice">         
       <i class="fas fa-shopping-cart text-light"></i>         
          <span class="badge badge-danger navbar-badge">7</span>
        </a>       
      </li>   
      
      <!-- Notifications Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="fas fa-bell text-light "></i>         
          <span class="badge badge-danger navbar-badge">15</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <span class="dropdown-header">15 Notifikasi</span>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-envelope mr-2"></i> 4 pesan baru
            <span class="float-right text-muted text-sm">3 mnt</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-users mr-2"></i> 8 pesan baru
            <span class="float-right text-muted text-sm">12 jam</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-file mr-2"></i> 3 laporan baru
            <span class="float-right text-muted text-sm">2 hari</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item dropdown-footer">Lihat semua notifikasi</a>
        </div>
      </li>   
      
      <li class="nav-item dropdown">
      <a class="nav-link" href="/logout" onclick="return confirm('Yakin ingin keluar dari halaman dashboard?');">         
      <i class="fas fa-sign-out-alt text-light"></i>         
      </a>       
      </li>   
      
      </ul>
     </nav> 