<?= $this-> extend('administrator/template/index'); ?>

<?= $this-> section('content'); ?>  

               
<?= $this-> include('users/template/topbar'); ?>

<?= $this-> include('users/template/sidebar'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">    
        <div class="row">  
         <?= $this-> include('administrator/template/time'); ?>      
          <div class="col-sm-6 mt-2">   
            <div class="text-primary"><?= user()->fullname; ?><br>
            Username : <?= user()->username; ?>
            </div>
            <br>
            <h1>BONUS MINGGUAN</h1>
          </div>
          </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">  
               <div class="card-header bg-info">
                 <div class="float-right text-dark">
                    <div class="badge badge-light">DIAMOND
                    </div>
                 </div>
                 <h2 class="card-title">BONUS UPGRADE</h2>
               </div>               
              <div class="card-body">
                <table id="example1" class="table table-bordered table-stripped">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Tanggal</th>
                    <th>Total Bonus</th>
                    <th>Bonus Upgrade Referal</th>
                    <th>Bonus Pairing</th>
                    <th>Bonus Bulanan</th>
                    <th>Tax 5℅</th>
                    <th>Sedekah Saya</th>
                    <th>Bonus Ditransfer</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>1</td>
                    <td>1 Jan 2022</td>                   
                    <td>Rp. 15.000.000,-</td>
                    <td>Rp. 5.000.000,-</td>
                    <td>Rp. 5.000.000,-</td>
                    <td>Rp. 5.000.000,-</td>
                    <td>Rp. 750.000,-</td>
                    <td>Rp. 1.000.000,-</td>
                    <td><b>Rp. 13.250.000,-</b></td>
                    <td><a class="badge badge-success">Paid</td>
                  </tr>
                  
                  </tbody>
                  <tfoot>
                  <tr>
                    <th>#</th>
                    <th>Tanggal</th>
                    <th>Total Bonus</th>
                    <th>Bonus Upgrade Referal</th>
                    <th>Bonus Pairing</th>
                    <th>Bonus Bulanan</th>
                    <th>Tax 5℅</th>
                    <th>Sedekah Saya</th>
                    <th>Bonus Ditransfer</th>
                    <th>Status</th>
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->                        
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  
   <br>
   <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <h1>BONUS BULANAN</h1>
           <small>Ditransfer bersama Bonus Mingguan di minggu ke-4 setiap bulan.</small>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card"> 
             <div class="card-header bg-info">
               <div class="float-right text-dark">
                <div class="badge badge-light">DIAMOND
                </div>
               </div>
              <h2 class="card-title">BONUS PAKET</h2>            
             </div>         
              <div class="card-body">
                <table class="table table-bordered table-responsive">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Tanggal</th>
                    <th>Crazy Cashback</th>
                    <th>Voucher Hapee</th>
                    <th>Total Bonus</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>1</td>
                    <td>1 Jan 2022</td>                   
                    <td>Rp. 600.000,-</td>
                    <td>Rp. 600.000,-</td>
                    <td><b>Rp. 1.200.000,-</b></td>
                    <td><a class="badge badge-success">Paid</td>
                  </tr>                 
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->                        
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
   
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card"> 
             <div class="card-header bg-info">
               <div class="float-right text-dark">
                <div class="badge badge-light">WHITE MANAGER
                </div>
               </div>
              <h2 class="card-title">BONUS Hapee</h2>
             </div>         
              <div class="card-body">
                <table class="table table-bordered table-responsive">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Tanggal</th>
                    <th>Bonus JAPRI</th>
                    <th>Bonus JAREF</th>
                    <th>Bonus GPS</th>
                    <th>Total Bonus</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>1</td>
                    <td>1 Jan 2022</td>                   
                    <td>Rp. 1.000.000,-</td>
                    <td>Rp. 2.500.000,-</td>
                    <td>Rp. 1.500.000,-</td>
                    <td><b>Rp. 5.000.000,-</b></td>
                    <td><a class="badge badge-success">Paid</td>
                  </tr>                 
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->                        
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card"> 
             <div class="card-header bg-info">
               <div class="float-right text-dark">
                <div class="badge badge-light">WHITE MANAGER
                </div>
               </div>
              <h2 class="card-title">BONUS RO</h2>
             </div>         
              <div class="card-body">
                <table class="table table-bordered table-responsive">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Tanggal</th>
                    <th>Bonus JAPRI</th>
                    <th>Bonus SELPI</th>
                    <th>Bonus GENERASI</th>                   
                    <th>Total Bonus</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>1</td>
                    <td>1 Jan 2022</td>                   
                    <td>Rp. 1.000.000,-</td>
                    <td>Rp. 2.500.000,-</td>
                    <td>Rp. 500.000,-</td>
                    <td><b>Rp. 5.000.000,-</b></td>
                    <td><a class="badge badge-success">Paid</td>
                  </tr>                 
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->                        
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    
   <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card"> 
             <div class="card-header bg-info">
               <h1 class="card-title"><b>TOTAL BONUS BULANAN</b></h1>
              </div>         
              <div class="card-body">
                <table class="table table-bordered table-responsive">
                  <thead>
                  <tr>
                    <th>Bonus Paket</th>
                    <th>Bonus Hapee</th>
                    <th>Bonus RO Swizh</th>
                    <th>TOTAL BONUS</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>                                      
                    <td>Rp. 600.000,-</td>
                    <td>Rp. 900.000,-</td>
                    <td>Rp. 1.000.000,-</td>  
                    <td>Rp. 2.500.000,-</td> 
                    <td><a class="badge badge-success text-light">Paid</td>
                  </tr>                 
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->                        
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    
    <br>
   <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <h1>REWARD</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>      
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card"> 
             <div class="card-header bg-info">
               <div class="float-right text-dark">
                <div class="badge badge-light">WHITE MANAGER
                </div>
               </div>
              <h2 class="card-title">REWARD</h2>
             </div>         
              <div class="card-body">
                <table class="table table-bordered table-responsive">
                  <thead>
                  <tr>
                    <th>Reward</th>
                    <th>Syarat Omset</th>
                    <th>Omset Hapee</th>
                    <th>Omset RO Swizh</th>
                    <th>Total Omset</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>Null</td>                   
                    <td>Null</td>
                    <td>Null</td>
                    <td>Null</td>  
                    <td>Null</td>              
                    <td><a class="badge badge-secondary text-light">Null</td>
                  </tr>                 
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->                        
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    
  <br>
   <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <h1>BONUS TAHUNAN</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>      
  <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card"> 
             <div class="card-header bg-info">
               <div class="float-right text-dark">
                <div class="badge badge-light">WHITE MANAGER
                </div>
               </div>
              <h2 class="card-title">BONUS LEBARAN</h2>
             </div>         
              <div class="card-body">
                <table class="table table-bordered table-responsive">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Tanggal</th>
                    <th>Omset Nasional</th>
                    <th>Premium Member</th>
                    <th>Bonus Lebaran</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>1</td>
                    <td>1 Jan 2022</td>
                    <td>Rp. 112 Trilyun</td>                 
                    <td>1.000.000,-</td>
                    <td>11.000.000,-</td>
                    <td><a class="badge badge-success">Paid</td>
                  </tr>                 
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->                        
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    
      <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card"> 
             <div class="card-header bg-info">
               <div class="float-right text-dark">
                <div class="badge badge-light">WHITE MANAGER
                </div>
               </div>
              <h2 class="card-title">BONUS DIRECTOR</h2>
             </div>         
              <div class="card-body">
                <table class="table table-bordered table-responsive">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Tanggal</th>
                    <th>Bonus DIRECTOR</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>1</td>
                    <td>1 Jan 2022</td>                   
                    <td>Null</td>
                    <td><a class="badge badge-secondary text-light">Null</td>
                  </tr>                 
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->                        
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    
  </div>
  <!-- /.content-wrapper -->
  

<?= $this-> endSection(); ?>  

    
