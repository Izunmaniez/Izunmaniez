<div class="info-box elevation-3" data-toggle="modal" data-target="#modal-xl-voucher">
   <span class="info-box-icon bg-info"><img src="/aset/img/userDashboard/voucher.png"></i></span>
   <div class="info-box-content">
   <span class="info-box-text text-info"><h4>My Voucher</h4></span>
   </div>           
</div>   
            
<div class="modal fade" id="modal-xl-voucher">
   <div class="modal-dialog modal-xl-voucher">
       <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Voucher Saya</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">                
             <div class="card-header">
             <h6 class="text-center">Gunakan Voucher Saat Berbelanja di Market Place <b>Hapee</b></h6>
             </div> 
                
             <div class="card-header bg-info">
               <div class="float-right text-dark">
                <div class="badge badge-light">DIAMOND
                </div>
               </div>
              <h2 class="card-title">Voucher <b>Hapee</b></h2>            
             </div>         
              
                <table class="table table-bordered table-responsive">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Kode Voucher</th>
                    <th>Nilai Voucher</th>
                    <th>Sudah digunakan</th>
                    <th>Ready</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>1</td>
                    <td>hongilaheng123008</td>                   
                    <td>Rp. 600.000,-</td>
                    <td>Rp. 500.000,-</td>
                    <td>Rp. 100.000,-</td>
                  </tr>                 
                  </tbody>
                  <tfoot>
                  <tr class="bg-warning">
                    <th colspan="2" class="text-center">TOTAL</th>
                    <th>Rp. 600.000,-</th>
                    <th>Rp. 500.000,-</th>
                    <th>Rp. 100.000,-</th>
                  </tr>
                  </tfoot>
                </table>
              
                                                                         
    <center>
    <button class="btn btn-secondary mb-3" data-dismiss="modal" aria-label="Close"><b>Close</b></button>
    </center>
                             
         </div><!-- /.modal-body -->
      </div>
   </div>
</div>          