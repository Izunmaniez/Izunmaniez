<?= $this-> extend('administrator/template/index'); ?>

<?= $this-> section('content'); ?>  

               
<?= $this-> include('users/template/topbar'); ?>

<?= $this-> include('users/template/sidebar'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
        
         <?= $this-> include('administrator/template/time'); ?>
   
          <div class="col">
            <div class="text-primary"><?= user()->fullname; ?><br>
            Username : <?= user()->username; ?>
            </div>
            <br><br>
            <a href="" type="button" class="btn btn-info float-right"><b>Pohon Jaringan</b></a>                
            <button type="button" class="btn btn-info"><b>List Grup</b></button>                        
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">           
              <div class="card-body">
                <table id="example1" class="table table-bordered table-stripped">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Username</th>
                    <th>Peringkat</th>
                    <th>Paket</th>
                    <th>Sponsor</th>
                    <th>Upline</th>
                    <th>Tgl Join</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>1</td>
                    <td>Sukonto Legowo</td>
                    <td>GREEN MANAGER</td>
                    <td>DIAMOND</td>
                    <td>Neneknya</td>
                    <td>Bininya</td>
                    <td>12 Rabiul Awal</td>
                  </tr>                 
                  </tbody>
                  <tfoot>
                  <tr>
                    <th>#</th>
                    <th>Username</th>
                    <th>Peringkat</th>
                    <th>Paket</th>
                    <th>Sponsor</th>
                    <th>Upline</th>
                    <th>Tgl Join</th>
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  

<?= $this-> endSection(); ?>  

    
