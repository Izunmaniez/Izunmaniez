<div class="info-box elevation-3" data-toggle="modal" data-target="#modal-xl-bonus">
<span class="info-box-icon bg-info"><img src="/aset/img/userDashboard/harta.png"></i></span>
  <div class="info-box-content">
      <span class="info-box-text text-info"><h4>My Bonus</h4></span>
  </div>               
</div>  
             
<div class="modal fade" id="modal-xl-bonus">
   <div class="modal-dialog modal-xl-bonus">
       <div class="modal-content">
           <div class="modal-header">
            <h4 class="modal-title">Data Bonus Real Time</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
            </div>
            
            <?= $this-> include('administrator/template/time'); ?>  
            <span class="card-body text-primary"><?= user()->fullname; ?><br>Username : <?= user()->username; ?></span>         
                   
             <div class="modal-body">       
           <!-- Bonus Mingguan -->
           <div class="card-header">
           <h6 class="text-center">BONUS MINGGUAN</h6>
          <small><center>Ditransfer Setiap Hari Jum'at</center></small>
           </div>          
            <!-- Bonus Upgrade Swizh -->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">BONUS UPGRADE - Swizh</h3>
              </div>                    
              <div class="card-body">
                <strong>Upgrade Sponsor</strong>
                <a class="float-right">Rp. <?=number_format(user()->norek, 0, ".", "."); ?>,-
                </a>   
                <hr>
                <strong>Pairing</strong>
                <a class="float-right">Rp. <?=number_format(user()->norek, 0, ".", "."); ?>,-
                </a> 
                <hr>              
                <strong>Total</strong> 
                <button class="float-right btn-info elevation-7">Rp. <?=number_format(user()->norek, 0, ".", "."); ?>,-
                </button>  
                </div><!-- /.card-body -->             
            </div><!-- /.card-info-->  
            
            <!-- Bonus Bulanan -->
           <div class="card-header">
           <h6 class="text-center">BONUS BULANAN</h6>
          <small><center>Ditransfer Setiap Jumat di Minggu Ke-4</center></small>
           </div>
            <!-- Bonus Upgrade Swizh -->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">BONUS MARKET PLACE - Hapee</h3>
              </div>
              <div class="card-body">
                <strong>JAPRI</strong>
                <a class="float-right">Rp. <?=number_format(user()->norek, 0, ".", "."); ?>,-
                </a>               
                <hr>
                <strong>JASPON</strong>
                <a class="float-right">Rp. <?=number_format(user()->norek, 0, ".", "."); ?>,-
                </a>
                <hr>
                <strong>GPS</strong>
                <a class="float-right">Rp. <?=number_format(user()->norek, 0, ".", "."); ?>,-
                </a>  
                <hr>              
                <strong>Total</strong> 
                <button class="float-right btn-info elevation-7">Rp. <?=number_format(user()->norek, 0, ".", "."); ?>,-
                </button>  
                <hr><hr>
                <strong>Omset Reward</strong>
                <button class="float-right btn-warning elevation-7">Rp. <?=number_format(user()->norek, 0, ".", "."); ?>,-
                </button>                                                        
               </div><!-- /.card-body -->             
            </div><!-- /.card-info-->  
            
            <!-- Bonus Belanja Paket Swizh -->
            <div class="card card-info">
              <div class="card-header">
              <h3 class="card-title">BONUS PAKET</h3><a class="float-right badge badge-light text-dark">DIAMOND</a>
              </div>                    
              <div class="card-body">
                <strong>Crazy Cashback</strong>
                <a class="float-right">Rp. <?=number_format(user()->norek, 0, ".", "."); ?>,-
                </a>               
                </button>  
                <hr>
                <strong>Voucher Hapee</strong>
                <a class="float-right">Rp. <?=number_format(user()->norek, 0, ".", "."); ?>,-
                </a>  
                <hr>              
                <strong>Total</strong> 
                <button class="float-right btn-info elevation-7">Rp. <?=number_format(user()->norek, 0, ".", "."); ?>,-
                </button>                                                     
               </div><!-- /.card-body -->             
            </div><!-- /.card-info-->  
            
            <!-- Bonus RO Swizh -->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">BONUS RO - Swizh</h3>
              </div>                    
              <div class="card-body">
                <strong>JAPRI</strong>
                <a class="float-right">Rp. <?=number_format(user()->norek, 0, ".", "."); ?>,-
                </a>               
                <hr>
                <strong>SELPI</strong>
                <a class="float-right">Rp. <?=number_format(user()->norek, 0, ".", "."); ?>,-
                </a>
                <hr>
                <strong>GENERASI</strong>
                <a class="float-right">Rp. <?=number_format(user()->norek, 0, ".", "."); ?>,-
                </a>  
                <hr>              
                <strong>Total</strong> 
                <button class="float-right btn-info elevation-7">Rp. <?=number_format(user()->norek, 0, ".", "."); ?>,-
                </button>  
                <hr><hr>
                <strong>Omset Reward</strong>
                <button class="float-right btn-warning elevation-7">Rp. <?=number_format(user()->norek, 0, ".", "."); ?>,-
                </button> 
                </div><!-- /.card-body -->             
            </div><!-- /.card-info-->  
            
            <!-- Total Bonus Real Time -->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">TOTAL BONUS REAL TIME</h3>
              </div>                    
              <div class="card-body">
                <strong>MINGGUAN</strong>
                <a class="float-right">Rp. <?=number_format(user()->norek, 0, ".", "."); ?>,-
                </a>               
                <hr>
                <strong>BULANAN</strong>
                <a class="float-right">Rp. <?=number_format(user()->norek, 0, ".", "."); ?>,-
                </a>
                <hr>
                <strong>TOTAL BONUS</strong><br>
                <button class="btn-info elevation-7">Rp. <?=number_format(user()->norek, 0, ".", "."); ?>,-
                </button> 
                </a>  
                <hr>              
                <strong>TOTAL OMSET REWARD</strong><br>
                <button class="btn-warning elevation-7">Rp. <?=number_format(user()->norek, 0, ".", "."); ?>,-
                </button>  
                
                </div><!-- /.card-body -->             
            </div><!-- /.card-info-->  
             
    <center>
    <button class="btn btn-secondary mb-3" data-dismiss="modal" aria-label="Close"><b>Close</b></button>
    <a href="/users/bonusHistory" class="btn btn-info mb-3"><b>History</b></a>
    </center>
                             
         </div><!-- /.modal-body -->
      </div>
   </div>
</div>