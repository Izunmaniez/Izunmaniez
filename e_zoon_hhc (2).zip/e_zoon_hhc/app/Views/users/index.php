<?= $this-> extend('administrator/template/index'); ?>

<?= $this-> section('content'); ?>

 <?= $this-> include('users/template/topbar'); ?>
 
 <?= $this-> include('users/template/sidebar'); ?>
 

<div class="content-wrapper">
   <section class="content">

   <?= $this-> include('users/template/userProfile'); ?> 


     <div class="col-12 col-sm-6 mt-3">      
         <label class="text-info"><small><i>My Referral Link</i></small></label>
         <div class="input-group mb-3">
         <input type="text" name="text" class="form-control bg-info" id="copyText"
         value="<?= base_url(); ?>/register/<?= user()->username; ?>" readonly>
              <div class="input-group-append">
              <span class="input-group-text copytext copyBoard text-info" id="copyBtn"> <i class="fa fa-copy"></i> </span>
              </div>
         </div>              
         <a href="" class="info-box elevation-3">
         <span class="info-box-icon bg-info"><img src="/aset/img/userDashboard/qris.png"></i></span>
             <div class="info-box-content">
                <span class="info-box-text text-info"><h4>My QRIS Code</h4></span>
             </div>           
         </a>   
           
<div class="row">             
   <div class="col-6 col-sm-6 mt-3">                 
          <!-- small box -->
     <div class="small-box bg-light">
        <div class="inner">
           <a href="/users/myProduk"><img src="/aset/img/userDashboard/toko2.png"><br>My Shop</a>
        </div>
           <a href="/toko/index" class="small-box-footer bg-info">Cekidot..<i class="fas fa-arrow-circle-right"></i></a>
     </div>                   
   </div><!-- ./col -->   
          
   <div class="col-6 col-sm-6 mt-3">
            <!-- small box -->
     <div class="small-box bg-light">
       <div class="inner">
          <a href=""><img src="/aset/img/userDashboard/toko1.png"><br>My Referal Shop</a>
       </div>
          <a href="#" class="small-box-footer bg-info">Cekidot..<i class="fas fa-arrow-circle-right"></i></a>
     </div>
   </div><!-- ./col -->        
 </div><!-- ./row -->
   </div>                                                   
</div>
      
<!-- Small boxes (Stat box) -->     
<div class="row">
    <div class="col-12 col-sm-6 mt-3">   
        <?= $this-> include('users/template/bonusRealtime'); ?>  
        <?= $this-> include('users/template/voucher'); ?>  
               
            
                            
            <a href="/users/pin" class="info-box elevation-3">
              <span class="info-box-icon bg-info"><img src="/aset/img/userDashboard/pin.png"></i></span>
              <div class="info-box-content">
                <span class="info-box-text text-info"><h4>My PIN</h4></span>
             </div>           
            </a>   
            
            <a href="" class="info-box elevation-3">
              <span class="info-box-icon bg-info"><img src="/aset/img/userDashboard/keranjang.png"></i></span>
              <div class="info-box-content">
                <span class="info-box-text text-info"><h4>My Shopping</h4></span>
              </div>           
            </a>   
           
            <a href="/users/suedekah" class="info-box elevation-3">
              <span class="info-box-icon bg-info"><img src="/aset/img/userDashboard/sedekah.png"></i></span>
              <div class="info-box-content">
                <span class="info-box-text text-info"><h4>My Sedekah</h4></span>
              </div>           
            </a>                         
              
            <a href="/users/grup" class="info-box elevation-3">
              <span class="info-box-icon bg-info"><img src="/aset/img/userDashboard/grup.png"></i></span>
              <div class="info-box-content">
                <span class="info-box-text text-info"><h4>My Teams</h4></span>
             </div>           
            </a>                                           
       </div>
       
       <div class="col-12 col-sm-6 mt-3">                 
         <div class="card card-info card-tabs">
           <div class="card-header p-1 pt-0">
             <ul class="nav nav-tabs" id="custom-tabs-one-tab" role="tablist">
               <li class="nav-item">
               <a class="nav-link active" id="custom-tabs-one-home-tab" data-toggle="pill" href="#custom-tabs-one-home" role="tab" aria-controls="custom-tabs-one-home" aria-selected="true"><b>HOT News</b>                  
               </a>
               </li>
               <li class="nav-item">
               <a class="nav-link" id="custom-tabs-one-profile-tab" data-toggle="pill" href="#custom-tabs-one-profile" role="tab" aria-controls="custom-tabs-one-profile" aria-selected="false"><b>Previous News</b></a>
               </li>                  
             </ul>
           </div>
           <div class="card-body">
             <div class="tab-content" id="custom-tabs-one-tabContent">
               <div class="tab-pane fade show active" id="custom-tabs-one-home" role="tabpanel" aria-labelledby="custom-tabs-one-home-tab">
 <u><b> Grand Launching HHC Versi 4.2</u></b><br><br>
01 Nopember 2021. <br> Ngopi Bareng |<b> Swizh Coffee </b>
  <p>
                 <img src="/aset/img/produkHome/swizh.jpg" style="width:250px;"> 
                 <div class="col-12 mt-3">  
                   <a href="" class="info-box elevation-3">
                   <span class="info-box-icon bg-info"><i class="fas fa-share text-light"></i></span>
                   <div class="info-box-content">
                   <span class="info-box-text text-info"><h5>Share</h5></span>
                   <span class="info-box-number">1,410</span>
                   </div>           
                   </a>                             
                  </div>                                 
               </div>
                                               
               <div class="tab-pane fade" id="custom-tabs-one-profile" role="tabpanel" aria-labelledby="custom-tabs-one-profile-tab">
                    <u><b> PINTU SURGA</u></b><br><br>
Dimana pintu surga? Orangtua? Tahajjud? Memberi makan orang lain? Mengasihi fakir miskin? Zikrullah? Ridha pada takdir? Benar semua. Tapi ada 1 pintu surga yang kerap dilupakan: Pekerjaan.

Bayangkan, misalnya pada zaman Nabi, ada penjahit, ataupun tukang masak bagi Nabi saw. Semua pakaian Nabi saw adalah jahitan beliau, atau semua makanan Nabi saw adalah masakan beliau, bukan kah itu adalah pintu surga bagi orang itu? Sangat ya!

Demikian juga seluruh pekerjaan kita, itu semua bisa menjadi pintu surga bagi kita. Jadikanlah pekerjaan sebagai pintu surga. Jika kerja tak menjadi pintu surga, tinggalkan kerja itu, atau tinggalkan cara berpikir kita yang lama. Jadikan kerja sebagai pintu surga.
<br><br>
SS.YMU DANISH LUTHFI
14/09/2021
20:12 WIB                     
  <p>
                  <div class="col-12 mt-3">  
                    <a href="" class="info-box elevation-3">
                    <span class="info-box-icon bg-info"><i class="fas fa-share text-light"></i></span>
                    <div class="info-box-content">
                    <span class="info-box-text text-info"><h5>Share</h5></span>
                    <span class="info-box-number">1,410</span>
                    </div>  
                    </a>                                                
                  </div>                                   
                </div>                                       
              </div>
            </div>
          </div>
        </div><!-- /.card -->
                    
     <?= $this-> include('users/template/contactAdmin'); ?>

   </section><!-- /.content -->   
</div>  <!-- /.content-wrapper -->

<img style="width:100%; border-radius:2px; margin-bottom:0;" src="/aset/img/swizh/top.jpg">

<?= $this-> endSection(); ?>
  
  
  
  