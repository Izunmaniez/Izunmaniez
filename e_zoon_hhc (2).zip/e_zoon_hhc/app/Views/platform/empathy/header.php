<!-- scroll-to-top start -->
 <div class="scroll-to-top">
    <span class="scrolOl-icon">
        <i class="fas fa-rocket" aria-hidden="true"></i>
    </span>
 </div>
<!-- scroll-to-top end -->

<section class="hero bg_img" data-background="/aset/img/bgBlue/bg2.jpg">
   <div class="container">
      <div class="row">
         <div class="col-lg-5">
            <div class="hero__content">
               <div id="google_translate_element"></div>
                <script type="text/javascript">
                function googleTranslateElementInit() {
                  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
                }
                </script>
                <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
                     <h1 class="hero__title mt-2"><span class="text-white font-weight-normal"><b>Empathy HHC</b></span></h1>
            <h3><i class="base--color">Reservoir Donation Center</i></h3>
                                                       
               </div>
           </div>
        </div>      
   </div>     
</section>
<?= $this->include('platform/template/runningText');?>