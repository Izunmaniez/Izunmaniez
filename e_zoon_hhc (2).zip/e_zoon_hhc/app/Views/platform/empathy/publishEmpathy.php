
<?= $this-> extend('platform/template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this->include('platform/template/navbar');?>

<?= $this->include('platform/empathy/header');?>


<section class="pt-120 pb-120">
    <div class="container">
      <div class="row justify-content-center">
          <div class="col-lg-10">
<p>   

<h4>Tabel Cashflow Empathy HHC</h4>
<p><p><p>

<form action="" method="post">
<?= csrf_field(); ?> 

<div class="input-group mb-3">
  <input type="text" class="form-control" style="border-radius:5px;" placeholder="Cari data" name="keyword">
<div class="input-grup-append">
  <button class="cmn-btn" type="submit" name="submit">Cari</button>
</div>
</div>
</form>

            



<table class="table table-responsive" style="background-color:white; border-radius:5px;">
  <thead class="cmn-btn">
    <tr>
      <th>#</th>
        <th>Tanggal</th>
        <th>Donatur</th>
        <th>Donasi</th>
        <th>Disalurkan</th>
        <th>Volunteer</th>
        <th>Keterangan</th>
    </tr>
  </thead>
  <tbody>

  
 <?php $i=1 + (30 * ($currentPage - 1)); ?>

 <?php foreach ($djos as $dj) : ?>
 
 <?php 

  $donasi[] =$dj['masuk'];
  $disalurkan[] =$dj['keluar'];
?> 

    <tr> 
         <td><?=$i++; ?>  </td>
         <td><?=$dj['tanggal']; ?>  </td>
         <td><?=$dj['donatur']; ?>  </td>
         <td>Rp. <?=number_format ($dj['masuk'], 0, ".", "."); ?>,-  </td>
         <td>Rp. <?=number_format ($dj['keluar'], 0, ".", "."); ?>,-  </td>
         <td><?=$dj['volunteer']; ?>  </td>
         <td>
<div class="container">      
<div class="vmvm-item"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="ket" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i> lihat </i></a>

  <div class="dropdown-menu" style="background-color:#808000; color:white; text-align:center; padding:15px 15px 15px 35px;"  aria-labelledby="ket">
<p>
<p>
   
<?=$dj['keterangan']; ?>

<p><p><p><p>

<div class="btn btn-success">Aye..😄
</div><p><p>
</div>
</div>
</div>
</div>
 </td>
 
</tr> 
 
  
<?php endforeach; ?>   
       
</tbody>  
</table>



 <?= $pager->links('djos','djos_pagination'); ?> 

       </div>
     </div>
   </div>
</section>

<?php
    //total
    $total_donasi =array_sum($donasi);
    $total_disalurkan   =array_sum($disalurkan);
    $saldo =$total_donasi-$total_disalurkan;
?>

<!-- Content Wrapper. Contains page content -->

    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h3>Total Cashflow</h3>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Hari ini <?= date("d-m-Y"); ?>  </a></li>            
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

  <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
                
          <div class="col-xl-6 col-sm-6 mb-30">
                <div class="d-widget d-flex flex-wrap">
                  <div class="col-8">
                    <p>Total Donasi Rp.</p>
                <h5><sup style="font-size: 17px"><?=number_format ($total_donasi, 0, ".", "."); ?></sup></h5>               
             </div>
                  <div class="col-4">
                    <div class="icon ml-auto">
                      <i class="fas fa-dollar-sign"></i>
                    </div>
                  </div>
                </div><!-- d-widget-two end -->
              </div>                  
          
          <div class="col-xl-6 col-sm-6 mb-30">
                <div class="d-widget d-flex flex-wrap">
                  <div class="col-8">
                    <p>Total Disalurkan Rp.</p>
                <h5><sup style="font-size: 17px"><?=number_format ($total_disalurkan, 0, ".", "."); ?></h5>
                </div>
                  <div class="col-4">
                    <div class="icon ml-auto">
                      <i class="fas fa-dollar-sign"></i>
                    </div>
                  </div>
                </div><!-- d-widget-two end -->
              </div>          
           
          <div class="col-xl-6 col-sm-6 mb-30">
                <div class="d-widget d-flex flex-wrap">
                  <div class="col-8">
                    <p>Saldo Rp.</p>
                <h5><sup style="font-size: 17px"><?=number_format ($saldo, 0, ".", "."); ?></h5>
                  </div>
                  <div class="col-4">
                    <div class="icon ml-auto">
                      <i class="fas fa-dollar-sign"></i>
                    </div>
                  </div>
                </div><!-- d-widget-two end -->
              </div>
              
              <div class="col-xl-6 col-sm-6 mb-30" data-toggle="modal" data-target="#donasi">
                <div class="d-widget d-flex flex-wrap">
                  <div class="col-8">
                    DONASI SEKARANG
                   </div>
                  <div class="col-4">
                    <div class="icon ml-auto">
                      <i class="fas fa-dollar-sign"></i>
                    </div>
                  </div>
                </div><!-- d-widget-two end -->
              </div>                                       
</div>
</div>


        
<div class="modal fade" id="donasi" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content modal-content-bg">
                <div class="modal-header">
                    <strong class="modal-title method-name text-white" id="exampleModalLabel"></strong>
                    <a href="javascript:void(0)" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </a>
                </div>
                <form action="#" method="post" class="register">
                    <input type="hidden" name="" value="">                    
                    <div class="modal-body">
                        <div class="form-group">
                            <input type="hidden" name="" class="edit-currency" value="">
                            <input type="hidden" name="" class="edit-method-code" value="">
                        </div>
                        <div class="form-group">
                                <label>Nominal Donasi:</label>
                            <div class="input-group">
                                <input id="" type="text" class="form-control form-control-lg" name="" placeholder="0.00" required autocomplete="off">
                                <div class="input-group-prepend">
                                    <span class="input-group-text currency-addon addon-bg">IDR</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-md btn-danger" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn-md cmn-btn">Next</button>
                    </div>
                </form>
            </div>
        </div>
    </div>



<?= $this-> endSection(); ?>










