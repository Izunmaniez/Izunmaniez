<?= $this-> extend('platform/template/index'); ?>

<?= $this-> section('content'); ?>

<?= $this->include('platform/template/navbar');?>
<?= $this->include('platform/empathy/header');?>

<div class="container mt-27 text-center">
<br>
<h4>Dokumentasi Empathy - HHC</h4>
<br><br>

    
      <form action="" method="post" enctype="multipart/form-data">
 <?= csrf_field(); ?> 
 
          
      <?php foreach ($djosdok as $dok) : ?>  
          
            <div class="col-12 col-sm-6 mb-5">          
             <center> <h3 class="d-inline-block "><?=$dok['judul']; ?></h3></center>
              <div class="col-12">
                <img src="/aset/img/dokumenDjos/<?=$dok['foto']; ?>" class="product-image" style="border-radius:7px;" alt="Dok. DJOS">
              </div>
              <small class="float-right"><i>posted : <?=$dok['created_at']; ?></i></small>
              <h6 class="d-inline-block"><?=$dok['ket']; ?></h6>
             </div>
             
    <?php endforeach; ?>   
                                               
                  </form>
                  
                  
    </div>   
     
              
<?= $this-> endSection(); ?>