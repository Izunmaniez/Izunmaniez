<?= $this-> extend('platform/template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this->include('platform/template/navbar');?>

<?= $this->include('platform/empathy/header');?>

         <section>
            <div class="row">                
                 <div class="col-lg-12 col-md-12 col-sm-12 mb-4 mt-1">
                    <div class="card">
                        <div class="card-body" data-background="/aset/img/bgBlue/bg3.jpg">
                            <div class="row justify-content-center">
                                <div class="col-sm-12">
<?= $this->include('platform/empathy/slider');?>  
                                </div>
                                <div class="col-md-7 col-sm-12">
                                    <ul class="list-group text-center">
                                        <li class="list-group-item">
                                         Rekening Donasi
                                        </li>
                                        <li class="list-group-item">
                                        Bank BRI <b>032301001983306</b>
                                        </li>
                                        <li class="list-group-item">
                                        an. <b>HHC</b>
                                        </li>

                                        <li class="list-group-item">
                                            <button type="button"  
                                            data-base_symbol=""
                                            class=" btn deposit cmn-btn w-100" data-toggle="modal" data-target="#exampleModal">
                                        Donasi Sekarang</button>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
             </section>

        
<section>
  <div class="bar-djos">
    <div class="pb-120">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-12 pl-lg-5 mt-lg-0 mt-5">
            <div class="row mb-none-30">
              
              <div class="col-xl-6 col-sm-6 mb-30">
                <div class="d-widget d-flex flex-wrap">
                  <div class="col-8">
                    <a href="/platform/publishEmpathy"><h4>Cashflow Donasi</h4></a>
                  </div>
                  <div class="col-4">
                    <div class="icon ml-auto">
                      <i class="fas fa-dollar-sign"></i>
                    </div>
                  </div>
                </div><!-- d-widget-two end -->
              </div>
              
              <div class="col-xl-6 col-sm-6 mb-30">
                <div class="d-widget d-flex flex-wrap">
                  <div class="col-8">
                    <a href="/users"><h4>Cek Bonus & Donasi Saya</h4></a>
                  </div>
                  <div class="col-4">
                    <div class="icon ml-auto">
                      <i class="fas fa-wallet"></i>
                    </div>
                  </div>
                </div><!-- d-widget-two end -->
              </div>                            
              
              <div class="col-xl-6 col-sm-6 mb-30">
                <div class="d-widget d-flex flex-wrap">
                  <div class="col-8">
                    <a href="/platform/galeryEmpathy"><h4>Galery Empathy</h4></a>
                  </div>
                  <div class="col-4">
                    <div class="icon ml-auto">
                      <i class="fas fa-file-image"></i>
                    </div>
                  </div>
                </div><!-- d-widget-two end -->
              </div>
              
              <div class="col-xl-6 col-sm-6 mb-30">
                <div class="d-widget d-flex flex-wrap">
                  <div class="col-8">
                    <a href="#"><h4>Dokumentasi Video</h4></a>
                  </div>
                  <div class="col-4">
                    <div class="icon ml-auto">
                      <i class="fas fa-file-video"></i>
                    </div>
                  </div>
                </div><!-- d-widget-two end -->
              </div>
              
              <div class="col-xl-6 col-sm-6 mb-30" data-toggle="modal" data-target="#team_profile">
                <div class="d-widget d-flex flex-wrap">
                  <div class="col-8">
                    <a href="#"><h4>Tim Manajemen Empathy</h4></a>
                  </div>
                  <div class="col-4">
                    <div class="icon ml-auto">
                      <i class="fas fa-users"></i>
                    </div>
                  </div>
                </div><!-- d-widget-two end -->
              </div>
              
              <div class="col-xl-6 col-sm-6 mb-30" data-toggle="modal" data-target="#sumber_donasi"  >
                <div class="d-widget d-flex flex-wrap">
                  <div class="col-8">
                    <a href="#"><h4>Potensi Sumber Donasi</h4></a>
                  </div>
                  <div class="col-4">
                    <div class="icon ml-auto">
                      <i class="fas fa-cubes"></i>
                    </div>
                  </div>
                </div><!-- d-widget-two end -->
              </div>  
                           
            </div><!-- row end -->
         </div>
        </div>
      </div>
    </div>
  </div>         
</section>          
        
            
        
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content modal-content-bg">
                <div class="modal-header">
                    <strong class="modal-title method-name text-white" id="exampleModalLabel"></strong>
                    <a href="javascript:void(0)" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </a>
                </div>
                <form action="#" method="post" class="register">
                    <input type="hidden" name="" value="">                    
                    <div class="modal-body">
                        <div class="form-group">
                            <input type="hidden" name="" class="edit-currency" value="">
                            <input type="hidden" name="" class="edit-method-code" value="">
                        </div>
                        <div class="form-group">
                                <label>Nominal Donasi:</label>
                            <div class="input-group">
                                <input id="" type="text" class="form-control form-control-lg" name="" placeholder="0.00" required autocomplete="off">
                                <div class="input-group-prepend">
                                    <span class="input-group-text currency-addon addon-bg">IDR</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-md btn-danger" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn-md cmn-btn">Next</button>
                    </div>
                </form>
            </div>
        </div>
    </div>





<section>
 <div class="modal fade" id="team_profile">
    <div class="modal-dialog">
      <div class="modal-content text-center">      
        <div class="modal-body">
        
<h2>Dewan Pengurus Pusat</h2>
<h4>Empathy - HHC</h4>
<div class="penasehat-djos" >
<div class="personil-djos">
<img src="/aset/img/teamDjos/miswan.png"> 
  <h6>Syech Miswan Alsambahuta</h6>
  Penasehat
</div>
</div>

<div class="pembina-djos">
<div class="personil-djos"><img src="/aset/img/teamDjos/suriono.png">
  <h6>Suriono</h6>
  Ketua Pembina
</div>
</div>

<div class="pembina-djos">
<div class="personil-djos"><img src="/aset/img/teamDjos/suprapto.png">
  <h6>Suprapto</h6>
  Pembina
</div>
  
<div class="personil-djos"><img src="/aset/img/teamDjos/aris.png">
  <h6>MH Siahaan</h6>Pembina
</div>
 
<div class="personil-djos"><img src="/aset/img/teamDjos/muliadi.png">
  <h6>Muliadi</h6>Pembina
</div>
</div>

<div class="penasehat-djos">
<div class="personil-djos"><img src="/aset/img/teamDjos/kuswito.png">
  <h6>Kuswito MH. FH</h6>
  Ketua Pelaksana
  </div>
</div>

<div class="pembina-djos">
<div class="personil-djos"><img src="/aset/img/teamDjos/ridho.png">
  <h6>Ridho A.G.S</h6>Sekretaris
</div>

<div class="personil-djos"><img src="/aset/img/teamDjos/dedy.png">
  <h6>Pranoto Dedy</h6>Bendahara
</div>
</div>


<p><br><br><br>
<h4>CORE VOLUNTEERS</h4>
<h5>(CV/Relawan Inti)</h5>
CV siap sedia melayani proses dan informasi donasi dan penyalurannya  kapanpun & dimanapun.


<div class="volunteer-djos" style="background-color:#667C26;">
  
<div class="personil-djos"><img src="/aset/img/teamDjos/adiono.png">
  <h6>Adiono</h6>Asahan-Sumut</div>
  
<div class="personil-djos"><img src="/aset/img/teamDjos/mardany.png">
  <h6>Mardany</h6>Rantau Parapat - Sumut</div>

<div class="personil-djos"><img src="/aset/img/teamDjos/acuk.png">
  <h6>Kamaluddin</h6>Asahan-Sumut</div>
  
<div class="personil-djos"><img src="/aset/img/teamDjos/sarwo.png">
  <h6>Sarwo Edy Rambe</h6>Asahan - Sumut</div>
  
<div class="personil-djos"><img src="/aset/img/teamDjos/ali.png">
  <h6>Ali Jaya Wiguna</h6>Asahan-Sumut</div>
  
<div class="personil-djos"><img src="/aset/img/teamDjos/alif.png">
  <h6>Alif CDF</h6>Asahan-Sumut</div>
  
<div class="personil-djos"><img src="/aset/img/teamDjos/hendri.png">
  <h6>Suhendri</h6>Asahan-Sumut</div>
  
<div class="personil-djos"><img src="/aset/img/teamDjos/obenk.png">
  <h6>Zainal Aripin</h6>Asahan-Sumut</div>
  
<div class="personil-djos"><img src="/aset/img/teamDjos/lilik.png">
  <h6>Ponidi Lilik</h6>Asahan - Sumut</div>
  
<div class="personil-djos"><img src="/aset/img/teamDjos/hendro.png">
  <h6>Hendro</h6>Asahan - Sumut</div>

<div class="personil-djos"><img src="/aset/img/teamDjos/iwan.png">
  <h6>Iwan Surbakti</h6>Asahan - Sumut</div>

<div class="personil-djos"><img src="/aset/img/teamDjos/nazir.png">
  <h6>Mhd. Nazir</h6>Asahan - Sumut</div>
  
<div class="personil-djos"><img src="/aset/img/teamDjos/hasan.png">
  <h6>Hasan Basri</h6>Asahan - Sumut</div>
  
<div class="personil-djos"><img src="/aset/img/teamDjos/didik.png">
  <h6>Didiek Pramudytha</h6>Asahan - Sumut</div>

<div class="personil-djos"><img src="/aset/img/teamDjos/ipin.png">
  <h6>M. Arifin Srg</h6>Asahan - Sumut</div>

</div>
<hr>
<div class="pembina-djos" style="background-color:white; color:black;" >
<div class="personil-djos"><img src="/aset/img/manager/izun.jpg">
  <h6>Nur Alfaizun</h6>Web Developer</div>

<div class="personil-djos"><img src="/aset/img/manager/indra.jpg">
  <h6>Indra Scout.</h6>Web Administrator</div>
</div>

</div>



        <div class="modal-footer">
          <button type="button" class="btn btn-success" data-dismiss="modal">Aye..😀😄</button>
        </div>      
      </div>
    </div>
  </div>
</div>
</section>

<section>
  <div class="modal fade" id="sumber_donasi" style="z-index:9999;">
    <div class="modal-dialog">
      <div class="modal-content">      
        <div class="modal-body">


<h5>Potensi sumber dana Empathy HHC berasal dari :</h5>

1. Masyarakat Umum
<p>

2. Member HHC
<br> Fitur donasi juga akan disediakan didalam setiap akun/walet member.
</p>

3. Monetisasi chanel youtube 
<br>
- <a href="https://www.youtube.com/channel/UChczBosBiGwtDBJxDgAfGXw">Vichar</a>
<br>
Dengan hanya nonton, like, comment & share video di chanel youtube <a href="https://www.youtube.com/channel/UChczBosBiGwtDBJxDgAfGXw">Vichar</a>
berpotensi menghasilkan nilai ibadah ubudiyah bagi Anda karena hasilnya 100% akan disalurkan ke Panti Asuhan, Panti Jompo, Door to door atau Langsung aksi lapangan/jalanan melalui Platform Empathy HHC. Kami juga membuka peluang ubudiyah bagi member yang memiliki skill sebagai content creator video yang bernilai positif dan mendukung Visi, Misi & Value <a href="/hhc">HHC</a> untuk turut berkontribusi mengembangkan chanel youtube <a href="https://www.youtube.com/channel/UChczBosBiGwtDBJxDgAfGXw">Vichar</a></p>
    
4. Alokasi Dana Sosial dari Profitly <a href="/hhc">Platform HHC</a>
</p>

5. Instansi/Perusahaan Lainnya
 </p>
    
6. Instansi Pemerintah.
<p><p>

Demi menjaga integritas kita bersama, informasi saldo, sumber dana dan penyalurannya akan dipubikasikan secara transparan di halaman situs <a href="/djos">ini.</a>

        <div class="modal-footer">
          <button type="button" class="btn btn-success" data-dismiss="modal">Aye..?!!</button>
        </div>      
      </div>
    </div>
  </div>
</section>         



  




<?= $this-> endSection(); ?>
