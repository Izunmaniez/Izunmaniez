<?= $this-> extend('platform/template/index'); ?>
<?= $this-> section('content'); ?>
<?= $this-> include('platform/template/navbar'); ?>
<?= $this-> include('platform/template/headerAbout'); ?>
<?= $this-> include('platform/template/runningText'); ?>
<?= $this-> include('platform/template/toTop'); ?>
<?= $this-> include('platform/template/vision'); ?>
<?= $this-> include('platform/template/platform'); ?>
<?= $this-> include('platform/template/bod'); ?>
<?= $this-> include('platform/template/legal'); ?>
<?= $this-> include('platform/template/partner'); ?>    
<?= $this-> include('platform/template/top'); ?>    
<?= $this-> endSection(); ?>


