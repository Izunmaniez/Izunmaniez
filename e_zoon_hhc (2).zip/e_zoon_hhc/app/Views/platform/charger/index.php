<?= $this-> extend('platform/template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this->include('platform/template/navbar');?>

<?= $this->include('platform/template/headerCharger');?>
 
<div class="container mb-5">          

 <?= $this->include('platform/charger/slider_charger');?>    
 
<i>Character Generating.</i>
Member tidak hanya berpotensi memperoleh manfaat yang luar biasa secara financial. Beberapa kegiatan-kegiatan Pelatihan Character Building yang disediakan GRATIS baik secara online maupun offline - langsung Tim Character Generator (Charger) turun ke lapangan mengadakan acara pelatihan-pelatihan di daerah-daerah yang memenuhi syarat & kuota jumlah member HHC. Ditambah lagi ada program khusus (eksklusif) Wisata Training Tour bagi member yang berprestasi lebih..

</div>


<?= $this-> endSection(); ?>