 <section class="mt-50">      
   <div class="row justify-content-center">
      <div class="paket">
        <div class="container">
          <div class="col-lg-6 text-center mb-2">      
          <h2>BONUS <b>Hapee</b></h2>
          (Belanja di Market Place - Bonus Bulanan)
          </div>                 
       </div>
     </div>
  </div><!-- row end -->
      
       <div class="row mb-30 justify-content-center ">           
         <div class="col-xl-3 col-lg-6 col-md-6 mb-30 wow zoomout" data-wow-duration="3s" style="visibility: visible; animation-duration: 5s; animation-name: bounceIn;">
            <div class="package-card text-center bg-dark">                      
    <?= $this->include('platform/swizh/sliderBonusHapee');?>
                     
             <div class="package-card__features mt-4">         
                <b>Bonus belanJA REferal (JARE)
                <h4 class="package-card__features base--color">10℅</h4></b>
                <b>Bonus Get Pro Seller (GPS)               
                <h4 class="package-card__features base--color">5℅</h4></b>
                <b>Bonus Lebaran (THR)
                <h4><span class="package-card__features base--color">10℅</h4></span>
                dari (PV) Omset Market Place.</b>                                         
                <b> 
                   
              <div class="package-card__features mt-3">Seluruh<b> Omset Anda dan Grup Anda</b> di Market Place akan terakumulasi dan terintegrasi dengan omset yang ada di Business Plan <a href="#"><b><span class="base--color">Swizh</span></b></a> dalam sistem perhitungan kwalifikasi Reward.               
              </div>
                 </b>
               </div>
             </div>   
          </div><!-- col end -->                                                                                                                           
        </div><!-- row end -->   
   </section>