 <section class="mt-50">      
   <div class="row justify-content-center">
      <div class="paket">
        <div class="container">
          <div class="col-lg-6 text-center mb-2">      
          <h2>BONUS <b>KEHORMATAN</b></h2>
          Khusus Untuk Para LEADERSHIP DIRECTOR
          </div>                 
       </div>
     </div>
  </div><!-- row end -->
      
  <div class="row mb-30 justify-content-center ">           
      <div class="col-xl-3 col-lg-6 col-md-6 mb-30 wow zoomout" data-wow-duration="3s" style="visibility: visible; animation-duration: 5s; animation-name: bounceIn;">
         <div class="package-card text-center bg-dark">   
             <h3 class="cmn-btn mb-2"><b> LEADERSHIP<br>DIRECTOR</b></h3>                  
             <div class="package-card__features mt-4">         
                LEADERSHIP DIRECTOR (Direktur Kepemimpinan) adalah Peringkat Kehormatan yang diberikan oleh Perusahaan HHC kepada para BLACK MANAGER yang telah berhasil meraih semua Reward. Para LEADERSHIP DIRECTOR akan dianggap sebagai salah satu pemegang Saham Perusahaan HHC sebesar <span class="base--color"><b>10%</b></span> dan ikut serta dalam RUPS (Rapat Umum Pemegang Saham) berikut Pembagian Dividen dalam periode Tahunan.              
             </div>             
           </div>
         </div><!-- col end -->                                                                                                                           
     </div><!-- row end -->  
 </section>
   
 <div class="row justify-content-center">
     <div class="container">
         <div class="col-lg-6 text-center mb-2">      
          <a href="<?= route_to('login') ?>" class="cmn-btn text-uppercase font-weight-600 mb-50">Upgrade Now</a>
          <a href="<?= route_to('register') ?>" class="cmn-btn text-uppercase font-weight-600 mb-50">Sign Up</a>                         
          </div>                 
       </div>
 </div><!-- row end -->