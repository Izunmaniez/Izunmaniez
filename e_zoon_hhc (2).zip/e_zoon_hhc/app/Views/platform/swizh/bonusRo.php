<section class="mt-50">      
   <div class="row justify-content-center">
      <div class="paket">
        <div class="container">
          <div class="col-lg-6 text-center mb-2">      
          <h2>BONUS Plan RO</h2>
          (Repeat Order - Bonus Bulanan)
          </div>                 
       </div>
     </div>
  </div><!-- row end -->

  <div class="row mb-30 justify-content-center ">           
      <div class="col-xl-3 col-lg-6 col-md-6 mb-30 wow zoomout" data-wow-duration="3s" style="visibility: visible; animation-duration: 5s; animation-name: bounceIn;">
         <div class="package-card text-center bg-dark">                      
    <?= $this->include('platform/swizh/sliderRo');?>          
           </div>   
       </div><!-- col end -->                                                                                                                           
   </div><!-- row end -->   
</section>