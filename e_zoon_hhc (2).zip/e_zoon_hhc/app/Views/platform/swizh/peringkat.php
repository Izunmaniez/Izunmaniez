<section class="pt-120 pb-120">
     <div class="row justify-content-center">
        <div class="col">  
<div class="row justify-content-center">
      <div class="paket">
        <div class="container">
          <div class="col-lg-6 text-center mb-2">      
          <h2>PERINGKAT</h2>
          </div>                 
       </div>
     </div>
  </div><!-- row end -->


<table class="table table-responsive" style="background-color:white; border-radius:5px;">
  <thead class="cmn-btn text-center">
    <tr>     
      <th>Peringkat</th>
      <th>Syarat</th>            
    </tr>
  </thead>
  <tbody>
    <tr> 
      <td><b>WHITE MANAGER</b></td>
      <td>Pilih salah satu Paket Belanja Produk Swizh</td>
    </tr>       
    <tr> 
      <td><b>YELLOW MANAGER</b></td>
      <td>Mensponsori Minimal 10 White Manager</td>
    </tr>       
    <tr> 
      <td><b>GREEN MANAGER</b></td>
      <td>Memiliki Minimal 2 Jalur Sponsorship Yellow Manager Peraih Reward Smart Phone</td>
    </tr>
    <tr> 
      <td><b>BLUE MANAGER</b></td>
      <td>Memiliki Minimal 2 Jalur Sponsorship Green Manager Peraih Reward Motor</td>
      </tr>
    <tr> 
      <td><b>RED MANAGER</b></td>
      <td>Memiliki Minimal 2 Jalur Sponsorship Blue Manager Peraih Reward Family Car</td>
    </tr>  
    <tr> 
      <td><b>BLACK MANAGER</b></td>
      <td>Memiliki Minimal 2 Jalur Sponsorship Red Manager Peraih Reward Luxury Car</td>
    </tr>
    <tr> 
      <td><b>DIRECTOR</b></td>
      <td>DIRECTOR adalah Peringkat Kehormatan bagi para Black Manager karena telah meraih semua reward dan selanjutnya akan dianggap sebagai pemilik saham perusahaan.</td>
    </tr>               
  </tbody>  
</table>
     </div>  
   </div>
</section>










