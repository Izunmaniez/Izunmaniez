<?= $this-> extend('platform/template/index'); ?>
<?= $this-> section('content'); ?>
<?= $this-> include('platform/template/navbar'); ?>
<?= $this-> include('platform/template/toTop'); ?>
<?= $this-> include('platform/swizh/header'); ?>
<?= $this-> include('platform/swizh/slider'); ?>
<?= $this-> include('platform/swizh/paket'); ?>
<?= $this-> include('platform/swizh/bonusUpgrade'); ?>
<?= $this-> include('platform/swizh/peringkat'); ?>
<?= $this-> include('platform/swizh/bonusRo'); ?>
<?= $this-> include('platform/swizh/bonusHapee'); ?>
<?= $this-> include('platform/swizh/reward'); ?>
<?= $this-> include('platform/swizh/bonusDirector'); ?>
<?= $this-> include('platform/swizh/top'); ?>                           
<?= $this-> endSection(); ?>


