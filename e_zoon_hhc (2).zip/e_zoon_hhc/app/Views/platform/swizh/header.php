    <!-- scroll-to-top start -->
    <div class="scroll-to-top">
      <span class="scrolOl-icon">
        <i class="fas fa-rocket" aria-hidden="true"></i>
      </span>
    </div>
    <!-- scroll-to-top end -->
    
 <section class="hero bg_img" data-background="/aset/img/bgBlue/bg1.jpg">
      <div id='stars'></div>
      <div id='stars2'></div>
      <div id='stars3'></div>
      <div id='stars4'></div>
      <div class="container">
        <div class="row">
          <div class="col-lg-5">
            <div class="hero__content">
             <div id="google_translate_element">
             </div>
                <script type="text/javascript">
                function googleTranslateElementInit() {
                  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
                }
                </script>
                <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
                        
               </div>
          </div>
        </div>
    </div>
</section>
  <?= $this->include('platform/template/runningText');?>
              