<section class="elementor-section elementor-top-section elementor-element elementor-element-699fc48 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="699fc48" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
  <div class="elementor-background-overlay"></div>
   <div class="elementor-container elementor-column-gap-default">
     <div class="elementor-row">
       <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-185dbbe" data-id="185dbbe" data-element_type="column">
	 <div class="elementor-column-wrap elementor-element-populated">
	   <div class="elementor-widget-wrap">
	     <div class="elementor-element elementor-element-6425982 elementor-widget elementor-widget-menu-anchor" data-id="6425982" data-element_type="widget" data-widget_type="menu-anchor.default">
	       <div class="elementor-widget-container">
	         <div id="caramaklon" class="elementor-menu-anchor"></div>
                 </div>
	       </div>
	         <div class="elementor-element elementor-element-3306e69 elementor-widget elementor-widget-heading" data-id="3306e69" data-element_type="widget" data-widget_type="heading.default">
		 <div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-large">Cara Naik Peringkat</h2>		 
                 </div>
		 </div>
		 <div class="elementor-element elementor-element-cc03a73 elementor-widget elementor-widget-text-editor" data-id="cc03a73" data-element_type="widget" data-widget_type="text-editor.default">
		 <div class="elementor-widget-container">
		 <div class="elementor-text-editor elementor-clearfix">
<p>Peringkat2 di HHC.</p>					
                </div>
		 </div>
		 </div>
		 <div class="elementor-element elementor-element-15c485d uael-timeline--center uael-timeline-responsive-tablet uael-timeline-arrow-center elementor-invisible elementor-widget elementor-widget-uael-timeline" data-id="15c485d" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;slideInUp&quot;,&quot;_animation_delay&quot;:100}" data-widget_type="uael-timeline.default">
      <div class="elementor-widget-container">
	 <div class="uael-timeline-wrapper uael-timeline-node uael-timeline-res-right">	
	   <div class="uael-timeline-shadow-yes uael-timeline-main">
	     <div class="uael-days">
		   <div class="elementor-repeater-item-3c5bd9c uael-timeline-field animate-border out-view">
		     <div class="uael-timeline-widget uael-timeline-right">
		       <div class="uael-timeline-marker">
		 <span class="timeline-icon-new out-view-timeline-icon">
		 <i aria-hidden="true" class="fas fa-user-friends"></i></span>
		       </div>
		          <div class="uael-day-new uael-day-right">
		            <div class="uael-events-new">																		 
                              <div class="uael-events-inner-new">																				 
                                <div class="uael-content">																																	 
                                  <div class="uael-timeline-heading-text">
<h3 class="uael-timeline-heading">WHITE LEADER</h3> 											 
                                  </div>																																																															 
                                </div>																							 
                                      <div class="uael-timeline-arrow">
                                      </div>																				 
                              </div>																 
                            </div>
	                  </div>															 
                                          <div class="uael-timeline-date-new">
		                            <div class="uael-date-new">
		                              <div class="inner-date-new">
		                                <div>
		                                </div>
		                              </div>									
	                                    </div>								
	                                   </div>
	           </div>
                </div>																	 
                 <div class="elementor-repeater-item-3d3bd83 uael-timeline-field animate-border out-view">
	         <div class="uael-timeline-widget uael-timeline-left">
		 <div class="uael-timeline-marker">
                 <span class="timeline-icon-new out-view-timeline-icon">
		 <i aria-hidden="true" class="fas fa-project-diagram"></i></span>
		 </div>
		 <div class="uael-day-new uael-day-left">
	         <div class="uael-events-new">																		<div class="uael-events-inner-new">
																				<div class="uael-content">
																																	<div class="uael-timeline-heading-text">
												<h3 class="uael-timeline-heading">YELLOW</h3> 											</div>
																																																																	</div>
																							<div class="uael-timeline-arrow"></div>
																				</div>
																	</div>
							</div>
															<div class="uael-timeline-date-new">
									<div class="uael-date-new"><div class="inner-date-new"><div ></div></div>
									</div>
								</div>
													</div>
					</div>
																	<div class="elementor-repeater-item-cdc1fb9 uael-timeline-field animate-border out-view">
						<div class="uael-timeline-widget uael-timeline-right">
							<div class="uael-timeline-marker">
								<span class="timeline-icon-new out-view-timeline-icon">
									<i aria-hidden="true" class="fas fa-chalkboard"></i>								</span>
							</div>

							<div class="uael-day-new uael-day-right">
								<div class="uael-events-new">
																		<div class="uael-events-inner-new">
																				<div class="uael-content">
																																	<div class="uael-timeline-heading-text">
												<h3 class="uael-timeline-heading">GREEN </h3> 											</div>
																																																																	</div>
																							<div class="uael-timeline-arrow"></div>
																				</div>
																	</div>
							</div>
															<div class="uael-timeline-date-new">
									<div class="uael-date-new"><div class="inner-date-new"><div ></div></div>
									</div>
								</div>
													</div>
					</div>
																	<div class="elementor-repeater-item-b007ce8 uael-timeline-field animate-border out-view">
						<div class="uael-timeline-widget uael-timeline-left">
							<div class="uael-timeline-marker">
								<span class="timeline-icon-new out-view-timeline-icon">
									<i aria-hidden="true" class="far fa-list-alt"></i>								</span>
							</div>

							<div class="uael-day-new uael-day-left">
								<div class="uael-events-new">
																		<div class="uael-events-inner-new">
																				<div class="uael-content">
																																	<div class="uael-timeline-heading-text">
												<h3 class="uael-timeline-heading">BLUE</h3> 											</div>
																																																								<div class="uael-timeline-desc-content"><span style="color: #F4CF3A">RED</span></div> 																																</div>
																							<div class="uael-timeline-arrow"></div>
																				</div>
																	</div>
							</div>
															<div class="uael-timeline-date-new">
									<div class="uael-date-new"><div class="inner-date-new"><div ></div></div>
									</div>
								</div>
													</div>
					</div>
																	<div class="elementor-repeater-item-b3d4de9 uael-timeline-field animate-border out-view">
						<div class="uael-timeline-widget uael-timeline-right">
							<div class="uael-timeline-marker">
								<span class="timeline-icon-new out-view-timeline-icon">
									<i aria-hidden="true" class="fas fa-cogs"></i>								</span>
							</div>

							<div class="uael-day-new uael-day-right">
								<div class="uael-events-new">
																		<div class="uael-events-inner-new">
																				<div class="uael-content">
																																	<div class="uael-timeline-heading-text">
												<h3 class="uael-timeline-heading">BLACK</h3> 											</div>
																																																																	</div>
																							<div class="uael-timeline-arrow"></div>
																				</div>
																	</div>
							</div>
															<div class="uael-timeline-date-new">
									<div class="uael-date-new"><div class="inner-date-new"><div ></div></div>
									</div>
								</div>
													</div>
					</div>
																	<div class="elementor-repeater-item-084daca uael-timeline-field animate-border out-view">
						<div class="uael-timeline-widget uael-timeline-left">
							<div class="uael-timeline-marker">
								<span class="timeline-icon-new out-view-timeline-icon">
									<i aria-hidden="true" class="fas fa-shipping-fast"></i>								</span>
							</div>

							<div class="uael-day-new uael-day-left">
								<div class="uael-events-new">
																		<div class="uael-events-inner-new">
																				<div class="uael-content">
																																	<div class="uael-timeline-heading-text">
												<h3 class="uael-timeline-heading">MASTER</h3> 											</div>
																																																																	</div>
																							<div class="uael-timeline-arrow"></div>
																				</div>
																	</div>
							</div>
															<div class="uael-timeline-date-new">
									<div class="uael-date-new"><div class="inner-date-new"><div ></div></div>
									</div>
								</div>
													</div>
					</div>
										</div>		
		<div class="uael-timeline__line">
			<div class="uael-timeline__line__inner"></div>
		</div>
	</div>
</div>

		 </div>
	       </div>
	    </div>
	  </div>
       </div>
    </div>
  </div>
</section>