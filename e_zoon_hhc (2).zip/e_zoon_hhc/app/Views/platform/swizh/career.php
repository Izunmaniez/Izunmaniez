<section class="pt-150 pb-100">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-6 text-center">
            <div class="section-header">
              <h2 class="section-title"><span class="font-weight-normal">PERINGKAT & BONUS RO</i></span> 
              
            </div>
          </div>
        </div><!-- row end -->
      </div>
    
        
        <div class="row mb-30 justify-content-center ">
        <div class="col-xl-3 col-lg-6 col-md-6 mb-30 wow zoomout" data-wow-duration="3s" style="visibility: visible; animation-duration: 5s; animation-name: bounceIn;">
            <div class="package-card text-center bg_img" data-background="/aset/img/bgBlue/bg2.jpg">
              <h3 class="package-card__title base--color mb-2">WHITE LEADER</h3>              
              <ul class="package-card__features mt-4">
                <li>Bonus belanJA PRIbadi (JAPRI)
                <h4 class="package-card__features base--color">14℅</h4></li>                
                <li>Bonus belanJA SPONsor  (JASPON)
                <h4 class="package-card__features base--color">14℅</h4></li>                
                <li>Bonus Get Pro Seller (GPS)
                <h4 class="package-card__features base--color">5℅</h4></li>
                <li>Bonus Lebaran (THR)
                <h4><span class="package-card__features base--color">10℅</h4></span>
                dari (PV) Omset Market Place.</li>                                         
                <li>         
              <div class="package-card__features mt-3">Seluruh<b> Omset Anda dan Grup Anda</b> di Market Place akan terakumulasi dan terintegrasi dengan omset yang ada di Business Plan <a href="#"><b><span class="base--color">Heronet</span></b></a> dalam sistem perhitungan kwalifikasi Reward.               
              </div>
                 </li>
               </ul>
              <a class="cmn-btn mt-4" href="/users">Upgrade Sekarang</a>
            </div><!-- package-card end -->
          </div><!-- col end -->
          
                                                                                                                                     
      </div><!-- row end --> 
      
      
      
      <div class="row mb-30 justify-content-center ">
        <div class="col-xl-6 col-lg-6 col-md-6 mb-30 wow zoomout" data-wow-duration="3s" style="visibility: visible; animation-duration: 5s; animation-name: bounceIn;">
            <div class="package-card text-center bg_img" data-background="/aset/img/bgBlue/bg2.jpg">
              <h3 class="package-card__title base--color mb-2">MASTER LEADER</h3>              
              <ul class="package-card__features mt-4">
              <li>         
              <div class="package-card__features mt-3">Peringkat<b> MASTER LEADER</b> diberikan kepada seorang yang telah melewati semua peringkat dan telah meraih semua Reward yang ada di Business Plan <a href="#"><b><span class="base--color">Swizh.</span></b></a> Pada tahap ini Seorang MASTER LEADER akan dianggap sebagai <b class="base--color">PEMILIK SAHAM Perusahaan HHC</b> yang nilainya 10℅ saham untuk Para Penyandang Gelar <b class="base--color">MASTER.</b>      
              </div>
                 </li>
               </ul>
              <a class="cmn-btn mt-4" href="/users">Upgrade Sekarang</a>
            </div><!-- package-card end -->
          </div><!-- col end -->                                                                                                                                                 
        </div><!-- row end --> 
</section>