<section class="mt-50">      
   <div class="row justify-content-center">
      <div class="paket">
        <div class="container">
          <div class="col-lg-6 text-center mb-2">      
          <h1>REWARD</h1>
          </div>                 
       </div>
     </div>
  </div><!-- row end -->

  <div class="row mb-30 justify-content-center ">           
      <div class="col-xl-3 col-lg-6 col-md-6 mb-30 wow zoomout" data-wow-duration="3s" style="visibility: visible; animation-duration: 5s; animation-name: bounceIn;">
         <div class="package-card text-center bg-dark">                      
    <?= $this->include('platform/swizh/sliderReward');?>
            <ul class="package-card__title mt-3">
              Rules : 
            </ul>
            <ul> 
              <li class="package-card__features mt-2">
              Akumulasi Tanpa Batas Waktu Omset Plan RO.
              </li>
              <li class="package-card__features mt-2">
              Digabung dengan Akumulasi Tanpa Batas Waktu dari Omset Hapee Market Place.
              </li>                                
              <div class="package-card__features mt-2">
              Hanya dari Jalur Sponsorisasi (Tidak termasuk omset dari dowline limpahan/spilover).
              </li>
              <div class="package-card__features mt-2">
              Tidak termasuk omset dari downline yang telah berperingkat sama dengan Anda.
              </li>
            </ul>               
           </div>   
       </div><!-- col end -->                                                                                                                           
   </div><!-- row end -->   
</section>