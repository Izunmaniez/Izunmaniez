<section class="slider-section pt-0 pb-0">
   <div class="slider-inner">
      <div class="row">                   
         <div class="col">
            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
               <div class="carousel-inner shadow-sm rounded ">
    <div class="carousel-item active">
                <h3 class="cmn-btn mb-2">YELLOW<br>MANAGER</h3>   
 <img src="/aset/img/reward/hp.jpg" class="d-block w-100" style="height:190px; margin-bottom:13px;">         
              <div class="package-card__features mt-4">
                <b>Akumukasi Omset Grup :
                <h4 class="package-card__features base--color">Rp. 50 Juta</h4></b>                
              </div>              
    </div>                 
    
    <div class="carousel-item">
                <h3 class="cmn-btn mb-2">GREEN<br>MANAGER</h3>              
               <img src="/aset/img/reward/motor.jpg" class="d-block w-100" style="height:190px; margin-bottom:13px;">         
              <div class="package-card__features mt-4">
                <b>Akumukasi Omset Grup :
                <h4 class="package-card__features base--color">Rp. 350 Juta</h4></b>                
              </div>                           
     </div>
<div class="carousel-item">
                <h3 class="cmn-btn mb-2">BLUE<br>MANAGER</h3>              
               <img src="/aset/img/reward/car1.jpg" class="d-block w-100" style="height:190px; margin-bottom:13px;">         
              <div class="package-card__features mt-4">
                <b>Akumukasi Omset Grup :
                <h4 class="package-card__features base--color">Rp. 2,5 Milyar</h4></b>                
              </div>                           
    </div>
    <div class="carousel-item">
                <h3 class="cmn-btn mb-2">RED<br>MANAGER</h3>              
               <img src="/aset/img/reward/car2.jpg" class="d-block w-100" style="height:190px; margin-bottom:13px;">         
              <div class="package-card__features mt-4">
                <b>Akumukasi Omset Grup :
                <h4 class="package-card__features base--color">Rp. 6 Milyar</h4></b>                
              </div>                           
    </div>
    <div class="carousel-item">
                <h3 class="cmn-btn mb-2">BLACK<br>MANAGER</h3>              
               <img src="/aset/img/reward/rumah.jpg" class="d-block w-100" style="height:190px; margin-bottom:13px;">         
              <div class="package-card__features mt-4">
                <b>Akumukasi Omset Grup :
                <h4 class="package-card__features base--color">Rp. 10 Milyar</h4></b>                
              </div>                           
    </div>    
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon text-success" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon text-success" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
            </div>
         </div>
      </div>
   </div>
</section>