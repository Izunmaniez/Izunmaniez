<section class="pt-20 pb-50 bg_img overlay--radial">
  <div class="row"> 
    <div class="col-lg-12">
       <div class="testimonial-slider">    
         <div class="single-slide">
           <div class="testimonial-card"> 
             <div class="team-card__thumb">
              <img src="/aset/img/produkHome/swizh.jpg" alt="image">
              </div>  
            </div>        
              <div class="team-card__content">
                <h4 class="name mb-1">Swizh Coffee</h4>
                <span class="designation">PV : 100%</span> <br>  
                <button class="btn bg-light" data-toggle="modal" data-target="#modal-coffee">Lihat Detail</button>                            
              </div>          
          </div><!-- single-slide end -->

         <div class="single-slide">
           <div class="testimonial-card">  
             <div class="team-card__thumb">
              <img src="/aset/img/produkHome/swizhOil.jpg" alt="image">
             </div>
           </div>         
              <div class="team-card__content">
                <h4 class="name mb-1">Swizh Oil</h4>
                <span class="designation">PV : 100%</span> <br>  
                <button class="btn bg-light" data-toggle="modal" data-target="#modal-oil">Lihat Detail</button>                             
              </div>
          </div><!-- single-slide end -->
          
           </div>
        </div>        
       </div>
     </div><!-- row end -->                                 
 </section>
 
<section>   
 <div class="modal fade" id="modal-coffee">
    <div class="modal-dialog modal-coffee">          
      <div class="modal-content">      
        <div class="modal-body">
        
          <div class="modal-header">                 
            <h4 class="modal-title">Swizh Coffee</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
          </div>
            <div class="container mt-2 mb-5">
              <div class="team-card__thumb elevation-7">
                <img src="/aset/img/produkHome/swizh.jpg" alt="image">
              </div>
                <h4 class="name mt-2">Swizh Coffee</h4>
                <span class="designation">PV : 100%</span> 
                <br><br>      
                <h4><b> Manfaat Swizh Coffee</b></h4>  
                <small><i>(Komposisi : Cordycep Mycellium, Ginseng Merah, Habbatussaudah, Tribulus, Kayu Bajaka, Daun Bidara, Madu Yaman, Purwoceng dan 13 bahan lainnya.)</i></small>         
                <li>  Menyembuhkan berbagai macam penyakit yang berhubungan dengan sebab penyumbatan pembuluh darah
               seperti : Stroke, Saraf Terjepit, Kolesterol Tinggi, Darah Tinggi, Jantung Koroner, Diabetes Type II, Asam Urat, dsb..  </li>
                <li>  Sebagai Anti Oksidan dan Detoksifikasi (Membung racun dalam tubuh).  </li>
                <li>  Membunuh sel kanker. </li>
                <li>  Menguatkan fungsi Jantung, Hati, Paru-paru, Pankreas, Limpa dan Ginjal.</li>
                <li>  Meningkatkan Vitalitas pria & wanita.</li>               
                <br>
                <small><i>BPOM : 000000000</i></small>
            </div>
        </div>
     </div>
   </div>
</section>
 
<section>   
 <div class="modal fade" id="modal-oil">
    <div class="modal-dialog modal-oil">          
      <div class="modal-content">      
        <div class="modal-body">
          <div class="modal-header">                 
            <h4 class="modal-title">Swizh Oil</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
          </div>
              <div class="team-card__thumb elevation-7">
                <img src="/aset/img/produkHome/swizhOil.jpg" alt="image">
              </div>
                <h4 class="name mt-2">Swizh Oil</h4>
                <span class="designation">PV : 100%</span> 
                <br><br>      
                <h4><b> Manfaat Swizh Oil</b></h4>  
                <small><i>(Komposisi : Minyak Kelapa Hijau, Daun Bidara, daun kelor dan 9 jenis dedaunan lainnya)</i></small>       
                <li> Untuk diminum dan obat luar (dioles). </li>
                <li>  Menyembuhkan berbagai macam penyakit yang berhubungan dengan sebab penyumbatan pembuluh darah
               seperti : Stroke, Saraf Terjepit, Kolesterol Tinggi, Darah Tinggi, Jantung Koroner, Diabetes Type II, Asam Urat, dsb..  </li>
                <li>  Sebagai Anti Oksidan dan Detoksifikasi (Membung racun dalam tubuh).  </li>
                <li>  Membunuh sel kanker. </li>
                <li>  Mengobati luka dan luka bakar. </li>
                <li>  Sebagai masker wajah.</li>
                <li>  Meningkatkan Vitalitas pria & wanita.</li>               
                <br>
                <small><i>BPOM : 000000000</i></small>
          </div> 
       </div>
     </div>
   </div>
</section>