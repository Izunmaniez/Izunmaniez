<section class="slider-section pt-0 pb-0">
   <div class="slider-inner">
      <div class="row">                   
         <div class="col">
            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
               <div class="carousel-inner shadow-sm rounded ">
    <div class="carousel-item active">
                <h3 class="cmn-btn mb-2">WHITE<br>MANAGER</h3>          
              <div class="package-card__features mt-4">
                <b>Bonus JAPRI (belanJA PRIbadi) :
                <h4 class="package-card__features base--color">10℅</h4></b>                
              </div>
              <div class="package-card__features mt-4">
                <b>Bonus SELPI (SELisih PerIngkat) :
                <h4 class="package-card__features base--color">--</h4></b>                
              </div>
              <div class="package-card__features mt-4">
                <b>Bonus GENERASI (Sama Peringkat):
                <h4 class="package-card__features base--color">3% hingga 1 Generasi</h4></b>                
              </div>            
    </div> 
        <div class="carousel-item">
                <h3 class="cmn-btn mb-2">YELLOW<br>MANAGER</h3>          
              <div class="package-card__features mt-4">
                <b>Bonus JAPRI (belanJA PRIbadi) :
                <h4 class="package-card__features base--color">12℅</h4></b>                
              </div>
              <div class="package-card__features mt-4">
                <b>Bonus SELPI (SELisih PerIngkat) :
                <h4 class="package-card__features base--color">2%</h4></b>                
              </div>
              <div class="package-card__features mt-4">
                <b>Bonus GENERASI (Sama Peringkat):
                <h4 class="package-card__features base--color">2% hingga 2 Generasi</h4></b>                
              </div>            
    </div>                                     
    <div class="carousel-item">
                <h3 class="cmn-btn mb-2">GREEN<br>MANAGER</h3>          
              <div class="package-card__features mt-4">
                <b>Bonus JAPRI (belanJA PRIbadi) :
                <h4 class="package-card__features base--color">14℅</h4></b>                
              </div>
              <div class="package-card__features mt-4">
                <b>Bonus SELPI (SELisih PerIngkat) :
                <h4 class="package-card__features base--color">2% - 4℅</h4></b>                
              </div>
              <div class="package-card__features mt-4">
                <b>Bonus GENERASI (Sama Peringkat):
                <h4 class="package-card__features base--color">1% hingga 3 Generasi</h4></b>                
              </div>                  
     </div>
<div class="carousel-item">
                <h3 class="cmn-btn mb-2">BLUE<br>MANAGER</h3>          
              <div class="package-card__features mt-4">
                <b>Bonus JAPRI (belanJA PRIbadi) :
                <h4 class="package-card__features base--color">16℅</h4></b>                
              </div>
              <div class="package-card__features mt-4">
                <b>Bonus SELPI (SELisih PerIngkat) :
                <h4 class="package-card__features base--color">2% - 6℅</h4></b>                
              </div>
              <div class="package-card__features mt-4">
                <b>Bonus GENERASI (Sama Peringkat):
                <h4 class="package-card__features base--color">0,75% hingga 4 Generasi</h4></b>                
              </div>                                             
    </div>
    <div class="carousel-item">
                <h3 class="cmn-btn mb-2">RED<br>MANAGER</h3>          
              <div class="package-card__features mt-4">
                <b>Bonus JAPRI (belanJA PRIbadi) :
                <h4 class="package-card__features base--color">18℅</h4></b>                
              </div>
              <div class="package-card__features mt-4">
                <b>Bonus SELPI (SELisih PerIngkat) :
                <h4 class="package-card__features base--color">2% - 8℅</h4></b>                
              </div>
              <div class="package-card__features mt-4">
                <b>Bonus GENERASI (Sama Peringkat):
                <h4 class="package-card__features base--color">0,5% hingga 5 Generasi</h4></b>                
              </div>                           
    </div>
    <div class="carousel-item">
                <h3 class="cmn-btn mb-2">BLACK<br>MANAGER</h3>          
              <div class="package-card__features mt-4">
                <b>Bonus JAPRI (belanJA PRIbadi) :
                <h4 class="package-card__features base--color">20℅</h4></b>                
              </div>
              <div class="package-card__features mt-4">
                <b>Bonus SELPI (SELisih PerIngkat) :
                <h4 class="package-card__features base--color">2% - 10℅</h4></b>                
              </div>
              <div class="package-card__features mt-4">
                <b>Bonus GENERASI (Sama Peringkat):
                <h4 class="package-card__features base--color">0,25% hingga 6 Generasi</h4></b>                
              </div>                                    
    </div>    
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon text-success" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon text-success" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
            </div>
         </div>
      </div>
   </div>
</section>