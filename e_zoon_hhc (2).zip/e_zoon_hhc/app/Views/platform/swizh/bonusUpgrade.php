<section class="mt-50">      
   <div class="row justify-content-center">
      <div class="paket">
        <div class="container">
          <div class="col-lg-6 text-center mb-3">                                                  
          <h6>Crazy Cashback diatas Anda terima hanya dari Belanja Pribadi Anda saja tanpa syarat rekrut member baru. Jika ada grup yang berbelanja di salah satu Paket Belanja Produk Swizh seperti Anda, maka Anda akan memperoleh bonus-bonus Upgrade Sponsor dan Pairing yang dibayar dalam periode mingguan.</h6>                                          
          </div>                 
       </div>
     </div>
  </div><!-- row end -->

  <img style="width:100%; border-radius:9px;" src="/aset/img/swizh/bonus1.jpg">          

</section>   