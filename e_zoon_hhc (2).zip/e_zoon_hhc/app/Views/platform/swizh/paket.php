<section class="mt-50">  
   <div class="row justify-content-center">
      <div class="paket">
        <div class="container">
          <div class="col-lg-6 text-center mb-3">                                                  
    <h2 class="section-title mt-4"><span class="font-weight-normal">Paket Belanja Dan PROMO*</span></h2>
    <h2 class="section-title"><span class="font-weight-normal"><b>Crazy Cashback di Swizh</b></span></h2>           
    <h6>Untuk 1.000 Member Premium Pertama</h6>                                          
          </div>                 
       </div>
     </div>
  </div><!-- row end -->

<div class="row justify-content-center">   
   <div class="col-xl-3 col-lg-6 col-md-6 mb-30 wow zoomout" data-wow-duration="3s" style="visibility: visible; animation-duration: 5s; animation-name: bounceIn;">
     <div class="cta-wrapper bg_img border-radius--10 text-right" data-background="/aset/img/swizh/wood.jpg">     
       <div class="paket">
          <h2 class="title">WOOD</h2>
          <h3 class="title mb-2">Belanja Rp. 400.000,-</h3>
          <h5 class="title">Pilihan Produk :</h5>
          <h4 class="title"><b>1 Box Swizh Coffee</b></h4>
          <h5 class="title mb-3">isi 15 sachet @25gr/box</h5>        
          <h5 class="title mb-1">Atau :</h5> 
          <h4 class="title"><b>1 Box Swizh Oil</b></h4>
          <h5 class="title mb-4">isi 2 botol @33ml/box</h5>
          <h4 class="title"><u>PROMO*</u> </h4>
          <h2 class="title">Crazy Cashback</h2>          
          <h2 class="title mb-3">---</h2>           
          <h3 class="title">Voucher Belanja</h3> 
          <h4 class="title">di Market Place <b>Hapee</b></h4> 
          <h4 class="title">Rp. 50.000,-/bln</h4> 
          <h5 class="title mb-3">Selama 1 bulan</h5> 
          <h3 class="title">Total Cashback</h3> 
          <h2 class="title mb-3">Rp. 50.000,-</h2>
         </div>                             
     </div>                             
   </div>
 </div>
  
<div class="row justify-content-center">   
  <div class="col-xl-3 col-lg-6 col-md-6 mb-30 wow zoomout" data-wow-duration="3s" style="visibility: visible; animation-duration: 5s; animation-name: bounceIn;">
     <div class="cta-wrapper bg_img border-radius--10 text-right" data-background="/aset/img/swizh/silver.jpg">     
        <div class="paket">
          <h2 class="title">SILVER</h2>
          <h3 class="title mb-2">Belanja Rp. 1.000.000,-</h3>
          <h5 class="title">Pilihan Produk :</h5>
          <h4 class="title"><b>1 Box Swizh Coffee</b></h4>
          <h5 class="title mb-4">isi 15 sachet @25gr/box</h5>        
          <h5 class="title mb-4">Atau :</h5> 
          <h4 class="title"><b>3 Box Swizh Oil</b></h4>
          <h5 class="title mb-4">isi 2 botol @33ml/box</h5>
          <h4 class="title"><u>PROMO*</u> </h4>
          <h2 class="title">Crazy Cashback</h2>          
          <h4 class="title">Rp. 50.000,-/bln</h4> 
          <h5 class="title mb-4">Selama 4 bulan</h5> 
          <h3 class="title">Voucher Belanja</h3> 
          <h4 class="title">di Market Place <b>Hapee</b></h4> 
          <h4 class="title">Rp. 50.000,-/bln</h4> 
          <h5 class="title mb-5">Selama 2 bulan</h5> 
          <h3 class="title">Total Cashback</h3> 
          <h2 class="title mb-3">Rp. 300.000,-</h2>
       </div>                             
     </div>                             
  </div>
  
  <div class="col-xl-3 col-lg-6 col-md-6 mb-30 wow zoomout" data-wow-duration="3s" style="visibility: visible; animation-duration: 5s; animation-name: bounceIn;">
     <div class="cta-wrapper bg_img border-radius--10 text-right" data-background="/aset/img/swizh/gold.jpg">     
        <div class="paket">
          <h2 class="title">GOLD</h2>
          <h3 class="title mb-2">Belanja Rp. 3.000.000,-</h3>
          <h5 class="title">Pilihan Produk :</h5>
          <h4 class="title"><b>9 Box Swizh Coffee</b></h4>
          <h5 class="title mb-3">isi 15 sachet @25gr/box</h5>        
          <h5 class="title mb-1">Atau :</h5> 
          <h4 class="title"><b>9 Box Swizh Oil</b></h4>
          <h5 class="title mb-3">isi 2 botol @33ml/box</h5>
          <h4 class="title mb-3">Bisa Kombinasi per Rp. 1 Juta</h4>
          <h4 class="title"><u>PROMO*</u> </h4>
          <h2 class="title">Crazy Cashback</h2>          
          <h4 class="title">Rp. 150.000,-/bln</h4> 
          <h5 class="title mb-3">Selama 8 bulan</h5> 
          <h3 class="title">Voucher Belanja</h3> 
          <h4 class="title">di Market Place <b>Hapee</b></h4> 
          <h4 class="title">Rp. 150.000,-/bln</h4> 
          <h5 class="title mb-3">Selama 3 bulan</h5> 
          <h3 class="title">Total Cashback</h3> 
          <h2 class="title mb-3">Rp. 1.650.000,-</h2>
       </div>                             
     </div>                             
   </div>
   
   <div class="col-xl-3 col-lg-6 col-md-6 mb-30 wow zoomout" data-wow-duration="3s" style="visibility: visible; animation-duration: 5s; animation-name: bounceIn;">
     <div class="cta-wrapper bg_img border-radius--10 text-right" data-background="/aset/img/swizh/platinum.jpg">     
       <div class="paket">
          <h2 class="title">PLATINUM</h2>
          <h3 class="title mb-2">Belanja Rp. 7.000.000,-</h3>
          <h5 class="title">Pilihan Produk :</h5>
          <h4 class="title"><b>21 Box Swizh Coffee</b></h4>
          <h5 class="title mb-3">isi 15 sachet @25gr/box</h5>        
          <h5 class="title mb-1">Atau :</h5> 
          <h4 class="title"><b>21 Box Swizh Oil</b></h4>
          <h5 class="title mb-4">isi 2 botol @33ml/box</h5>
          <h4 class="title mb-4">Bisa Kombinasi per Rp. 1 Juta</h4>
          <h4 class="title"><u>PROMO*</u> </h4>
          <h2 class="title">Crazy Cashback</h2>          
          <h4 class="title">Rp. 350.000,-/bln</h4> 
          <h5 class="title mb-3">Selama 12 bulan</h5> 
          <h3 class="title">Voucher Belanja</h3> 
          <h4 class="title">di Market Place <b>Hapee</b></h4> 
          <h4 class="title">Rp. 350.000,-/bln</h4> 
          <h5 class="title mb-3">Selama 4 bulan</h5> 
          <h3 class="title">Total Cashback</h3> 
          <h2 class="title mb-3">Rp. 5.600.000,-</h2>
       </div>                             
     </div>                             
  </div>
  
  <div class="col-xl-3 col-lg-6 col-md-6 mb-30 wow zoomout" data-wow-duration="3s" style="visibility: visible; animation-duration: 5s; animation-name: bounceIn;">
     <div class="cta-wrapper bg_img border-radius--10 text-right" data-background="/aset/img/swizh/diamond.jpg">     
        <div class="paket">
          <h2 class="title">DIAMOND</h2>
          <h3 class="title mb-2">Belanja Rp. 12.000.000,-</h3>
          <h5 class="title">Pilihan Produk :</h5>
          <h4 class="title"><b>36 Box Swizh Coffee</b></h4>
          <h5 class="title mb-3">isi 15 sachet @25gr/box</h5>        
          <h5 class="title mb-1">Atau :</h5> 
          <h4 class="title"><b>36 Box Swizh Oil</b></h4>
          <h5 class="title mb-4">isi 2 botol @33ml/box</h5>
          <h4 class="title mb-4">Bisa Kombinasi per Rp. 1 Juta</h4>
          <h4 class="title"><u>PROMO*</u> </h4>
          <h2 class="title">Crazy Cashback</h2>          
          <h4 class="title">Rp. 600.000,-/bln</h4> 
          <h5 class="title mb-3">Selama 17 bulan</h5> 
          <h3 class="title">Voucher Belanja</h3> 
          <h4 class="title">di Market Place <b>Hapee</b></h4> 
          <h4 class="title">Rp. 600.000,-/bln</h4> 
          <h5 class="title mb-3">Selama 5 bulan</h5> 
          <h3 class="title">Total Cashback</h3> 
          <h2 class="title mb-3">Rp. 13.200.000,-</h2>
        </div>                             
      </div>
    </div>
  </div>                     
</section>     
  
                           