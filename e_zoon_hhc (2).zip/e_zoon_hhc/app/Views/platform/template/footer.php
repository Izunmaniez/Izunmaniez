  <!-- footer section start -->
 <footer class="footer bg_img" style="width:100%;" data-background="/aset/img/gold/footer.jpg">
  <div class="footer__top">
    <div class="container">
      <div class="row justify-content-center">       
        <div class="col-lg-12 text-center">
          <a href="/platform"><img class="img brand-image mb-5" src="/aset/img/bar/logohhc.png" alt="HHC"></a>
    <div class="row justify-content-center">
      <a href="/"><img class="work-card__icon" src="/aset/img/logoPlatform/hapee.png" alt="Hapee HHC"></a>
      <a href="#"><img class="work-card__icon" src="/aset/img/logoPlatform/shotoo.png" alt="Shotoo HHC"></a>
      <a href="/platform/swizh"><img class="work-card__icon" src="/aset/img/logoPlatform/swizh.png" alt="Swizh HHC"></a>                        
    </div>
    <div class="row justify-content-center">
      <a href="#"><img class="work-card__icon" src="/aset/img/logoPlatform/heroports.png" alt="HeroPorts HHC"></a>
      <a href="#"><img class="work-card__icon" src="/aset/img/logoPlatform/heroads.png" alt="HeroAds HHC"></a>
    </div>
    <div class="row justify-content-center">
      <a href="#"><img class="work-card__icon" src="/aset/img/logoPlatform/heromox.png" alt="HeroMoX HHC"></a>
      <a href="#"><img class="work-card__icon" src="/aset/img/logoPlatform/herocx.png" alt="HeroCX HHC"></a>                      
    </div>
    <div class="row justify-content-center">
      <a href="/platform/empathy"><img class="work-card__icon" src="/aset/img/logoPlatform/empathy.png" alt="Empathy HHC"></a>
      <a href="/platform/charger"><img class="work-card__icon" src="/aset/img/logoPlatform/charger.png" alt="Charger HHC"></a>
      <a href="/platform/vichar"><img class="work-card__icon" src="/aset/img/logoPlatform/vichar.png" alt="Vichar HHC"></a>                        
    </div>
             <ul class="footer-short-menu d-flex flex-wrap justify-content-center mt-3">
                 <li><a href="">Privacy &amp; Policy</a></li>
                    <li><a href="">Terms &amp; Condition</a></li>
                 </ul>
                 <ul class="footer-short-menu d-flex flex-wrap justify-content-center mt-2">
                    <li>contact us :  <a href="">sobathhc@gmail.com</a></li>
             </ul>    
        </div>
      </div>
    </div>
  </div>
  <div class="footer__bottom">      
    <div class="container">
      <div class="row">
 
        <div class="col-md-6 text-md-left text-center">
          <p><p>© 2015-2021 <a href="<?= base_url(); ?>/hhc" class="base--color">HHC</a>. All rights reserved</p></p>
        </div>
        <div class="col-md-6">
          <ul class="social-link-list d-flex flex-wrap justify-content-md-end justify-content-center">
                        <li><a href="https://www.facebook.com"><i class="fab fa-facebook"></i></a></li>
                        <li><a href="https://www.twitter.com"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="https://www.instagram.com"><i class="fab fa-instagram"></i></a></li>
                        <li><a href="https://www.linkedin.com"><i class="fab fa-linkedin"></i></a></li>
                      </ul>
        </div>
      </div>
    </div>
  </div>
</footer>
<!-- footer section end -->
  </div> <!-- page-wrapper end -->
    <!-- jQuery library -->
  <script src="<?= base_url(); ?>/aset/js/jquery-3.5.1.min.js"></script>
  <!-- bootstrap js -->
  <script src="<?= base_url(); ?>/aset/js/bootstrap.bundle.min.js"></script>

    <!-- slick slider js -->
  <script src="<?= base_url(); ?>/aset/js/slick.min.js"></script>
  <script src="<?= base_url(); ?>/aset/js/wow.min.js"></script>
  <!-- dashboard custom js -->
  <script src="<?= base_url(); ?>/aset/js/app.js"></script>


  <link rel="stylesheet" href="<?= base_url(); ?>/aset/css/extern/iziToast.min.css">
<script src="<?= base_url(); ?>/aset/js/iziToast.min.js"></script>





</body>
</html>

  </body>
</html> 