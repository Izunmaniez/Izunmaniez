<section class="overlay--radial bg_img mb-7" data-background="/aset/img/gold/bg4.jpg">
      
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-6 text-center">
            <div class="section-header my-3">
              <h2 class="section-title"><span class="font-weight-normal">We Are</span> <b class="base--color">HHC</b></h2>  
               <i class="base--color">Since 2015</i>      
            </div>
          </div>
        </div><!-- row end -->
        <div class="row justify-content-center mb-none-30">
                    <div class="col-xl-4 col-md-6 mb-30">
            <div class="choose-card border-radius--5">
              <div class="choose-card__header mb-3">
                <div class="choose-card__icon base--color">
                  <i class="fas fa-eye"></i>                
                  </div>
                <h4 class="choose-card__title base--color">VISI</h4>
              </div>
              <p> Menjadi Perusahaan Korporasi Startup yang memberi jalan yang membahagiakan untuk meraih kesuksesan Finansial, Emosional dan Spiritual kepada dunia.
              <p>
                </div><!-- choose-card end -->
          </div>
                    <div class="col-xl-4 col-md-6 mb-30">
            <div class="choose-card border-radius--5">
              <div class="choose-card__header mb-3">
                <div class="choose-card__icon base--color">
                  <i class="fas fa-chart-line"></i>
                  </div>
                <h4 class="choose-card__title base--color">MISI</h4>
              </div>
              <p>
              1. Menjalankan semua program/platform HHC dengan sikap yang tertuang dalam 7 PRINCESS HHC.<br>
              2. Beradaptasi terhadap segala perkembangan teknologi dan Berinovasi tanpa batas.
              </p>
            </div><!-- choose-card end -->
          </div>
                    <div class="col-xl-4 col-md-6 mb-30">
            <div class="choose-card border-radius--5">
              <div class="choose-card__header mb-3">
                <div class="choose-card__icon base--color">
                  <i class="fas fa-user-lock"></i>               
                   </div>
                <h4 class="choose-card__title base--color">VALUE</h4>
              </div>
       <p> <b>7 PRINCESS (PRINciples of sucCESS)</b><br>
1. Teguhkan Impian dan Fokus.<br>
2. Bersyukur, bersuka-cita dan tidak mengeluh.<br>
3. Rutin bersedekah.<br>
4. Konsumsi yang halal.<br>
5. Tulus, Rendah hati, No Jaim, Respek dan Empati.<br>
6. Menjaga Integritas.<br>
7. Menjadi Leader yang menginspirasi.
</p>
</div><!-- choose-card end -->
          </div>
                    <div class="col-xl-4 col-md-6 mb-30">
            <div class="choose-card border-radius--5">
              <div class="choose-card__header mb-3">
                <div class="choose-card__icon base--color">
                  <i class="fas fa-heart"></i>               
                   </div>
                <h4 class="choose-card__title base--color">BELIEF</h4>
              </div>
              <p>Kami Sangat <b class="choose-card__title base--color">Bersyukur!</b> </p>
              <p>Kami Sangat <b class="choose-card__title base--color">Bahagia!</b> </p>
              <p>Kami Sangat <b class="choose-card__title base--color">Sukses!</b> </p>
              
            </div><!-- choose-card end -->          
          
                    
            <div class="choose-card border-radius--5 mt-5">
              <div class="choose-card__header mb-3">
                <div class="choose-card__icon base--color">
                  <i class="fas fa-heart"></i>                </div>
                <h4 class="choose-card__title base--color">MOTTO</h4>
              </div>
              <p>"Happiness is the key to success"</p>
            </div><!-- choose-card end -->
          </div>
          </div>    
          </div>
        </div>   
    </section>      