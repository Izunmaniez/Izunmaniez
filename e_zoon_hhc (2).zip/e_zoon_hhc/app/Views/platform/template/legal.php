   <div class="container mb-5">
      <div class="row justify-content-center">
         <div class="col-lg-6 text-center">
         <html>
            <img src="/aset/img/gold/legal.jpg"/>
         </html>
            <a href="/aset/img/gold/legal1.jpg" class="cmn-btn mt-4">View Company Certificate</a>            
            <a href="/login" class="cmn-btn text-uppercase font-weight-600 mt-4">My Account</a>
            <a href="/register" class="cmn-btn text-uppercase font-weight-600 mt-4">Sign Up</a>           
         </div>
      </div>
    </div>