<!-- scroll-to-top start -->
 <div class="scroll-to-top">
    <span class="scrolOl-icon">
        <i class="fas fa-rocket" aria-hidden="true"></i>
    </span>
 </div>
<!-- scroll-to-top end -->

<section class="hero bg_img" data-background="/aset/img/bgBlue/bg2.jpg">
   <div class="container">
      <div class="row">
         <div class="col-lg-5">
            <div class="hero__content">
               <div id="google_translate_element"></div>
                <script type="text/javascript">
                function googleTranslateElementInit() {
                  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
                }
                </script>
                <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
                     <h1 class="hero__title mt-2"><span class="text-white font-weight-normal"><b>Vichar HHC</b></span></h1>
            <h4><i class="base--color">Video Charity - Video Untuk Amal</i></h4>
           <p> Dengan hanya nonton, like, comment & share video-video di chanel youtube Vichar, Anda telah memperoleh nilai amal ubudiyah karena hasil dari monetisasi dari chanel ini 100% akan disumbangkan melalui Platform DJOS HHC. Kami juga membuka peluang ubudiyah bagi para member untuk turut berkontribusi mengembangkan chanel ini dengan menyumbangkan content video yang bernilai positif dan inspiratif.</p>
                                                       
               </div>
           </div>
        </div>      
   </div>     
</section>
<?= $this->include('platform/template/runningText');?>