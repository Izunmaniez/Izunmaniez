<section class="pt-120 pb-120 bg_img" data-background="">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-6 text-center">
            <div class="section-header">
              <h2 class="section-title"><span class="font-weight-normal">Top Management</span> <b class="base--color">HHC</b></h2>
              <p>Kami siap mengabdikan diri demi mewujudkan Visi HHC.</p>
            </div>
          </div>
        </div><!-- row end -->
        <div class="row justify-content-center mb-30">
          <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
            <div class="team-card">
              <div class="team-card__thumb img-circle">
                <img src="/aset/img/manager/izun.jpg" alt="image">
              </div>
              <div class="team-card__content">
                <h4 class="name mb-1">Nur Alfaizun</h4>
                <span class="designation">CEO (Chief Executive Officer)</span>
              </div>
            </div><!-- team-card end -->
          </div>
        </div><!-- row end -->
          <div class="row justify-content-center mb-none-30">                                    
                    <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
            <div class="team-card">
              <div class="team-card__thumb">
                <img src="/aset/img/manager/iwan.jpg" alt="image">
              </div>
              <div class="team-card__content">
                <h4 class="name mb-1">Rusdi Bahalwan Panjaitan</h4>
                <span class="designation">COO (Chief Operating Officer)</span>
              </div>
            </div><!-- team-card end -->
          </div>
          <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
            <div class="team-card">
              <div class="team-card__thumb">
                <img src="/aset/img/manager/indra.jpg" alt="image">
               </div>
              <div class="team-card__content">
                <h4 class="name mb-1">Indra Saputra Marpaung</h4>
                <span class="designation">CFO (Chief Finance Officer)</span>
              </div>
            </div><!-- team-card end -->
          </div>
          <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
            <div class="team-card">
              <div class="team-card__thumb">
                <img src="/aset/img/manager/caman.jpg" alt="image">
               </div>
              <div class="team-card__content">
                <h4 class="name mb-1">Mr. Caman</h4>
                <span class="designation">CTO (Chief Technology Officer)</span>
              </div>
            </div><!-- team-card end -->
          </div>
                    <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
            <div class="team-card">
              <div class="team-card__thumb">
                <img src="/aset/img/manager/miswanto.jpg" alt="image">
                              </div>
              <div class="team-card__content">
                <h4 class="name mb-1">Mismanto S.Fil SH. MH</h4>
                <span class="designation">CPO (Chief Product Officer)</span>
              </div>
            </div><!-- team-card end -->
          </div>
                    <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
            <div class="team-card">
              <div class="team-card__thumb">
                <img src="/aset/img/manager/putra.jpg" alt="image">
              </div>
              <div class="team-card__content">
                <h4 class="name mb-1">Syahputra Damanik S.Fil</h4>
                <span class="designation">CHRO (Chief Human Resource Officer)</span>
              </div>
            </div><!-- team-card end -->
          </div>
                              <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
            <div class="team-card">
              <div class="team-card__thumb">
                <img src="/aset/img/manager/kuswito.jpg" alt="image">
              </div>
              <div class="team-card__content">
                <h4 class="name mb-1">Kuswito, SH</h4>
                <span class="designation">CCO (Chief Charity Officer)</span>
              </div>
            </div><!-- team-card end -->
          </div>
          <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
            <div class="team-card">
              <div class="team-card__thumb">
                <img src="/aset/img/manager/colil.jpg" alt="image">
                              </div>
              <div class="team-card__content">
                <h4 class="name mb-1">Dedy Hermanto</h4>
                <span class="designation">CMO (Chief Marketing Officer)</span>
              </div>
            </div><!-- team-card end -->
          </div>  
          <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
            <div class="team-card">
              <div class="team-card__thumb">
                <img src="/aset/img/manager/parlin.jpg" alt="image">
                              </div>
              <div class="team-card__content">
                <h4 class="name mb-1">Ahmad Parlindungan Lubis</h4>
                <span class="designation">CNO (Chief Networking Officer)</span>
              </div>
            </div><!-- team-card end -->
          </div>
         
        </div>
      </div>
    </section>