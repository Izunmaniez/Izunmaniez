 <div class="full-wh">
    <!-- STAR ANIMATION -->
    <div class="bg-animation">
      <div id='stars'></div>
      <div id='stars2'></div>
      <div id='stars3'></div>
      <div id='stars4'></div>
    </div><!-- / STAR ANIMATION -->
 </div>
  <div class="page-wrapper">
    <!-- header-section start  -->
    <header class="header">
      <div class="header__bottom"> 
        <div class="container">         
          <nav class="navbar navbar-expand-xl p-0 align-items-center">
          <a href="/platform"><img class="img brand-image" style="width:65px;" src="/aset/img/bar/logohhc.png"></a>
          
         <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="menu-toggle"></span>                                 
          </button>
             <div class="collapse navbar-collapse" id="navbarSupportedContent">                
                <ul class="navbar-nav main-menu ml-auto">                
      <div id='stars'></div>
      <div id='stars2'></div>
      <div id='stars3'></div>
      <div id='stars4'></div>               
               <li><a href="/">Go to Market Place</a></li>
               <li><a href="/platform/swizh">Go to Swizh</a></li>
               <li class="menu_has_children"><a href="#0">Non Profit Platforms</a>
                <ul class="sub-menu">
               <li><a href="/platform/empathy">Empathy</a></li>
               <li><a href="/platform/vichar">Vichar</a></li>
               <li><a href="/platform/charger">Charger</a></li>
                </ul>
               </li>               
               <li class="menu_has_children"><a href="#0">Next Our's Platforms</a>
                <ul class="sub-menu">
               <li><a href="#">Shotoo</a></li>
               <li><a href="#">HeroPorts</a></li>
               <li><a href="#">HeroAds</a></li>
               <li><a href="#">HeroMoX</a></li>
               <li><a href="#">HeroCX</a></li>
                </ul>
               </li>                     
               <li><a href="/platform">About Us</a></li>
               <li><a href="/users">My Account</a></li>
            </ul>                   
            <div class="nav-right">
              <ul class="account-menu ml-3">
                <li class="icon"><a href="/users "><i class="fas fa-user"></i></a></li>
              </ul> 
            </div>
          </div>
        </nav>
      </div>              
    </div><!-- header__bottom end -->
  </header>
  <!-- header-section end  -->
</div>