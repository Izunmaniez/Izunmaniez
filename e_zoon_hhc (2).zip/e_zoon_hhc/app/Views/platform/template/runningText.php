<div style="height:32px; background-color: #000000; overflow:hidden; box-sizing: border-box; border: 0px solid #fff000; border-radius: 0px; text-align: right; line-height:14px; block-size:px; font-size: 14px; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 px 0 0 #fff000;padding:1px;padding: 0px; margin: 0px; width: 100%;">
    <marquee behavior=”scroll” direction=”right”>
    <b class="base--color"> Hapee</b> {HHC e-commerce - Market Place HHC}
    <b class="base--color"> Shotoo</b> {Shopping HHC Offline To Online}
    <b class="base--color"> Swizh</b> {Network Marketing HHC}
    <b class="base--color"> HeroPorts</b> {Transports Apps HHC} 
    <b class="base--color"> HeroAds</b> {Advertising HHC} 
    <b class="base--color"> HeroMoX</b> {Currency Investment HHC}
    <b class="base--color"> HeroCX</b> {Crypto Currency HHC}
    <b class="base--color"> DJOS</b> {Donasi Jariyah Online System HHC}
    <b class="base--color"> Charger</b> {Character Generating HHC}
    <b class="base--color"> Vichar</b> {Video Charity HHC}
    </marquee>
</div>