<section class="about-section pt-120 pb-120 bg_img" data-background="/aset/img/gold/bg2.jpg">
      <div class="container">
        <div class="row">
            <div class="col-sm-6 wow slideInLeft" data-wow-duration="2s" style="visibility: visible; animation-duration: 2s; animation-name: slideInLeft;">
                <style>
.iframe-container{
  position: relative;
  width: 100%;
  padding-bottom: 56.25%; 
  height: 0;
}
.iframe-container iframe{
  position: absolute;
  top:0;
  left: 0;
  width: 100%;
  height: 100%;
}
                </style>
                
                <div class="iframe-container  mb-4">  
                    <iframe width="560" height="315" src="https://youtube.com/embed/Yj9B0IgEoPE" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
            </div>
            
          <div class="col-sm-6 wow slideInRight" data-wow-duration="2s" style="visibility: visible; animation-duration: 2s; animation-name: slideInRight">
            <div class="about-content">
              <h2 class="section-title mb-3"><span class="font-weight-normal">Platform</span> <b class="base--color">Kami</b></h2>
              <p>Kami memiliki banyak Platform yang kami ciptakan sendiri maupun melalui kerjasama dengan berbagai perusahaan atau instansi lain yang banyak dibutuhkan masyarakat luas. Dan terdiri dari platform yang menghasilkan Profit dan platform Non Profit.
              </p>
                </div>            
          </div>
        </div>
      </div>
    </section>
    
    <div class="container">
    <div class="col-sm-6 wow slideInRight" data-wow-duration="2s" style="visibility: visible; animation-duration: 2s; animation-name: slideInRight">
            <div class="about-content">
              <h2 class="section-title mb-3 mt-3"><b class="base--color">Profitable Platforms</b></h2>
            </div>            
          </div>
          </div>
    
        <section>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-xl-8">
            <div class="cta-wrapper bg_img border-radius--10 text-center" data-background="/aset/img/bgBlue/bg4.jpg">
              <h2 class="title mb-3">Hapee</h2>
              <p>Adalah Market Place sebagai pusat dari perdagangan online yang mayoritas dipenuhi oleh produk-produk dari produsen langsung UMKM Indonesia.
              </p>
              <a href="/" class="cmn-btn mt-4">Visit Now</a>    </div>
          </div>
        </div>
      </div>
    </section>
        
    <section>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-xl-8">
            <div class="cta-wrapper bg_img border-radius--10 text-center" data-background="/aset/img/bgBlue/bg4.jpg">
              <h2 class="title mb-3">Swizh</h2>
              <p>Adalah bisnis Network Marketing yang memasarkan produk-produk khusus dengan bonus-bonus yang fantastis dan kenaikan peringkat akan menjadi sumber pendapatan yang relatif semakin membesar bagi para member HHC yang lebih berkomitmen untuk berkarir di HHC.
              </p>
              <a href="/platform/swizh" class="cmn-btn mt-4">Visit Now</a>    </div>
          </div>
        </div>
      </div>
    </section>
    
    <section>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-xl-8">
            <div class="cta-wrapper bg_img border-radius--10 text-center" data-background="/aset/img/bgBlue/bg4.jpg">
              <h2 class="title mb-3">Shotoo</h2>
              <p>Shoping offline to online, menikmati makan & minum di cafe, nonton bioskop dan sebagianya yang telah bermitra dengan HHC, akan menjadi PV (Poin Value) bagi para member HHC.
              </p>
              <a href="#" class="cmn-btn mt-4">Visit Now</a>    </div>
           </div>
          </div>
        </div>
      </div>
    </section>
                
    <section>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-xl-8">
            <div class="cta-wrapper bg_img border-radius--10 text-center" data-background="/aset/img/bgBlue/bg4.jpg">
              <h2 class="title mb-3">HeroPorts</h2>
              <p>Aplikasi Transportasi Online yang mencakup semua jenis kenderaan seperti Ojek Online, Taksi Online dan pembelian Tiket Online untuk Bus, Kereta Api dan Pesawat.</p>
              <a href="#" class="cmn-btn mt-4">Visit Now</a>    </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <section>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-xl-8">
            <div class="cta-wrapper bg_img border-radius--10 text-center" data-background="/aset/img/bgBlue/bg4.jpg">
              <h2 class="title mb-3">HeroAds</h2>
              <p>Aplikasi Advertising (Periklanan) HHC yang akan mempertemukan antara pemilik Brand dengan para member HHC yang terus berkembang secara multiply. Para Member HHC akan mendapatkan Bonus hanya dengan nonton Video Iklan.</p>
              <a href="#" class="cmn-btn mt-4">Visit Now</a>    </div>
            </div>
          </div>
        </div>
      </div>
    </section>
   
    <section>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-xl-8">
            <div class="cta-wrapper bg_img border-radius--10 text-center" data-background="/aset/img/bgBlue/bg4.jpg">
              <h2 class="title mb-3">HeroMoX</h2>
              <p>Platform Investasi Perdagangan Mata Uang (Forex) yang terpercaya dan minim resiko.</p>
              <a href="#" class="cmn-btn mt-4">Visit Now</a>    </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <section class="pb-120">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-xl-8">
            <div class="cta-wrapper bg_img border-radius--10 text-center" data-background="/aset/img/bgBlue/bg4.jpg">
              <h2 class="title mb-3">HeroCX</h2>
              <p>Platform Investasi dan Mining Cryto Currency yang terpercaya dan minim resiko.</p>
              <a href="#" class="cmn-btn mt-4">Visit Now</a>    </div>
            </div>
          </div>
        </div>
      </div>
    </section>
      
    <div class="container">
        <div class="col-sm-6 wow slideInRight" data-wow-duration="2s" style="visibility: visible; animation-duration: 2s; animation-name: slideInRight">
            <div class="about-content">
              <h2 class="section-title mb-3 mt-3"><b class="base--color">Non Profitable Platforms</b></h2>
            </div>            
          </div>
    </div>
    
    <section>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-xl-8">
            <div class="cta-wrapper bg_img border-radius--10 text-center" data-background="/aset/img/bgBlue/bg4.jpg">
              <h2 class="title mb-3">Empathy</h2>
              <p>Reservoir Donation Center. Kami juga memberikan fasilitas kepada Anda untuk bersedekah secara online & offline baik dalam skala individu maupun kelompok/organisasi untuk disalurkan secara Cepat dan Tepat. Bagi yang sudah menjadi member HHC telah ada fitur sedekah otomatis melalui menu Dashboard Member didalam tiap-tiap akun pribadinya.
              </p>
              <a href="/platform/empathy" class="cmn-btn mt-4">Visit Now</a>    </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <section>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-xl-8">
            <div class="cta-wrapper bg_img border-radius--10 text-center" data-background="/aset/img/bgBlue/bg4.jpg">
              <h2 class="title mb-3">Vichar</h2>
              <p>Video Charity Channel. Berbuat untuk amal kebaikan kini menjadi sangat mudah namun sangat berarti dan berdampak positif yang besar. Karena dengan hanya Anda selalu menonton video-video di chanel ini, maka hasil monetisasi dari youtube akan terus meningkat dimana semua pendapatan dari monetisasi itu 100% akan di salurkan untuk program-program amal melalui platform <b>Empathy HHC.</b>
              </p>
              <a href="/platform/vichar" class="cmn-btn mt-4">Visit Now</a>    </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <section>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-xl-8">
            <div class="cta-wrapper bg_img border-radius--10 text-center" data-background="/aset/img/bgBlue/bg4.jpg">
              <h2 class="title mb-3">Charger</h2>
              <p>Character Generating. Dengan CHARGER kita akan bersama-sama belajar dan membangun karaker dari para pakar dengan berbagai bidang training seperti : Character Building, Hypno Theraphy, Skill Bisnis, Skill IT, dan sebagainya.
              </p>
              <a href="/platform/charger" class="cmn-btn mt-4">Visit Now</a>    </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    