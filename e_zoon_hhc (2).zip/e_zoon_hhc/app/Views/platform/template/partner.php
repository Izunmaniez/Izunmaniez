<section class="pb-120">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-6 text-center">
            <div class="section-header">
              <h2 class="section-title"><span class="font-weight-normal">Our Company</span> <b class="base--color"> Parters</b></h2>
               </div>
          </div>
        </div><!-- row end -->
        <div class="row mb-1">
          <div class="col-lg-12">
            <div class="payment-slider">
                            <div class="single-slide">
                <div class="brand-item">
                  <img src="/aset/img/gold/bri.jpg" alt="image">
                </div><!-- brand-item end -->
              </div>
                            <div class="single-slide">
                <div class="brand-item">
                  <img src="/aset/img/gold/bsi.jpg" alt="image">
                </div><!-- brand-item end -->
              </div>
                            <div class="single-slide">
                <div class="brand-item">
                  <img src="/aset/img/gold/bni.jpg" alt="image">
                </div><!-- brand-item end -->
              </div>
                            <div class="single-slide">
                <div class="brand-item">
                  <img src="/aset/img/gold/bca.jpg" alt="image">
                </div><!-- brand-item end -->
              </div>
                            <div class="single-slide">
                <div class="brand-item">
                  <img src="/aset/img/gold/mandiri.jpg" alt="image">
                </div><!-- brand-item end -->
              </div>
                            <div class="single-slide">
                <div class="brand-item">
                  <img src="/aset/img/gold/linkaja.jpg" alt="image">
                </div><!-- brand-item end -->
              </div>
                            <div class="single-slide">
                <div class="brand-item">
                  <img src="/aset/img/gold/ovo.jpg" alt="image">
                </div><!-- brand-item end -->
              </div>
                            <div class="single-slide">
                <div class="brand-item">
                  <img src="/aset/img/gold/dana.jpg" alt="image">
                </div><!-- brand-item end -->
              </div>
                            
                          </div><!-- payment-slider end -->
          </div>
        </div>
      </div>
    </section>