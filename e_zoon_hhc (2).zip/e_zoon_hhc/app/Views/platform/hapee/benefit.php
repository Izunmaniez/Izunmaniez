<?= $this-> extend('platform/hapee/template/index'); ?>

<?= $this-> section('content'); ?>
<?= $this->include('platform/hapee/template/navbar');?>

    <section class="pt-120 pb-150">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-sm-6 text-center mt-7">
            <div class="section-header">
              <div class="package-card__title base--color">Mari kita mulai dari yang</i><b> GRATIS...!!!</b>   
              </div>         
              <p>Anda tidak harus keluar uang sepeser pun untuk memulai sebuah bisnis besar. Dan Anda diberi fasilitas Toko Online di <b class="section-title base--color">Hapee</b> secara gratis dengan potensi pasar yang sudah terorganisir dan terintegrasi dengan Platform Network Marketing <b class="section-title base--color">Swizh</b> dengan jumlah member yang terus berkembang secara Multiply (Zombie Effect System).</p>
            </div>
          </div>
        
        
          <div class="col-xl-3 col-lg-6 col-md-6 mt-7 mb-30 wow zoomout" data-wow-duration="3s" style="visibility: visible; animation-duration: 5s; animation-name: bounceIn;">
            <div class="package-card text-center text-light bg--base">
              <h4 class="package-card__title mb-2">Free Member</h4>              
              <div class="package-card__features mt-4">
                <b>Bonus belanJA PRIbadi (JAPRI)
                <h4 class="package-card__features p--color">9℅</h4></b>                
                <b>Bonus belanJA REferal  (JARE)
                <h4 class="package-card__features p--color">9℅</h4></b>                
                <b>Bonus Get Pro Seller (GPS)
                <h4 class="package-card__features p--color">5℅</h4></b>                                           
              </div>            
            <div class="package-card__range mt-1">Modal              
             <span class="p--color"> RP. 0,-</span>
            </div>
              <a class="btn bg-light mt-4" href="/register">Daftar Sekarang</a>
          </div><!-- package-card end -->
         </div>                                                                                                                    
       </div>
 </section>
 
 <section class="pb-150">
   <div class="container">  
      <div class="row justify-content-center">  
         <div class="col-sm-6 mt-30 wow slideInLeft" data-wow-duration="2s" style="visibility: visible; animation-duration: 2s; animation-name: slideInLeft;">
            <div class="package-card text-center text-light bg-dark">
Bonus dihitung dari nilai PV (Point Value) yang tertera bersama label disetiap produk, dimana besar kecilnya PV ditentukan oleh Pemilik Toko yang telah diverifikasi untuk menjadi Pro Seller (Penjual Profesional) di market place <b class="section-title base--color">Hapee.</b>
                <div class="package-card__features mt-3">Bagi Member Premium (Sudah berbelanja Paket Produk Swizh), Seluruh<b> Omset Anda dan Grup Anda</b> di Market Place akan terakumulasi dan terintegrasi dengan omset yang ada di Business Plan <a href="#"><b><span class="package-card__title base--color">Swizh</span></b></a> dalam sistem perhitungan kwalifikasi Reward.                              
                </div>
             </div>  
          </div>  
            
          <div class="col-xl-3 col-lg-6 col-md-6 mb-30 mt-30 wow zoomout" data-wow-duration="3s" style="visibility: visible; animation-duration: 5s; animation-name: bounceIn;">   
            <h3 class="btn cmn-btn mb-2">PREMIUM MEMBER</h3>                   
            <div class="package-card text-center bg-light">                                
            <?= $this->include('platform/hapee/template/sliderBenefit');?>                    
               <div class="package-card__features mt-4">         
                <b>Bonus belanJA REferal  (JARE)
                <h4 class="package-card__features base--color">10℅</h4></b>
                <b>Bonus Get Pro Seller (GPS)
                <h4 class="package-card__features base--color">5℅</h4></b>
                <b>Bonus Lebaran (THR)
                <h4><span class="package-card__features base--color">10℅</h4></span>
                dari (PV) Omset Market Place selama setahun.</b>                                                      
               </div>
              <a class="btn cmn-btn mt-4 mb-0" href="/users">Upgrade Sekarang</a>      
             </div>   
          </div><!-- col end -->                 
      </div><!-- row end -->                                                                                                                    
   </div><!-- container end -->   
</section>
   
<section class="pb-150">
   <div class="container">  
     <div class="row justify-content-center">
       <div class="col-lg-12 wow slideInRight" data-wow-duration="2s" style="visibility: visible; animation-duration: 2s; animation-name: slideInRight">      
          <div class="section-header mb-3">
             <div class="section-title">Pertanyaan <span class="font-weight-normal base--color"><b> yang selalu diajukan</b></span> 
             </div>
          </div>
     
           <div class="accordion cmn-accordion" id="accordionExample">
              <div class="card bg--base">
                <div class="card-header" id="heading0">
                  <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapse0" aria-expanded="false" aria-controls="collapse0">
                      <i class="fas fa-question-circle"></i>
                      <span>Menjadi anggota komunitas di HHC itu gratis, benarkah kemudian bisa mendapatkan penghasilan?</span>
                    </button>
                  </h2>
                </div>           
                <div id="collapse0" class="collapse" aria-labelledby="heading0" data-parent="#accordionExample" style="">
                   <div class="card-body base--color">
                   Ya! Benar-benar gratis! Anda akan mendapatkan penghasilan ketika Anda mereferensikan orang lain kemudian orang tersebut melakukan perbelanjaan pribadinya di market place <b>Hapee</b> walaupun Anda belum pernah melakukan perbelanjaan pribadi sekalipun. Semakin banyak orang yang Anda referensikan maka akan semakin besar peluang Anda untuk memperoleh penghasilan.
                   </div>
                </div>
              </div><!-- card end -->  
               
              <div class="card">
                <div class="card-header" id="heading1">
                  <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapse1" aria-expanded="false" aria-controls="collapse1">
                      <i class="fas fa-question-circle"></i>
                      <span>Bagaimana saya mengetahui setiap perkembangan bisnis saya? </span>
                    </button>
                  </h2>
                </div>           
                   <div id="collapse1" class="collapse" aria-labelledby="heading1" data-parent="#accordionExample" style="">
                       <div class="card-body base--color">
                    Anda dapat melihat ini kapan saja di dasbor akun Anda.
                       </div>
                     </div>
                 </div> 
                                                  
               <div class="card">
                 <div class="card-header" id="heading1">
                  <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapse2" aria-expanded="false" aria-controls="collapse1">
                      <i class="fas fa-question-circle"></i>
                      <span>Bagaimana saya mengetahui setia barang-barang apa saja yang sudah laku terjual dari toko (Profesional Seller) yang saya  Sponsori? Karena saya akan turut memperoleh fee dari setiap transaksi itu.</span>
                    </button>
                  </h2>
                </div>           
                   <div id="collapse2" class="collapse" aria-labelledby="heading1" data-parent="#accordionExample" style="">
                       <div class="card-body base--color">
                    Anda dapat melihat ini kapan saja di dasbor akun Anda.
                    </div>
                   </div>
                 </div>   
                          
                
                <div class="card">
                    <div class="card-header" id="heading2">
                    <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapse3" aria-expanded="false" aria-controls="collapse2">
                      <i class="fas fa-question-circle"></i>
                      <span>Saya lupa kata sandi saya, apa yang harus saya lakukan?</span>
                    </button>
                    </h2>
                    </div>            
                    <div id="collapse3" class="collapse" aria-labelledby="heading2" data-parent="#accordionExample" style="">
                      <div class="card-body base--color">
                    Klik tulisan "Lupa Password di posisi paling bawah pada form login, lalu ketik alamat email Anda dan klik tombol `Reset`. 
                  </div>
                </div>
             </div><!-- card end -->  
                            
             <div class="card">
                <div class="card-header" id="heading3">
                  <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapse4" aria-expanded="false" aria-controls="collapse3">
                      <i class="fas fa-question-circle"></i>
                      <span>Bagaimana saya mengetahui pendapatan saya sudah masuk ke rekening saya?</span>
                    </button>
                  </h2>
                </div>            
                <div id="collapse4" class="collapse" aria-labelledby="heading3" data-parent="#accordionExample" style="">
                  <div class="card-body base--color">
                    Anda akan mendapatkan pemberitahuan otomatis melalui kontak What's up Anda setelah kami lakukan transfer bonus ke rekening Anda dan Anda selalu dapat memeriksa setiap transaksi di akun Anda.
                  </div>
                </div>
              </div><!-- card end -->  
              
              <div class="card">
                <div class="card-header" id="heading4">
                  <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapse5" aria-expanded="false" aria-controls="collapse4">
                      <i class="fas fa-question-circle"></i>
                      <span>Seberapa sering saya menerima pendapatan yang masuk ke rekening saya?</span>
                    </button>
                  </h2>
                </div>           
                <div id="collapse5" class="collapse" aria-labelledby="heading4" data-parent="#accordionExample" style="">
                  <div class="card-body base--color">
                    Kami melakukan pentransferan bonus dari omset Market Place setiap satu bulan sekali. Namun kami menyediakan platform lainnya yang melakukan pembayaran bonus-bonus secara mingguan, bulanan dan tahunan.                         
                  </div>
                </div>                                                       
             </div><!-- card end -->  
                 
               
            
          </div>
        </div>
     </div>   
   </div><!-- row end -->      
</section>          
    
                  
    
<?= $this->endSection();?>


