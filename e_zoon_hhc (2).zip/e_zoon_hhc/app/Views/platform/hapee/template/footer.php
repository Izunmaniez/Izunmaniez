<div class="container">
  <footer>
    <div class="footer">

        <a href="/hapee/blogs" class="footer-item"><img src="/aset/img/bar/blog.png"><br>Blogs</p></a>
        <a href="/hapee/benefit" class="footer-item"><img src="/aset/img/bar/benefit.png"><br>Benefit</a>   

        <a class="footer-item-middle" data-toggle="modal" data-target="#modal-platform"><img src="/aset/img/bar/logohhc.png">
        </a>



  <div class="modal fade" id="modal-platform">
    <div class="modal-dialog modal-platform">          
      <div class="modal-content">      
        <div class="modal-body">
        


         

   <h2 class="platform-judul-item">Platform HHC</h2>

<div class="container-platform">

<a href="/"class="platform-item"><img src="/aset/img/bar/platform_item.png"><br><b>Hapee</b><p><small>Market Place</small></p></a>

<a href="#"class="platform-item" style="color:black"><img src="/aset/img/bar/platform_item.png"><br><b>Shotoo</b><p><small>Shoping Ofline</small></p></a>

<a href="/platform/swizh" class="platform-item"><img src="/aset/img/bar/platform_item.png"><br><b>Swizh</b><p><small>Network Marketing</small></p></a>

<a href="#"class="platform-item" style="color:black;"><img src="/aset/img/bar/platform_item.png"><br><b>HeroPorts</b><p><small>Transports Apps</small></p></a>

<a href="#"class="platform-item" style="color:black;"><img src="/aset/img/bar/platform_item.png"><br><b>HeroAds</b><p><small>Advertising Apps</small></p></a>

<a href="#" class="platform-item" style="color:black;"><img src="/aset/img/bar/platform_item.png"><br><b>HeroMoX</b><p><small>Currency Invesment</small></p></a>
    
<a href="#" class="platform-item" style="color:black;"><img src="/aset/img/bar/platform_item.png"><br><b>HeroCX</b><p><small>Crypto Currency</small></p></a>
        
<a href="/platform/empathy"class="platform-item"><img src="/aset/img/bar/platform_item.png"><br><b>Empathy</b><p><small> Donation Center</small></p></a>

<a href="/platform/vichar"class="platform-item"><img src="/aset/img/bar/platform_item.png"><br><b>Vichar</b><p><small>Video Charity</small></p></a>

<a href="/platform/charger"class="platform-item"><img src="/aset/img/bar/platform_item.png"><br><b>Charger</b><p><small>Character Generating</small></p></a>
  
   </div>

          <a href="/platform" class="btn btn-info mt-4">Tentang Kami</a>             
          <button type="button" class="btn btn-success mt-4" data-dismiss="modal">Aye..?!!😀</button>
              
             </div>
          </div>
        </div>
     </div>
    
  






          <a href="/" class="footer-item"><img src="/aset/img/bar/hapee.png"><br>Shoping</a>
          <a href="/users" class="footer-item"><img src="/aset/img/bar/login.png"><br>Account</a>   
     </div>   
  </footer>
</div>
  
  
  
  
  
  
  
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <!-- Option 2: jQuery, Popper.js, and Bootstrap JS
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    -->
    

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
    -->
    
    
  </body>
</html>

  
  
  
  
  
  
