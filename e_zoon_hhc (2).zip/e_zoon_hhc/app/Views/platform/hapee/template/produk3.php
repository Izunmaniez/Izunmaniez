<div class="container">  
   <div class="produkHome">   
     <a href="https://api.whatsapp.com/send?phone=62823-6791-8581&text=Hallo..Admin Hapee - HHC,%20Saya %20ingin%20Menyewa%20Lapak%20Lokasi%20Strategis di HapeeðŸ¥º" class="produk"><img src="/aset/img/produkHome/lapakSewaHHC.png"> 
     <div class="namaProduk">LOKASI STRATEGIS
     </div> 
        <div class="brandProduk">DISEWAKAN
        </div> 
           <div class="hargaProduk">Hubungi Admin
           </div>  
     </a>
     <a href="https://api.whatsapp.com/send?phone=62823-6791-8581&text=Hallo..Admin Hapee HHC, %20Saya %20ingin%20Menyewa%20Lapak%20Lokasi%20Strategis di HapeeðŸ¥º" class="produk"><img src="/aset/img/produkHome/lapakSewaHHC.png"> 
              <div class="namaProduk">LOKASI STRATEGIS
              </div> 
                 <div class="brandProduk">DISEWAKAN
                 </div> 
                    <div class="hargaProduk">Hubungi Admin
                    </div>  
      </a>
   </div>
</div>

<div class="container">     
   <div class="produkHome">   
      <form action="" method="post" enctype="multipart/form-data">
      <?= csrf_field(); ?>          
      <?php foreach ($produk as $prod) : ?>   
      <a class="produk" data-toggle="modal" data-target="#modal-xl-produkDetail" name="view" value="View" data-id="<?php echo $prod["id"]; ?>" >
      <img src="/aset/img/produkHome/<?=$prod['image']; ?>">
      <div class="namaProduk"><?=$prod['nama_produk']; ?>   
      </div> 
         <div class="hargaProduk">Brand:<span class="brandProduk"> <?=$prod['brand']; ?></span>
         </div> 
            <div class="hargaProduk"><b>Rp. <?=number_format ($prod['harga'], 0, ".", "."); ?>,-</b><span class="badge badge-info text-sm text-light elevation-3 ml-2 mb-1">  PV <?=$prod['pv']; ?>℅</span>
            </div>  
      </a>
      <?php endforeach; ?>                                                 
      </form>    
   </div>
               

 <div id="modal-xl-produkDetail" class="modal fade">  
    <div class="modal-dialog">  
         <div class="modal-content">  
              <div class="modal-header">  
                   <h4 class="modal-title">Detail Produk</h4>  
              </div>  
              <div class="modal-body" id="produk_detail">  
              
<?php  
if(isset($_POST["data_id"])){
	$data_id = $_POST["data_id"];
	$output = "";
	$connect = mysqli_connect('localhost', 'hamdala2_ci4_hhc', '', 'produk');  
	$query = "SELECT * FROM produk WHERE id = '$data_id' ";  
	$result = mysqli_query($connect, $query); 
	$output .= '
<div class="table-responsive">  
	<table class="table table-bordered">'; 
	$row = mysqli_fetch_array($result);
     $output .= '  
          <tr>  
               <td width="30%"><label>Nama Produk</label></td>  
               <td width="70%">'.$prod["nama_produk"].'</td>  
          </tr>
          <tr>  
               <td width="30%"><label>Harga</label></td>  
               <td width="70%">'.$prod["harga"].'</td>  
          </tr>  
          <tr>  
               <td width="30%"><label>Point Value : </label></td>  
               <td width="70%">'.$prod["pv"].'</td>  
          </tr>
          ';    
$output .= "
	</table>
</div>";  
echo $output;  
}
 
?>
              
                         
              </div>  
              <div class="modal-footer">  
                   <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
              </div>  
         </div>  
    </div>  
</div> 
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script>
$(document).ready(function(){
	$('.view_data').click(function(){
		var data_id = $(this).data("id")
		$.ajax({
			url: "proses.php",
			method: "POST",
			data: {data_id: data_id},
			success: function(data){
				$("#produk_detail").html(data)
				$("#modal-xl-produkDetail").modal('show')
			}
		})
	})
})
</script>
   
         