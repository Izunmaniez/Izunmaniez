<section class="slider-section pt-0 pb-0">

            <div class="slider-inner">
                <div class="row">
                    
                    <div class="col">
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner shadow-sm rounded ">
    <div class="carousel-item active">
                <h3 class="cmn-btn mb-2">WHITE<br>MANAGER</h3>              
              <div class="package-card__features mt-4">
                <b>Bonus belanJA PRIbadi (JAPRI)
                <h4 class="package-card__features base--color">10℅</h4></b>                
              </div>              
    </div>
    <div class="carousel-item">
                <h3 class="cmn-btn mb-2">YELLOW<br>MANAGER</h3>              
              <div class="package-card__features mt-4">
                <b>Bonus belanJA PRIbadi (JAPRI)
                <h4 class="package-card__features base--color">12℅</h4></b>                
              </div>              
    </div>
    <div class="carousel-item">
                <h3 class="cmn-btn mb-2">GREEN<br>MANAGER</h3>              
              <div class="package-card__features mt-4">
                <b>Bonus belanJA PRIbadi (JAPRI)
                <h4 class="package-card__features base--color">14℅</h4></b>                
              </div>              
     </div>
<div class="carousel-item">
                <h3 class="cmn-btn mb-2">BLUE<br>MANAGER</h3>              
              <div class="package-card__features mt-4">
                <b>Bonus belanJA PRIbadi (JAPRI)
                <h4 class="package-card__features base--color">16℅</h4></b>                
              </div>              
    </div>
    <div class="carousel-item">
                <h3 class="cmn-btn mb-2">RED<br>MANAGER</h3>              
              <div class="package-card__features mt-4">
                <b>Bonus belanJA PRIbadi (JAPRI)
                <h4 class="package-card__features base--color">18℅</h4></b>                
              </div>              
    </div>
    <div class="carousel-item">
                <h3 class="cmn-btn mb-2">BLACK<br>MANAGER</h3>              
              <div class="package-card__features mt-4">
                <b>Bonus belanJA PRIbadi (JAPRI)
                <h4 class="package-card__features base--color">20℅</h4></b>                
              </div>              
    </div>
    <div class="carousel-item">
                <h3 class="cmn-btn mb-2">LEADERSHIP<br>DIRECTOR</h3>              
              <div class="package-card__features mt-4">
                <b>Bonus belanJA PRIbadi (JAPRI)
                <h4 class="package-card__features base--color">20℅</h4></b>                
              </div>              
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon text-success" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon text-success" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>
</div>
</div>

</section>