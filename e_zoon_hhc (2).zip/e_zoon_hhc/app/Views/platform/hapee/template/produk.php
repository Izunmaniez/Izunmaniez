<div class="container">  
   <div class="produkHome">   
     <a href="https://api.whatsapp.com/send?phone=62823-6791-8581&text=Hallo..Admin Hapee - HHC,%20Saya %20ingin%20Menyewa%20Lapak%20Lokasi%20Strategis di HapeeðŸ¥º" class="produk"><img src="/aset/img/produkHome/lapakSewaHHC.png"> 
     <div class="namaProduk">LOKASI STRATEGIS
     </div> 
        <div class="brandProduk">DISEWAKAN
        </div> 
           <div class="hargaProduk">Hubungi Admin
           </div>  
     </a>
     <a href="https://api.whatsapp.com/send?phone=62823-6791-8581&text=Hallo..Admin Hapee HHC, %20Saya %20ingin%20Menyewa%20Lapak%20Lokasi%20Strategis di HapeeðŸ¥º" class="produk"><img src="/aset/img/produkHome/lapakSewaHHC.png"> 
              <div class="namaProduk">LOKASI STRATEGIS
              </div> 
                 <div class="brandProduk">DISEWAKAN
                 </div> 
                    <div class="hargaProduk">Hubungi Admin
                    </div>  
      </a>
   </div>
</div>

<div class="container">     
   <div class="produkHome">   
      <form action="" method="post" enctype="multipart/form-data">
      <?= csrf_field(); ?>          
      <?php foreach ($produk as $prod) : ?>   
      <a href="<?= base_url ('hapee/produk_detail/' . $prod['id']); ?>" class="produk">      
      <img src="/aset/img/produkHome/<?=$prod['image']; ?>"> 
      <div class="namaProduk"><?=$prod['nama_produk']; ?>   
      </div> 
         <div class="hargaProduk"><b>Rp. <?=number_format ($prod['harga'], 0, ".", "."); ?>,-</b><span class="badge badge-info text-sm text-light elevation-3 ml-2 mb-1">  PV <?=$prod['pv']; ?>℅</span>
            </div>  
      </a>
      <?php endforeach; ?>                                                 
      </form>    
   </div>
 </div>
   
         