 <hr>
 <hr>

 <div class="copyright">         
             
 <div class="copyright-item">~ Copyright &#169 <script>document.write(new Date().getFullYear())</script>   Powered by : HHC ~</div>
 
</div>