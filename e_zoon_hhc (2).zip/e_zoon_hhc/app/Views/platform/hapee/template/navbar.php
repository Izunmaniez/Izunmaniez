<div class="container">
  <nav>
    <div class="navbar-index">
    <a href="/" class="navbar-brand"><img src="/aset/img/bar/hapee1.png"></a>
      
    <!-- SEARCH FORM -->
    <form action="" method="get"  class="form-inline-hp">
      <div class="input-group input-group-sm">
        <input class="form-control-hp form-control-navbar" type="search" placeholder="Search" aria-label="Search">
          <div class="input-group-append">
          <button class="btn btn-navbar" type="submit">
            
          </button>
        </div>
      </div>
    </form>

    <a href="<?= route_to('register') ?>" class="mendaftar">Daftar<br>Gratis</a>
    </div>
  </nav>
</div>