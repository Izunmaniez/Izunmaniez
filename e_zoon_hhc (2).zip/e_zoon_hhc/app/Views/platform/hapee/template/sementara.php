<div class="modal fade" id="modal-xl-produkDetail">
   <div class="modal-dialog modal-xl-produkDetail">
       <div class="modal-content">
           <div class="modal-header">
            <h4 class="modal-title">Data Bonus Real Time</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
            </div>         
            <div class="modal-body">       
   
              <section class="content-header">
                   <div class="container-fluid">
                     <div class="row">
                       <div class="col-sm-6">
                          <h1><b><?= user()->nama_toko; ?></b></h1>
                       </div>        
                     </div>
                   </div><!-- /.container-fluid -->
                </section>
                 
                 <section class="content">   
                    <div class="slider-section">
                      <div class="row">
                         <div class="col-12 col-sm-6">
                            <div class="card-body">
                               <div class="card card-solid">          
                                  <div class="container">
                                     <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                                       <div class="carousel-inner shadow-sm rounded ">
                                          <div class="carousel-item active">
                                             <img src="/aset/img/produkHome/swiz100ml.jpg" class="d-block w-100" style="height:190px; margin-bottom:13px;">
                                          </div>
                                          <div class="carousel-item">
                                             <img src="/aset/img/produkHome/swiz30ml.jpg" class="d-block w-100"  style="height:190px; margin-bottom:13px;">
                                          </div>
                                          <div class="carousel-item">
                                             <img src="/aset/img/produkHome/sepatu_bunut.jpg" class="d-block w-100"  style="height:190px; margin-bottom:13px;">
                                          </div>
                                          <div class="carousel-item">
                                             <img src="/aset/img/produkHome/kutus.jpg" class="d-block w-100"  style="height:190px; margin-bottom:13px;">
                                          </div>
                                       </div>
                                          <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                                          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                          <span class="sr-only">Previous</span>
                                          </a>
                                          <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                                          <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                          <span class="sr-only">Next</span>
                                          </a>
                                    </div>
                                  </div>
                               </div>
                               
                               <div class="card-body" style="overflow:auto;">
                               <table> 
                                  <tr>
                                     <td>Merk</td>
                                     <td>:</td>
                                     <td><?= user()->fullname; ?> </td>
                                  </tr> 
                                  <tr>
                                     <td>Kategori</td>
                                     <td>:</td>
                                     <td><?= user()->username; ?> </td>
                                  </tr> 
                                  <tr>
                                     <td>Harga</td>
                                     <td>:</td>
                                     <td><?= user()->telp; ?> </td>
                                  </tr> 
                                  <tr>
                                     <td>PV</td>
                                     <td>:</td>
                                     <td><?= user()->norek; ?> </td>
                                  </tr> 
                               </table>
                               </div> 
                            </div>
                         </div>                                                                                                
       
            <div class="col-12 col-sm-6">
              
              <hr>
              <h4>Pilih Warna Favoritmu ya sob..</h4>
              <div class="btn-group btn-group-toggle" data-toggle="buttons">
                <label class="btn btn-default text-center active">
                  <input type="radio" name="color_option" id="color_option1" autocomplete="off" checked="">
                  Hijau
                  <br>
                  <i class="fas fa-circle fa-2x text-green"></i>
                </label>
                <label class="btn btn-default text-center">
                  <input type="radio" name="color_option" id="color_option2" autocomplete="off">
                  Biru
                  <br>
                  <i class="fas fa-circle fa-2x text-blue"></i>
                </label>
                <label class="btn btn-default text-center">
                  <input type="radio" name="color_option" id="color_option3" autocomplete="off">
                  Ungu
                  <br>
                  <i class="fas fa-circle fa-2x text-purple"></i>
                </label>
                <label class="btn btn-default text-center">
                  <input type="radio" name="color_option" id="color_option4" autocomplete="off">
                  Merah
                  <br>
                  <i class="fas fa-circle fa-2x text-red"></i>
                </label>
                <label class="btn btn-default text-center">
                  <input type="radio" name="color_option" id="color_option5" autocomplete="off">
                  Orange
                  <br>
                  <i class="fas fa-circle fa-2x text-orange"></i>
                </label>
              </div>

              <h4 class="mt-3">Pilih Size <small>yang pas untukmu..</small></h4>
              <div class="btn-group btn-group-toggle" data-toggle="buttons">
                <label class="btn btn-default text-center">
                  <input type="radio" name="color_option" id="color_option1" autocomplete="off">
                  <span class="text-xl">S</span>
                  <br>
                  Small
                </label>
                <label class="btn btn-default text-center">
                  <input type="radio" name="color_option" id="color_option1" autocomplete="off">
                  <span class="text-xl">M</span>
                  <br>
                  Medium
                </label>
                <label class="btn btn-default text-center">
                  <input type="radio" name="color_option" id="color_option1" autocomplete="off">
                  <span class="text-xl">L</span>
                  <br>
                  Large
                </label>
                <label class="btn btn-default text-center">
                  <input type="radio" name="color_option" id="color_option1" autocomplete="off">
                  <span class="text-xl">XL</span>
                  <br>
                  Xtra-Large
                </label>
              </div>

              <div class="bg-pink py-2 px-3 mt-4">
                <h2 class="mb-0">
                  pH : 35%
                </h2>
                <h4 class="mt-0">
                  <small>Rp.700.000,- </small>
                </h4>
              </div>

              <div class="mt-4">
                <div class="btn btn-primary btn-lg d-block">
                  <i class="fas fa-cart-plus fa-lg mr-2"></i> 
                  Masukkan ke Keranjang
                </div>
<p>
                <div class="btn btn-success btn-lg d-block">
                  <i class="fas fa-coin fa-lg mr-2"></i> 
                  <b>BELI SEKARANG</b>
                </div>
              </div>

              <div class="mt-4 product-share">
                <a href="#" class="text-gray">
                  <i class="fab fa-facebook-square fa-2x"></i>
                </a>
                <a href="#" class="text-gray">
                  <i class="fab fa-twitter-square fa-2x"></i>
                </a>
                <a href="#" class="text-gray">
                  <i class="fas fa-envelope-square fa-2x"></i>
                </a>
                <a href="#" class="text-gray">
                  <i class="fas fa-rss-square fa-2x"></i>
                </a>
              </div>

            </div>
          </div>
          <div class="row mt-4">
            <nav class="w-100">
              <div class="nav nav-tabs" id="product-tab" role="tablist">
                <a class="nav-item nav-link active" id="product-desc-tab" data-toggle="tab" href="#product-desc" role="tab" aria-controls="product-desc" aria-selected="true">Deskripsi</a>
                <a class="nav-item nav-link" id="product-comments-tab" data-toggle="tab" href="#product-comments" role="tab" aria-controls="product-comments" aria-selected="false">Comments</a>
                <a class="nav-item nav-link" id="product-rating-tab" data-toggle="tab" href="#product-rating" role="tab" aria-controls="product-rating" aria-selected="false">Rating</a>
              </div>
            </nav>
            <div class="tab-content p-3" id="nav-tabContent">
              <div class="tab-pane fade show active" id="product-desc" role="tabpanel" aria-labelledby="product-desc-tab"> Deskripsi Produk 
              </div>
              <div class="tab-pane fade" id="product-comments" role="tabpanel" aria-labelledby="product-comments-tab"> Komentar Pembeli
              </div>
              <div class="tab-pane fade" id="product-rating" role="tabpanel" aria-labelledby="product-rating-tab"> Star
              </div>
            </div>
          </div>
        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
  </div>


</div>
</div>
</div>
</div>
</div>