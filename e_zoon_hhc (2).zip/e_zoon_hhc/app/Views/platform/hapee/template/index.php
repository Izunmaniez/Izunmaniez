<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">    
    
    <!-- My CSS -->
    <link rel="stylesheet" href="/aset/css/style.css">
    <link rel="stylesheet" href="/aset/css/front/content1.css">
    <link rel="stylesheet" href="/aset/css/front/content2.css">
    <link rel="stylesheet" href="/aset/css/front/content3.css">
    
    
    <!-- line-awesome webfont -->
    <link rel="stylesheet" href="<?= base_url(); ?>/aset/css/front/line-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>/aset/css/front/animate.min.css">

    <!-- fontawesome 5  -->
    <link rel="stylesheet" href="<?= base_url(); ?>/plugins/fontawesome-free/css/all.min.css">
    

    <title><?= $title; ?></title>
  </head>
  <body>
      
<?= $this->renderSection('content');?>      



<?= $this->include('platform/hapee/template/copyright');?>
      
<?= $this->include('platform/hapee/template/footer');?>



