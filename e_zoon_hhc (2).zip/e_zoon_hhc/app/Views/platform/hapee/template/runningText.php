<div class="container"> 
  <div class="running-text">        
    <marquee behavior=”scroll” direction=”right”>
    <b class="base--color"> Hapee</b> {HHC e-commerce - Market Place}
    <b class="base--color"> Shotoo</b> {Shopping Offline To Online}
    <b class="base--color"> Swizh</b> {Network Marketing}
    <b class="base--color"> HeroPorts</b> {Transports Apps} 
    <b class="base--color"> HeroAds</b> {Advertising HHC} 
    <b class="base--color"> HeroMoX</b> {Currency Investment}
    <b class="base--color"> HeroCX</b> {Crypto Currency Investment}
    <b class="base--color"> Empathy</b> {Reservoir Donation Center}
    <b class="base--color"> Charger</b> {Character Generating}
    <b class="base--color"> Vichar</b> {Video Charity}
    </marquee>
  </div> 
</div> 