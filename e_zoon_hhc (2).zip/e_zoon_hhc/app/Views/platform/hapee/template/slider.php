<section class="slider-section pt-0 pb-0">
<div class="container">
            <div class="slider-inner">
                <div class="row">
                    
                    <div class="col">
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner shadow-sm rounded ">
    <a href="/platform/swizh" class="carousel-item active">
      <img src="/aset/img/sliderHome/swizhCoffee.jpg" class="d-block w-100" style="height:130px";
      alt="...">
    </a>
    <a href="/platform/swizh" class="carousel-item">
      <img src="/aset/img/sliderHome/swizhOil.jpg" class="d-block w-100" style="height:130px;" alt="...">
    </a>
    <a href="/platform/swizh" class="carousel-item">
      <img src="/aset/img/sliderHome/swizhCandy.jpg" class="d-block w-100" style="height:130px;" alt=...>
    </a>
    <a href="/platform/swizh" class="carousel-item">
      <img src="/aset/img/sliderHome/swizhParfum.png" class="d-block w-100" style="height:130px;" alt=...>
    </a>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>
</div>
</div>
</div>
</section>