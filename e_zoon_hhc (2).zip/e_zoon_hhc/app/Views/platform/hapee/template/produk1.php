<div class="container">  
   <div class="produkHome">   
     <a href="https://api.whatsapp.com/send?phone=62823-6791-8581&text=Hallo..Admin Hapee - HHC,%20Saya %20ingin%20Menyewa%20Lapak%20Lokasi%20Strategis di HapeeðŸ¥º" class="produk"><img src="/aset/img/produkHome/lapakSewaHHC.png"> 
     <div class="namaProduk">LOKASI STRATEGIS
     </div> 
        <div class="brandProduk">DISEWAKAN
        </div> 
           <div class="hargaProduk">Hubungi Admin
           </div>  
     </a>
     <a href="https://api.whatsapp.com/send?phone=62823-6791-8581&text=Hallo..Admin Hapee HHC, %20Saya %20ingin%20Menyewa%20Lapak%20Lokasi%20Strategis di HapeeðŸ¥º" class="produk"><img src="/aset/img/produkHome/lapakSewaHHC.png"> 
     <div class="namaProduk">LOKASI STRATEGIS
     </div> 
       <div class="brandProduk">DISEWAKAN
       </div> 
         <div class="hargaProduk">Hubungi Admin
         </div>  
     </a>
   </div>
</div>

<div class="container">  
   <div class="produkHome">   
     <form action="" method="post" enctype="multipart/form-data">
     <?= csrf_field(); ?>          
     <?php foreach ($produk as $prod) : ?>      
     <a class="produk" data-toggle="modal" data-target="#modal-xl-produkDetail" ><img src="/aset/img/produkHome/<?=$prod['image']; ?>"> 
     <div class="namaProduk"><?=$prod['nama_produk']; ?>   
     </div> 
       <div class="hargaProduk">Brand:<span class="brandProduk"> <?=$prod['brand']; ?></span>
       </div> 
         <div class="hargaProduk"><b>Rp. <?=number_format ($prod['harga'], 0, ".", "."); ?>,-</b><span class="badge badge-info text-sm text-light elevation-3 ml-2 mb-1">  PV <?=$prod['pv']; ?>℅</span>
         </div> 
     </a>
     <?php endforeach; ?>                                                 
     </form>
   </div>
               
<div class="modal fade" id="modal-xl-produkDetail">
   <div class="modal-dialog modal-xl-produkDetail">
       <div class="modal-content">
           <div class="modal-header">
            <h4 class="modal-title">Data Bonus Real Time</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
            </div>         
            <div class="modal-body">         
              <div class="container">  
                  <div class="img img-preview">   
                     <img src="/aset/img/produkHome/sementara.jpg">
                 </div>
              </div>
              <i>
              <small>Detail Produk belum bisa ditampilkan. Pembangunan website sedang berlangsung.</small></i>
              <br>
              <p>Ada yang ingin Anda beli?<br> Atau Anda Pelaku UMKM yang punya produk untuk dijual? Segera <b>DAFTAR</b> dan <b>AMBIL LAPAK</b> di Hapee, lalu hubungi Admin untuk menindaklanjuti!</p>
              <br>          
              <div class="col-lg-6 text-center mb-2">      
               <a href="<?= route_to('register') ?>" class="cmn-btn text-uppercase font-weight-600 mb-50">Daftar</a>    
               <a href="https://api.whatsapp.com/send?phone=+62895634323332&text=Hallo..Admin Hapee - HHC, Saya Pelaku UMKM dan ingin pajang produk saya di Market Place Hapee"  class="cmn-btn text-uppercase font-weight-600 mb-50">Hubungi Admin</a>            
              </div>
              <br>
              <br>
              
            </div>

       </div>
     </div>
   </div>
 </div>
   
             
             
    