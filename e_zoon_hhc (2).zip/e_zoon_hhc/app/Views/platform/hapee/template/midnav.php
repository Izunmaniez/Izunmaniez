<section mt--3>
<div class="container">
<div class="midnav">
   <div class="row">   
      <div class="midnav-item"><img src="/aset/img/bar/kategori.png" data-toggle="modal" data-target="#modal-xl">
      <br>Semua<br>Kategori
      </div> 
      <div class="midnav-item"><img src="/aset/img/bar/terdekat.png" alt="" loading="lazy" type="button" data-toggle="collapse" data-target="#navbarSupportedContents" aria-controls="navbarSupportedContents" aria-expanded="false" aria-label="Toggle navigation">
      <br>Toko<br>Terdekat
      </div>     
      <a href="#" class="midnav-item"><img src="/aset/img/bar/bigpv.png"> 
      <br>PV<br>Gede
      </a">
      <a href="/platform/swizh" class="midnav-item"><img src="/aset/img/bar/cashback.png">
      <br>Crazy<br>Cashback
      </a>    
      <div class="midnav-item"><img src="/aset/img/bar/payment.png" alt="" loading="lazy" type="button" data-toggle="collapse" data-target="#navbarSupportedContent2" aria-controls="navbarSupportedContent2" aria-expanded="false" aria-label="Toggle navigation">
      <br>E-Payment<br>E-Voucher
      </div>    
   </div>
</div>  
</div>
</section>

<section class="nav-items" style="z-index:99999999;">
  <div class="modal fade" id="modal-xl">
     <div class="modal-dialog modal-xl">
         <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title text-dark">Pilih Kategori</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">

 <div class="row">   
<div class="nav-item">
<img src="/aset/img/category/makanan.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Makanan
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Sembako</a>
    <a class="dropdown-item" href="#">Makanan Ringan</a>
    <a class="dropdown-item" href="#">Camilan</a>
  </div>
</div>   
   
<div class="nav-item">
<img src="/aset/img/category/herbal.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Makanan<br>Kesehatan
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Makanan Kesehatan</a>
  </div>
</div>   

<div class="nav-item">
<img src="/aset/img/category/minuman.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Minuman
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Kopi</a>
    <a class="dropdown-item" href="#">Juice</a>
    <a class="dropdown-item" href="#">Energy Drink</a>
  </div>
</div>   

<div class="nav-item">
<img src="/aset/img/category/parfum.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Parfum
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Parfum</a>
  </div>
</div>   

<div class="nav-item">
<img src="/aset/img/category/kecantikan.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Kecantikan
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Kosmetika</a>
    <a class="dropdown-item" href="#">Alat Saloon Wanita</a>
 <a class="dropdown-item" href="#">Alat Saloon Pria</a>
  </div>
</div>   

<div class="nav-item">
<img src="/aset/img/category/rumah.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Rumah &<br>Taman
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Furniture</a>
    <a class="dropdown-item" href="#">Dapur Mania</a>
 <a class="dropdown-item" href="#">Toiletris</a>
 <a class="dropdown-item" href="#">Taman</a>
  </div>
</div>   

<div class="nav-item">
<img src="/aset/img/category/pakaian_wanita.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Pakaian<br>Wanita
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Muslimah</a>
    <a class="dropdown-item" href="#">Batik</a>
 <a class="dropdown-item" href="#">Kemeja</a>
<a class="dropdown-item" href="#">Kaos</a>
<a class="dropdown-item" href="#">Rok/Celana</a>
<a class="dropdown-item" href="#">Under Ware</a>
<a class="dropdown-item" href="#">Sepatu/Sendal</a>
  </div>
</div>   

<div class="nav-item">
<img src="/aset/img/category/pakaian_pria.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Pakaian<br>Pria
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Muslim</a>
    <a class="dropdown-item" href="#">Batik</a>
 <a class="dropdown-item" href="#">Kemeja</a>
<a class="dropdown-item" href="#">Kaos</a>
<a class="dropdown-item" href="#">Celana Panjang</a>
<a class="dropdown-item" href="#">Celana Pendek</a>
<a class="dropdown-item" href="#">Under Ware</a>
<a class="dropdown-item" href="#">Sepatu/Sendal</a>
  </div>
</div>   

<div class="nav-item">
<img src="/aset/img/category/pakaian_anak.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Pakaian<br>Anak
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Muslimah</a>
    <a class="dropdown-item" href="#">Batik</a>
 <a class="dropdown-item" href="#">Kemeja</a>
<a class="dropdown-item" href="#">Kaos</a>
<a class="dropdown-item" href="#">Rok/Celana</a>
<a class="dropdown-item" href="#">Under Ware</a>
<a class="dropdown-item" href="#">Sepatu/Sendal</a>
  </div>
</div>   

<div class="nav-item">
<img src="/aset/img/category/buku.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Buku &<br> Alat Tulis
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Buku Sekolah</a>
<a class="dropdown-item" href="#">Buku Tulis/Gambar</a>
    <a class="dropdown-item" href="#">Buku/Kitab Agama</a>
 <a class="dropdown-item" href="#">Buku Umum</a>
<a class="dropdown-item" href="#">Alat Tulis/Gambar</a>
<a class="dropdown-item" href="#">Buku/Alat Tulis Anak</a>
  </div>
</div>   

<div class="nav-item">
<img src="/aset/img/category/peternakan.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Peternakan
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Pakan Ternak</a>
<a class="dropdown-item" href="#">Alat peternakan</a>
  </div>
</div>

<div class="nav-item">
<img src="/aset/img/category/pertanian.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Pertanian
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Pupuk</a>
<a class="dropdown-item" href="#">Alat Pertanian</a>
    <a class="dropdown-item" href="#">Bibit</a>
<a class="dropdown-item" href="#">Buah-buahan</a>
    <a class="dropdown-item" href="#">Bunga</a>
<a class="dropdown-item" href="#">palawija</a>
  </div>
</div>

<div class="nav-item">
<img src="/aset/img/category/pertukangan.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Pertukangan
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Material Bangunan </a>
<a class="dropdown-item" href="#">Alat Kerja Tukang</a>
  </div>
</div>

<div class="nav-item">
<img src="/aset/img/category/handphone.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Handphone &<br>Aksesoris
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Handphone</a>
<a class="dropdown-item" href="#">Aksesoris</a>
<a class="dropdown-item" href="#">Alat Teknisi HP</a>
<a class="dropdown-item" href="#">Kartu Perdana</a>
  </div>
</div>

<div class="nav-item">
<img src="/aset/img/category/listrik.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Listrik
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Material Listrik</a>
 <a class="dropdown-item" href="#">Alat Teknisi Listrik</a>
  </div>
</div>

<div class="nav-item">
<img src="/aset/img/category/elektronik.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Elektronik
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
<a class="dropdown-item" href="#">Elektronik</a>
    <a class="dropdown-item" href="#">Alat Service Elektronik </a>
<a class="dropdown-item" href="#">Spare Part</a>
  </div>
</div>

<div class="nav-item">
<img src="/aset/img/category/komputer.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Komputer &<br>Laptop
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Komputer (PC)</a>
    <a class="dropdown-item" href="#">Laptop</a>
  </div>
</div>   
    
<div class="nav-item">
<img src="/aset/img/category/mobil.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Mobil
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Mobil</a>
    <a class="dropdown-item" href="#">Spare Part</a>
  </div>
</div>   
 
<div class="nav-item">
<img src="/aset/img/category/motor.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Sepeda<br>Motor
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Sepeda Motor</a>
    <a class="dropdown-item" href="#">Spare Part</a>
  </div>
</div>   

<div class="nav-item">
<img src="/aset/img/category/mesin.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Mesin
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Mesin</a>
    <a class="dropdown-item" href="#">Spare Part Mesin</a>
  </div>
</div>   

<div class="nav-item">
<img src="/aset/img/category/olahraga.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Olah Raga
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Alat Olah Raga</a>
    <a class="dropdown-item" href="#">Fasilitas Olah Raga</a>
  </div>
</div>   
    
<div class="nav-item">
<img src="/aset/img/category/musik.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Alat Musik
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Alat Musik</a>
  </div>
</div>   

<div class="nav-item">
<img src="/aset/img/category/souvenir.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Souvenir
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">souvenir</a>
  </div>
</div>  

<br><br><br><br><br><br>
<br><br><br><br><br><br>
<hr><hr>
 
               </div>
            </div>
         </div>   
      </div>
   </div>
</section>
