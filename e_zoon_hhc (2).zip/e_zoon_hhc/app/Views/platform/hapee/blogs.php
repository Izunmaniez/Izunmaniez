<?= $this-> extend('platform/hapee/template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this->include('platform/hapee/template/navbar');?>


<div class="container">
    <div class="row">
        <div class="col">
        <p>
<h4 class="package-card__title base--color mb-2">Tips</h4>
Buat Aplikasi HHC tanpa download & install. Caranya, ﻿klik tanda titik tiga atau tanda panah di pojok paling kanan atas, lalu scroll kebawah cari bacaan Tambahkan ke layar utama lalu beri nama aplikasi ini HHC.  Beres! selanjut Anda tinggal klik icon tersebut setiap akan masuk ke website HHC tanpa mengetik lagi "https://www.hamdalahku.com"   
 <hr>
 <hr>
 <p>
 
<form action="" method="post">
 <?= csrf_field(); ?> 
 
 <?php foreach ($blogs as $blog) : ?>
 
       
<h4 class="package-card__title base--color mb-2"><?=$blog['judul']; ?></h4>
    
<?=$blog['isi_blog']; ?>
<hr>
<hr>
<hr>

<?php endforeach; ?>   
       </form>       
        </div>
    </div>
</div>
    
<?= $this-> endSection(); ?>


 