<?= $this-> extend('platform/hapee/template/index'); ?>

<?= $this-> section('content'); ?>

<?= $this->include('platform/hapee/template/navbar');?>

<?= $this->include('platform/hapee/template/slider');?>

<?= $this->include('platform/hapee/template/runningText');?>

<?= $this->include('platform/hapee/template/midnav');?>

<?= $this->include('platform/hapee/template/produk');?>


<?= $this-> endSection(); ?>
