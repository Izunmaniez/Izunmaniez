<?= $this-> extend('administrator/template/index'); ?>


<?= $this-> section('content'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <div class="user-block">
               <img class="img-circle img-bordered-sm ml-2 mr-2" src="/aset/img/produkHome/<?= $produk->image; ?>">
             </div>  
             <div class="ml-2">Toko/UMKM
             <h5><b><?= $produk->nama_toko; ?></b></h5>
             </div>         
          </div>         
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card card-solid">
        <div class="card-body">
          <div class="row">
            <div class="col-12 col-sm-6">
              <center><h4 class="d-inline-block"><b><?= $produk->nama_produk; ?></b></h4></center>                          
              <div class="col-12">             
                <img src="/aset/img/produkHome/<?= $produk->image; ?>" class="product-image" style="border-radius:7px;" alt="<?=$produk->nama_produk; ?>">
              </div>              
                
              <hr>           
              <div class="bg-no-bg py-2 px-3 mt-4">
                <h5 class="badge bg-pink float-right mb-1 text-lg">PV : <?= $produk->pv; ?> %</h5>                                                           
                <h5 class="mb-2">Rp. <?=number_format ($produk->harga, 0, ".", "."); ?>,-</h5>
              </div>

              <div class="mt-4">
                <a href="https://api.whatsapp.com/send?phone=+6285275305301" class="btn btn-success btn-lg d-block mb-2">
                  <i class="fas fa-money-bill-wave fa-lg mr-2"></i> 
                   <b>Beli Sekarang</b>
                </a>
                <p>
                <a href="/users" class="btn bg-olive btn-lg d-block">
                  <i class="fas fa-shopping-basket fa-lg mr-2"></i> 
                  Masukkan ke Keranjang
                </a>
                <p>
                <a href="/" class="btn bg-teal btn-lg d-block">
                  <i class="fas fa-cart-plus fa-lg mr-2"></i> 
                  Lanjut Belanja
                </a>
              </div>
            </div><!-- /.end col -->
            
          <div class="col-12 col-sm-6 mt-5">            
<div class="card card-info card-tabs ">
           <div class="card-header p-4 pt-0 pl-10">
             <ul class="nav nav-tabs" id="custom-tabs-one-tab" role="tablist">
               <li class="nav-item">
               <a class="nav-link active" id="custom-tabs-one-home-tab" data-toggle="pill" href="#custom-tabs-one-home" role="tab" aria-controls="custom-tabs-one-home" aria-selected="true"><b>Detail Produk</b>                  
               </a>
               </li>
               <li class="nav-item">
               <a class="nav-link" id="custom-tabs-one-profile-tab" data-toggle="pill" href="#custom-tabs-one-profile" role="tab" aria-controls="custom-tabs-one-profile" aria-selected="false"><b>Deskripsi</b></a>
               </li>                  
             </ul>
           </div>
           <div class="card-body">
             <div class="tab-content" id="custom-tabs-one-tabContent">
               <div class="tab-pane fade show active" id="custom-tabs-one-home" role="tabpanel" aria-labelledby="custom-tabs-one-home-tab">
                  <div class="table-responsive">
                    <table class="table">
                      <tr>
                        <th>Kategori</th>
                        <td> <?= $produk->kategori; ?></td>
                      </tr>
                      <tr>
                        <th style="width:50%">Kondisi</th>
                        <td> <?= $produk->kondisi; ?></td>
                      </tr>
                      <tr>
                      <tr>
                        <th style="width:50%">Berat</th>
                        <td> <?=number_format ($produk->berat, 0, ".", "."); ?> gram                       
                        </td>
                      </tr>
                      <tr>
                        <th>Minimal Order</th>
                        <td> <?= $produk->min_order; ?> <?= $produk->satuan_produk; ?></td>                    
                      </tr>
                    </table>                 
                 </div>                                                           
               </div>
                                               
               <div class="tab-pane fade" id="custom-tabs-one-profile" role="tabpanel" aria-labelledby="custom-tabs-one-profile-tab">
                    <?=$produk->deskripsi; ?>                                                   
                </div>                                       
              </div>
            </div>
          </div>
            <div class="callout callout-warning mt-5">
              <h5><i class="fas fa-info text-warning"></i> Warning!</h5>
              Hati-hati dengan pembayaran atas pembelian produk (online) di Hapee tanpa melalui jalur Resmi (Admin Hapee -HHC). Transaksi tersebut diluar tanggung jawab Kami. <br>TTD.<br><br><b>HHC Management</b>
            </div>    
        </div><!-- /.col -->    
        
         
        
                                                                  
            
            </div><!-- /.row -->
         </div> <!-- /.card-body -->
      </div><!-- /.card-solid -->
   </section>    <!-- /.content -->
</div>  <!-- /.content-wrapper -->

  

 <?= $this-> endSection(); ?>
  
  
  