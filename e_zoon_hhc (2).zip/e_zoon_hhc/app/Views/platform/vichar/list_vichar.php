<?= $this-> extend('administrator/template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this->include('administrator/template/topbar');?>

<?= $this->include('administrator/template/sidebar');?>

<div class="container">
    <div class="row">
        <div class="col">
 <p>   

 <?php if(session()->getFlashdata('pesan')) : ?>

<div class="alert alert-success" role="alert">

<?= session()->getFlashdata('pesan');?>

</div>
  
<?php endif; ?>
<form action="" method="post">
 <?= csrf_field(); ?> 
 
 <?php foreach ($vichar as $vic) : ?>
 
       
<h5>Judul : <?=$vic['judul']; ?></h5>
last uploaded : <?=$vic['tanggal']; ?>
<p>
<tr>
<td>   
<a href="/platform/vichar/editVichar/<?= $vic['id']; ?> " class="btn btn-warning">Edit</a>
</td>

<a href="/administrator" class="btn btn-secondary btn-md float-right mr-1">Back</a>
                  
<td>
<form action="/platform/deleteVichar/<?= $vic['id']; ?>" method="post">
<?= csrf_field(); ?>
<input type="hidden" name="_method" value="delete">

<button type="submit" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus video ini?');">Hapus</button>
</form>
</td>
</tr>        
                    
 <hr>
 <hr>
 <hr>  
 
   <?php endforeach; ?>
       
    </form>
  
   </div>
    </div>
</div> 

<?= $this-> endSection(); ?>