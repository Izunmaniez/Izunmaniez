<?= $this-> extend('administrator/template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this-> include('administrator/template/topbar'); ?>

<?= $this-> include('administrator/template/sidebar'); ?>

<div class="container">
   <div class="row">   
      <div class="col">
      
<p>   

<h3>Edit Video</h3>


<form action="/platform/updateVichar/<?= $vichar['id']; ?>" method="post" enctype="multipart/form-data">

<?= csrf_field(); ?>

<div class="form-grup row">
    <label for="tanggal" class="col-sm-2 col-form-label">Tanggal</label>
    <div class="col-sm-10">
<input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= $vichar['tanggal']; ?>" autofocus>            
</div>
</div>
 <p>
 
  <div class="form-grup row">
    <label for="judul" class="col-sm-2 col-form-label">Judul</label>
    <div class="col-sm-10">
<input type="text" class="form-control" id="judul" name="judul"  value="<?= $vichar['judul']; ?>" >            
</div>
</div>
<p>

  <div class="form-grup row">
    <label for="link_video" class="col-sm-2 col-form-label">Link Video</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="link_video" name="link_video"  value="<?= $vichar['link_video']; ?>"   >
    </div>
  </div>
  
  <p>
  <p>

<a href="/platform/vichar/list_vichar" class="btn btn-secondary btn-md float-right mr-1">Back</a>
                  
  <button type="submit" class="btn btn-warning">Simpan</button>
 
</form>

</p>

</div>
</div>
</div>

<?= $this-> endSection(); ?>
