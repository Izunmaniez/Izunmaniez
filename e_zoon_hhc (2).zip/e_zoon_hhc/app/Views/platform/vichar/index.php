<?= $this-> extend('platform/template/index'); ?>

<?= $this-> section('content'); ?>

<?= $this->include('platform/template/navbar');?>

<?= $this->include('platform/template/headerVichar');?>

<div class="container mt-7">     
   
  <form action="" method="post">
 <?= csrf_field(); ?> 
 
 <?php foreach ($vichar as $vic) : ?>		
		
			<div class="col-sm-12 col-lg-4 text-center align-self-lg-center mt-3 elevation-9">
				<h4><?=$vic['judul']; ?></h4>
			</div>
			<div class="col-sm-12 col-lg-8 mt-3">
				<div class="embed-responsive embed-responsive-16by9">
					<iframe width="560" height="315" src="<?=$vic['link_video']; ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
				</div>
			</div>
		
		<hr>		
		<hr>
    
<?php endforeach; ?>   
       </form>             	

</div>


<?= $this-> endSection(); ?>

            
            
         

            

