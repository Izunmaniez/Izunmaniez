<br>
<div class="col-sm-12 col-lg-4 text-center align-self-lg-center mt-3">
	<h4>Al-Wahidah Islamic Center <b></h4>
</div>
<div class="col-sm-12 col-lg-8 mt-3">
<div class="embed-responsive embed-responsive-16by9">
<iframe width="560" height="315" src="https://www.youtube.com/embed/4OOcTax2Yqw" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
</div>
</div>	
	
<br>
<div class="col-sm-12 col-lg-4 text-center align-self-lg-center mt-3">
	<h4>Konsep duplikasi ngiklan 3 sachet Rp. 100.000 mengahasilkan omset Milyaran/bulan  <b></h4>
</div>
<div class="col-sm-12 col-lg-8 mt-3">
<div class="embed-responsive embed-responsive-16by9">
<iframe width="560" height="315" src="https://www.youtube.com/embed/milXAQ4n1eo" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
</div>
</div>	

<br>
<div class="col-sm-12 col-lg-4 text-center align-self-lg-center mt-3">
	<h4>Teknis ngiklan 3 sachet Rp. 100.000 Bukan sekedar jualan Kopi & Susu<b></h4>
</div>
<div class="col-sm-12 col-lg-8 mt-3">
<div class="embed-responsive embed-responsive-16by9">
<iframe width="560" height="315" src="https://www.youtube.com/embed/_oBVUnciBz0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
</div>
</div>	

<br>
<div class="col-sm-12 col-lg-4 text-center align-self-lg-center mt-3">
	<h4>Klaim Reward N-Max Pertama hanya dalam waktu 3 bulan pertama<b></h4>
</div>
<div class="col-sm-12 col-lg-8 mt-3">
<div class="embed-responsive embed-responsive-16by9">
<iframe width="560" height="315" src="https://www.youtube.com/embed/dBjH224cZHo" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
</div>
</div>	

<br>
<div class="col-sm-12 col-lg-4 text-center align-self-lg-center mt-3">
	<h4>Klaim Reward N-Max Kedua hanya dalam waktu 1.5 bulan sejak klaim N-Max pertama<b></h4>
</div>
<div class="col-sm-12 col-lg-8 mt-3">
<div class="embed-responsive embed-responsive-16by9">
<iframe width="560" height="315" src="https://www.youtube.com/embed/lWXP_FvJIKs" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
</div>
</div>

<br><br>
			
			
		
	
	