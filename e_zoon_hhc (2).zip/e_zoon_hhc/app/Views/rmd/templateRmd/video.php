<br>
	<div class="col-sm-12 col-lg-4 text-center align-self-lg-center mt-3">
				<h4>Kopi RMD berfungsi diawal <b>Mendeteksi</b> penyakit</h4>
			</div>
			<div class="col-sm-12 col-lg-8 mt-3">
				<div class="embed-responsive embed-responsive-16by9">
					<iframe width="560" height="315" src="https://www.youtube.com/embed/GzcU92HWmU4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
				</div>
			</div>		
<br>
	<div class="col-sm-12 col-lg-4 text-center align-self-lg-center mt-3">
				<h4>Kopi RMD menyembuhkan penyakit <b>Komplikasi</b> dan <b>Kelenjar Getah Bening</b> </h4>
			</div>
			<div class="col-sm-12 col-lg-8 mt-3">
				<div class="embed-responsive embed-responsive-16by9">
					<iframe width="560" height="315" src="https://www.youtube.com/embed/PA2kHQwCJKI" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
				</div>
			</div>	
			
<br>
	<div class="col-sm-12 col-lg-4 text-center align-self-lg-center mt-3">
				<h4>Kopi RMD menyembuhkan penyakit <b>Stroke Ringan</b> </h4>
			</div>
			<div class="col-sm-12 col-lg-8 mt-3">
				<div class="embed-responsive embed-responsive-16by9">
					<iframe width="560" height="315" src="https://www.youtube.com/embed/jPOpMX_pKUM" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
				</div>
			</div>		
			
<br>
	<div class="col-sm-12 col-lg-4 text-center align-self-lg-center mt-3">
				<h4>Kopi RMD rasanya <b>Sangat Lezat</b> bikin nagih..😍😁💓</h4>
			</div>
			<div class="col-sm-12 col-lg-8 mt-3">
				<div class="embed-responsive embed-responsive-16by9">
					<iframe width="560" height="315" src="https://www.youtube.com/embed/aSS8t-b-UVo" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
				</div>
			</div>			
			
			
			
			
					