<!-- start music-box --> 
<div class="music-box"> 
    <button class="music-box-toggle-btn"> 
        <!-- 
        <i class="fa fa-music"></i> --> 
        <audio id='song' loop> 
          <source src="http://docs.google.com/uc?export=open&id=1sKGLoP0tole6RAqcWhGfRC78oP9HwP8P"> 
        </audio>   
        <button type="button" class="music" id="mute-sound" > 
          <i class="fa fa-music"></i> 
        </button> 
        <button type="button" class="music" id="unmute-sound" > 
          <i class="fa fa-microphone-slash"></i> 
        </button>  
    </button> 
</div> 
<!-- end music box -->
</div></div>
<script> 
 document.getElementById('mute-sound').style.display = 'none'; 
  document.getElementById('unmute-sound').addEventListener('click', function(event){ 
    document.getElementById('unmute-sound').style.display = 'none'; 
    document.getElementById('mute-sound').style.display = 'inline-block'; 
    document.getElementById('song').play(); 
  }); 
  document.getElementById('mute-sound').addEventListener('click', function(event){ 
    document.getElementById('mute-sound').style.display = 'none'; 
    document.getElementById('unmute-sound').style.display = 'inline-block'; 
    document.getElementById('song').pause(); 
  }); 
</script></p></div></p>
</div></div>