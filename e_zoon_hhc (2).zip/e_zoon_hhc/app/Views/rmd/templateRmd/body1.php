<img src="/aset/img/rmd/rmd1.jpg" alt="kopi rmd" width="100%">
<br>
<img src="/aset/img/rmd/papa.jpg" alt="papa minum mama senyum - rmd" width="100%">
<br>


<div class="content-wrapper">
<section class="content-header" style="color:black">    
<div class="card card-primary card-outline">
<div class="card card-header">
         
        <center><h1><b> Manfaat Kopi RMD</b></h1>  
        <small style="color:darkblue;"><i>(Komposisi Utama : Cordycep Mycellium, Ginseng Merah, Tribulus, Macca, Epidemium)</i></small>
        <br>    <br>   
               <li>  Menyembuhkan berbagai macam penyakit yang berhubungan dengan sebab penyumbatan pembuluh darah
               seperti : Stroke, Saraf Terjepit, Kolesterol Tinggi, Darah Tinggi, Jantung Koroner, Diabetes Type II, Asam Urat, dsb..  </li>
                 <li>  Sebagai Anti Oksidan dan Detoksifikasi (Membung racun dalam tubuh).  </li>
                 <li>  Membunuh sel kanker. </li>
                 <li>  Menguatkan fungsi Jantung, Hati, Paru-paru, Pankreas, Limpa dan Ginjal.</li>
                 <li>  Meningkatkan Vitalitas pria & wanita.</li>               
               <br>
             <small style="color:darkblue;"><i>Legalitas Kopi RMD : P-IRT: 5133204013175</i></small>
           </center>
                                                                   
        </div>
      </div><!-- /.container-fluid -->
    </section>
 </div>
    
<div class="content-wrapper">
<section class="content-header" style="color:black">     
<div class="card card-primary card-outline">
<div class="card card-header">
         
        <center><h1><b> Manfaat Susu RMD</b></h1>  
        <small style="color:darkblue;"><i>(Komposisi Utama : Susu Kambing Etawa, Jahe Merah dan Madu)</i></small>
        <br>    <br>   
                 <li>  Mencegah dan memperbaiki keropos tulang (osteoporosis).  </li>
                 <li>  Menormalkan teknanan darah tinggi dan tekanan darah rendah.  </li>
                 <li>  Membantu menyembuhkan penyakit gula darah (diabetes). </li>
                 <li>  Membantu mengatasi penyakit pernafasan.</li>               
                 <li>  Membantu mengatasi penyakit pencernaan dan asam lambung.</li>
                 <li>  Menguatkan imunitas tubuh.</li>
                 <li>  Meregenerasi sel organ, sel otak & sel kulit.</li>
                 <li>  Sebagai nutrisi yang sangat baik bagi ibu hamil & menyusui.</li>
                 <li>  Sebagai nutrisi yang sangat baik dan mempercepat pertumbuhan bagi anak-anak.</li>
                 <li>  Sumber serat pangan yang dibutuhkan tubuh.</li>
                 <li>  Sumber vitamin A, B6, B12, C, D, Kalsium, Zat Besi & Zinc.</li>                            
               <br>
             <small style="color:darkblue;"><i>Legalitas Susu RMD : LPOM MUI 12040002540519</i></small>
           </center>
                                                       
        </div>
      </div><!-- /.container-fluid -->
    </section>
 </div>
    
<img src="/aset/img/rmd/rmd2.jpg" alt="kopi rmd" width="100%">

<img src="/aset/img/rmd/down3.gif" alt="kopi rmd" width="100%">

<img src="/aset/img/rmd/rmd3.jpg" alt="kopi rmd" width="100%">

<img src="/aset/img/rmd/testimoni.jpg" alt="kopi rmd" width="100%">

<img src="/aset/img/rmd/down3.gif" alt="kopi rmd" width="100%">

