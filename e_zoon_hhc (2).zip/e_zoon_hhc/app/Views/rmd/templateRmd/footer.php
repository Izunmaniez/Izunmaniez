  <footer class="content-wrapper">
    
    <strong>				
    <a href="#top" style="padding-top:7px;">Kembali keatas</a>
    </strong>   
  
  </footer>
  

  
  
  
  