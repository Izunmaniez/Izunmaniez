<?= $this-> extend('templateRmd/header'); ?>


<?= $this-> section('content'); ?>

<?= $this->include('templateRmd/music');?>

<?= $this->include('templateRmd/runningText');?>

<?= $this->include('templateRmd/body1');?>

<?= $this->include('templateRmd/video');?>



<div class="container my-5">
<a href="https://api.whatsapp.com/send?phone=+62 82273007888&text=Hallo..Franchiser RMD...%20Saya %20berminat%20membeli%20produk%20RMD%20☕🍵😍">
<img src="/aset/img/rmd/pesansekarang.gif" alt="kopi rmd" width="100%"></a>
</div>



<?= $this->include('templateRmd/body2');?>

<?= $this->include('templateRmd/video2');?>

<?= $this->include('templateRmd/slider');?>

<?= $this->include('templateRmd/body3');?>



<div class="content-wrapper">
<div class="container py-5">
<a href="https://api.whatsapp.com/send?phone=+62 82273007888&text=Hallo..Franchiser RMD...%20Saya %20berminat%20menjadi%20Franchiser%20RMD%20☕🍵😍">
<img src="/aset/img/rmd/daftar.gif" alt="kopi rmd" width="90%"></a>
<div>
<div>




 <?= $this-> endSection(); ?>
 