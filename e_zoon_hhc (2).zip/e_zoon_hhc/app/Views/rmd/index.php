<?= $this-> extend('rmd/templateRmd/header'); ?>


<?= $this-> section('content'); ?>

<?= $this->include('rmd/templateRmd/music');?>

<?= $this->include('rmd/templateRmd/runningText');?>

<?= $this->include('rmd/templateRmd/body1');?>

<?= $this->include('rmd/templateRmd/video');?>



<div class="container my-5">
<a href="https://api.whatsapp.com/send?phone=62 85275305301&text=Hallo..Franchiser RMD...%20Saya %20berminat%20membeli%20produk%20RMD%20😊☕">
<img src="/aset/img/rmd/pesansekarang.gif" alt="kopi rmd" width="100%"></a>
</div>



<?= $this->include('rmd/templateRmd/body2');?>

<?= $this->include('rmd/templateRmd/video2');?>

<?= $this->include('rmd/templateRmd/slider');?>

<?= $this->include('rmd/templateRmd/body3');?>



<div class="content-wrapper">
<div class="container py-5">
<a href="https://api.whatsapp.com/send?phone=62 85275305301&text=Hallo..Franchiser RMD...%20Saya %20berminat%20menjadi%20Franchiser%20RMD%20😊☕">
<img src="/aset/img/rmd/daftar.gif" alt="kopi rmd" width="90%"></a>
<div>
<div>




 <?= $this-> endSection(); ?>
 