<?php

namespace App\Models;

use CodeIgniter\Model;

class BlogsModel extends Model
{
    protected $table         = 'blogs';
    protected $allowedFields = ['judul', 'blogger', 'isi_blog'];
    protected $useTimestamps = true;
    
}