<?php namespace App\Models;

use CodeIgniter\Model;

class TokoModel extends Model
{

protected $table ='toko';

protected $useTimestamps = true;

protected $allowedFields = ['id_toko', 'nama_toko', 'logoToko', 'created_at'];



}