<?php namespace App\Models;

use CodeIgniter\Model;

class DjosdokModel extends Model
{

protected $table ='djosdok';

protected $useTimestamps = true;

protected $allowedFields = ['judul', 'kategori', 'foto', 'video', 'ket'];

}
