<?php namespace App\Models;

use CodeIgniter\Model;

class ProdukModel extends Model {
	protected $table = 'produk';
	protected $allowedFields = ['image', 'nama_produk', 'kategori', 'berat', 'harga', 'pv', 'satuan_produk', 'deskripsi', 'nama_toko', 'kondisi', 'min_order', 'sistem_bayar', 'brand', 'nama_produsen', 'alamat_produsen'];
        protected $useTimestamps = true;

	
}