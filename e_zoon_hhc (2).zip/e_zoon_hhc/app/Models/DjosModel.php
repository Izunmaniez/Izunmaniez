<?php namespace App\Models;

use CodeIgniter\Model;

class DjosModel extends Model
{

protected $table ='djos';

protected $useTimestamps = true;

protected $allowedFields = ['tanggal', 'masuk', 'donatur', 'keluar', 'volunteer', 'keterangan'];



public function search($keyword) {

return $this->table('djos')->like('donatur', $keyword);
}

}

