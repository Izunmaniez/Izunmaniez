<?php namespace App\Controllers;

use App\Models\DjosModel;
use App\Models\DjosdokModel;

class AdminEmpathy extends BaseController
{

protected $djosModel;
protected $djosdokModel;

public function __construct()
{
$this->djosModel = new DjosModel();
$this->djosdokModel = new DjosdokModel();
}

    
public function listGalery()
{

$djosdok = $this->djosdokModel->orderBy('id desc')->paginate(30, 'djosdok');
	    
$data = [
    'title'=>'List Galery',
    'djosdok'=>$djosdok
    ];	   
     return view('administrator/adminEmpathy/listGalery',$data);}
    
    
public function tambahGalery()
{

session();
	    
$data = [
    'title'=>'Form Tambah Galery',
    'validation'=> \Config\Services::validation()
    ];	   
     return view('administrator/adminEmpathy/tambahGalery',$data);}


public function saveGalery()

{

if (!$this->validate ([

'foto'=>['rules'=>'max_size[foto,1024]|is_image[foto]|mime_in[foto,image/jpg,image/jpeg,image/png]',

  'errors'=> [
  'max_size'=>'Gambar terlalu besar (maks:1 MB)',
  'is_image'=>'Yang Anda pilih bukan gambar',
  'mime_in'=>'Yang Anda pilih bukan gambar'
   
  ]]]))  {
  
// $validation= \Config\Services :: validation();

//   return redirect()->to ('/djosdok/tambah_djosdok')->withInput()->with('validation', $validation);
   
   return redirect()->to ('/adminEmpathy/tambahGalery')->withInput();
   
   }


// ambil gambar
$fileFoto = $this->request->getFile ('foto');

if ($fileFoto->getError() == 4)
{ $namaFoto ='default.png'; }

else {

//ambil nama file random
$namaFoto = $fileFoto->getRandomName();

// pindahkan gambar ke folder gbr-cashflow
$fileFoto->move('aset/img/dokumenDjos', $namaFoto);
}


 $this->djosdokModel->save([
  
  'judul'=>$this->request->getVar('judul'),
  'kategori'=>$this->request->getVar('kategori'),
  'ket'=>$this->request->getVar('ket'),
  'foto'=>$namaFoto
  
  ]);
  
  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Dokumentasi Berhasil Ditambahkan.');
  
  return redirect()->to('/adminEmpathy/listGalery');
  
}


public function deleteGalery($id)

{

// cari foto
$djosdok = $this->djosdokModel->find($id);

// periksa jika foto bukan default
if ($djosdok ['foto'] != 'default.png') {

unlink('aset/img/dokumenDjos/' .$djosdok['foto']);
}

$this->djosdokModel->delete($id);

session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Dokumentasi Berhasil Dihapus.');
  

return redirect()->to('/adminEmpathy/listGalery');

}


public function editGalery($id)
{
 
 session();
    	   	    
$djosdok = $this->djosdokModel->find($id);
      	    
$data = [
    'title'=>'Edit Galery Empathy',
    'djosdok'=>$djosdok,
    'validation'=> \Config\Services::validation()
    ];	 
  
  return view('administrator/adminEmpathy/editGalery',$data);}
          

public function updateGalery($id)
{

if (!$this->validate ([

'foto'=>['rules'=>'max_size[foto,1024]|is_image[foto]|mime_in[foto,image/jpg,image/jpeg,image/png]',

  'errors'=> [
  'max_size'=>'Gambar terlalu besar (maks:1 MB)',
  'is_image'=>'Yang Anda pilih bukan gambar',
  'mime_in'=>'Yang Anda pilih bukan gambar'
   
  ]]]))  {
  
// $validation= \Config\Services :: validation();

//   return redirect()->to ('/djosdok/tambah_djosdok')->withInput()->with('validation', $validation);
   
   return redirect()->to ('/adminEmpathy/editGalery')->withInput();
   
   }

// ambil gambar
$fileFoto = $this->request->getFile ('foto');

if ($fileFoto->getError() == 4)
{ $namaFoto = $this->request->getVar('fotoLama'); }

else {

//ambil nama file random
$namaFoto = $fileFoto->getRandomName();

// pindahkan gambar ke folder gbr-cashflow
$fileFoto->move('aset/img/dokumenDjos', $namaFoto);

// hapus file lama
unlink('aset/img/dokumenDjos/' .$this->request->getVar('fotoLama'));

}


$this->djosdokModel->save([
  'id'=>$id,
  'judul'=>$this->request->getVar('judul'),
  'kategori'=>$this->request->getVar('kategori'),
  'ket'=>$this->request->getVar('ket'),
  'foto'=>$namaFoto
  ]);

  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Dokumentasi Berhasil Diedit.');
  
  return redirect()->to('/adminEmpathy/listGalery');
}


public function listCashflow()
{   
  	    
$djos = $this->djosModel->orderBy('id desc')->findAll();

$data = [
    'title'=>'Cashflow Empathy',
    'djos'=>$djos
    
    ];	 
          
    return view('administrator/adminEmpathy/listCashflow',$data);
}


public function tambahCashflow()
{

$djos = $this->djosModel->orderBy('id desc')->paginate(30, 'platform/empathy/cashflowEmpathy');	
	    
$data = [
    'title'=>'Form Tambah Data Cash Flow Empathy'];	   
     return view('administrator/adminEmpathy/tambahCashflow',$data);}


public function saveCashflow()
{

//if (!$this->validate ([

//'dokumentasi' => [
// 'rules'=>'max_size[dokumentasi,1024]|is_image[dokumentasi]|mime_in[dokumentasi,image/jpg,image/jpeg,image/png]',

//  'errors'=> [
//  'max_size'=>'Gambar terlalu besar (maks:1 MB)',
//  'is_image'=>'Yang Anda pilih bukan gambar',
//  'mime_in'=>'Yang Anda pilih bukan gambar'
   
//  ]]]))   {
//$validation= \Config\Services :: validation();

// return redirect()->to ('djos/tambah_cashflow')->withInput();}


// ambil gambar
// $fileDokumentasi = $this->request->getFile ('dokumentasi');

// pindahkan gambar ke folder gbr-cashflow
// $fileDokumentasi->move('gbr_cashflow');

//ambil nama
// $namaDokumentasi = $fileDokumentasi->getName();


 $this->djosModel->save([
  
  'tanggal'=>$this->request->getVar('tanggal'),
  'masuk'=>$this->request->getVar('masuk'),
  'donatur'=>$this->request->getVar('donatur'),
  'keluar'=>$this->request->getVar('keluar'),
  'volunteer'=>$this->request->getVar('volunteer'),
  'keterangan'=>$this->request->getVar('keterangan')
//  'dokumentasi'=>$namaDokumentasi

  ]);
  
  session()->setFlashdata('pesan', 'Aye..!😆😀😎 Cashflow Berhasil Ditambahkan.');
  
  return redirect()->to('/adminEmpathy/listCashflow'); 
}


public function deleteCashflow($id)

{
$this->djosModel->delete($id);

session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Cashflow Berhasil Dihapus.');
  
return redirect()->to('/adminEmpathy/listCashflow');
}


public function editCashflow($id)
{
    	   	    
$djos = $this->djosModel->find($id);
      	    
$data = [
    'title'=>'Edit Data Cashflow Empathy',
    'djos'=>$djos
    ];	 
  
  return view('administrator/adminEmpathy/editCashflow',$data);
}
          

public function updateCashflow($id)
{

$this->djosModel->save([  
  'id'=>$id,
  'tanggal'=>$this->request->getVar('tanggal'), 
  'masuk'=>$this->request->getVar('masuk'),
  'donatur'=>$this->request->getVar('donatur'),
  'keluar'=>$this->request->getVar('keluar'),
  'volunteer'=>$this->request->getVar('volunteer'),
  'keterangan'=>$this->request->getVar('keterangan')
// 'dokumentasi'=>$this->request->getVar('dokumentasi')

  ]);

  session()->setFlashdata('pesan', 'Aye..!😆😀😎 Cashflow Berhasil Diedit.');
  
  return redirect()->to('/adminEmpathy/listCashflow');
}







}
   