<?php namespace App\Controllers;

use App\Models\UsersModel;
use App\Models\ProdukModel;

class Users extends BaseController
{

protected $usersModel;
protected $produkModel;

public function __construct()

{
$this->usersModel = new UsersModel();
$this->produkModel = new ProdukModel();
}


public function index()
{
     	    
$data = [
    'title'=>'My Dashboard'    
    ];	 
          
    return view('users/index',$data);}
    
 
 public function tambah_user()
{
    	   	    
session();
    	   	    
$users = $this->usersModel->find($id);
      	    
$data = [
    'title'=>'Tambah User',
    'users'=>$users,
    'validation'=> \Config\Services::validation()
    ];	 
   	
    return view('users/tambah_user',$data);
}


public function save()
   
{

if (!$this->validate ([

'foto'=>['rules'=>'max_size[foto,1024]|is_image[foto]|mime_in[foto,image/jpg,image/jpeg,image/png]',

  'errors'=> [
  'max_size'=>'Gambar terlalu besar (maks:1 MB)',
  'is_image'=>'Yang Anda pilih bukan gambar',
  'mime_in'=>'Yang Anda pilih bukan gambar'
   
  ]]]))  {
  
return redirect()->to ('/users')->withInput();
}


// ambil gambar
$fileFoto = $this->request->getFile ('foto');

if ($fileFoto->getError() == 4)
{ $namaFoto ='default_profile.png'; }

else {

//ambil nama file random
$namaFoto = $fileFoto->getRandomName();

// pindahkan gambar ke folder gbr-cashflow
$fileFoto->move('foto_profile', $namaFoto);

}


$this->usersModel->save([
  'id'=>$id,  
  'telp'=>$this->request->getVar('telp'),  
  'fullname'=>$this->request->getVar('fullname'),
  'email'=>$this->request->getVar('email'),
  'foto'=>$namaFoto
  
  ]);

  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Profil Anda Berhasil Diubah.');
  
  return redirect()->to('/users');
  
}
   
    
public function delete($id)

{

// cari foto
$users = $this->usersModel->find($id);

// periksa jika foto bukan default
if ($users ['foto'] != 'default_profile.png') {

unlink('foto_profile/' .$users['foto']);
}

$this->usersModel->delete($id);

session()->setFlashdata('pesan', 'Aye..!😆😀😎 Berhasil Dihapus.');
  
return redirect()->to('/users');

} 

    
public function edit($id)
{
    	   	    
session();
    	   	    
$users = $this->usersModel->find($id);
      	    
$data = [
    'title'=>'Edit My Profile',
    'users'=>$users,
    'validation'=> \Config\Services::validation()
    ];	 
   	
    return view('users/edit',$data);
}


public function update($id)
   
{

if (!$this->validate ([

'foto'=>['rules'=>'max_size[foto,1024]|is_image[foto]|mime_in[foto,image/jpg,image/jpeg,image/png]',

  'errors'=> [
  'max_size'=>'Gambar terlalu besar (maks:1 MB)',
  'is_image'=>'Yang Anda pilih bukan gambar',
  'mime_in'=>'Yang Anda pilih bukan gambar'
   
  ]]]))  {
  
return redirect()->to ('/users/edit')->withInput();
}


// ambil gambar
$fileFoto = $this->request->getFile ('foto');

if ($fileFoto->getError() == 4)
{ $namaFoto = $this->request->getVar('fotoLama'); }

else {

//ambil nama file random
$namaFoto = $fileFoto->getRandomName();

// pindahkan gambar ke folder foto_profile
$fileFoto->move('foto_profile', $namaFoto);

// hapus file lama
//unlink('foto_profile/' .$this->request->getVar('fotoLama'));

}


$this->usersModel->save([
  'id'=>$id,  
  'telp'=>$this->request->getVar('telp'),  
  'fullname'=>$this->request->getVar('fullname'),
  'email'=>$this->request->getVar('email'),
  'foto'=>$namaFoto
  
  ]);

  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Profil Anda Berhasil Diubah.');
  
  return redirect()->to('/users');
  
}
   
 
public function grup()
{      	    
$data = [
    'title'=>'My Groups'   
    ];	 
          
    return view('users/template/grup',$data);}
    
public function bonusHistory()
{      	    
$data = [
    'title'=>'My Groups'   
    ];	 
          
    return view('users/template/bonusHistory',$data);}
    
public function pin()
{      	    
$data = [
    'title'=>'My PIN'   
    ];	 
          
    return view('users/template/pin',$data);}
    
public function sedekah()
{      	    
$data = [
    'title'=>'My PIN'   
    ];	 
          
    return view('users/template/sedekah',$data);}
    


public function myProduk()
{	    
$data ['title'] = 'Detail Produk';


    return view('users/myToko/myProduk',$data);
}



public function tambahProduk()
{

session();

$users = $this->usersModel->find($id);
	    
$data = [
    'title'=>'Form Tambah Produk',
    'validation'=> \Config\Services::validation()
    ];	   
     return view('users/myToko/tambahProduk',$data);}


public function saveProduk()

{

if (!$this->validate ([

'image'=>['rules'=>'max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/png]',

  'errors'=> [
  'max_size'=>'Gambar terlalu besar (maks:1 MB)',
  'is_image'=>'Yang Anda pilih bukan gambar',
  'mime_in'=>'Yang Anda pilih bukan gambar'
   
  ]]]))  {
  
return redirect()->to ('/users/tambahProduk')->withInput();
   
   }



// ambil gambar
$fileImage = $this->request->getFile ('image');


//ambil nama file
$namaImage = $fileImage->getName();

// pindahkan gambar ke folder gbr-cashflow
$fileImage->move('aset/img/produkHome', $namaImage);



 $this->produkModel->save([ 
 
  'nama_produk'=>$this->request->getVar('nama_produk'),
  'kategori'=>$this->request->getVar('kategori'),
  'brand'=>$this->request->getVar('brand'),
  'produsen'=>$this->request->getVar('produsen'),
  'berat'=>$this->request->getVar('berat'),
  'harga'=>$this->request->getVar('harga'),
  'satuan_produk'=>$this->request->getVar('satuan_produk'),
  'pv'=>$this->request->getVar('pv'),
  'deskripsi'=>$this->request->getVar('deskripsi'),
  'nama_toko'=>$this->request->getVar('nama_toko'),
  'kondisi'=>$this->request->getVar('kondisi'),
  'min_order'=>$this->request->getVar('min_order'),
  'sistem_bayar'=>$this->request->getVar('sistem_bayar'),
  'brand'=>$this->request->getVar('brand'),
  'nama_produsen'=>$this->request->getVar('nama_produsen'),
  'alamat_produsen'=>$this->request->getVar('alamat_produsen'),
  'image'=>$namaImage
  ]);
  
  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Produk Berhasil Ditambahkan.');
  
  return redirect()->to('/users/myProduk');
  
}


public function deleteProduk($id)

{

// cari gbr
$produk = $this->produkModel->find($id);

// periksa jika foto bukan default
if ($produk ['image'] != 'default.png') {

unlink('aset/img/produkHome/' .$produk['image']);
}

$this->produkModel->delete($id);

session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Produk Berhasil Dihapus.');
  

return redirect()->to('/users/myProduk');

}


public function editProduk($id)
{
 
 session();
    	   	    
$produk = $this->produkModel->find($id);
      	    
$data = [
    'title'=>'Edit Produk',
    'produk'=>$produk,
    'validation'=> \Config\Services::validation()
    ];	 
  
  return view('users/mytoko/editProduk',$data);}
          

public function updateProduk($id)
{

if (!$this->validate ([

'image'=>['rules'=>'max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/png]',

  'errors'=> [
  'max_size'=>'Gambar terlalu besar (maks:1 MB)',
  'is_image'=>'Yang Anda pilih bukan gambar',
  'mime_in'=>'Yang Anda pilih bukan gambar'
   
  ]]]))  {
  
// $validation= \Config\Services :: validation();

//   return redirect()->to ('/djosdok/tambah_djosdok')->withInput()->with('validation', $validation);
   
   return redirect()->to ('/users/editProduk')->withInput();
   
   }

// ambil gambar
$fileImage = $this->request->getFile ('image');

if ($fileImage->getError() == 4)
{ $namaImage = $this->request->getVar('imageLama'); }

else {

//ambil nama file random
$namaImage = $fileImage->getName();

// pindahkan gambar ke folder gbr-cashflow
$fileImage->move('aset/img/produkHome', $namaImage);

// hapus file lama
unlink('aset/img/produkHome/' .$this->request->getVar('imageLama'));

}

 $this->produkModel->save([ 
  'id'=>$id,
  'nama_produk'=>$this->request->getVar('nama_produk'),
  'kategori'=>$this->request->getVar('kategori'),
  'brand'=>$this->request->getVar('brand'),
  'produsen'=>$this->request->getVar('produsen'),
  'berat'=>$this->request->getVar('berat'),
  'harga'=>$this->request->getVar('harga'),
  'pv'=>$this->request->getVar('pv'),
  'satuan_produk'=>$this->request->getVar('satuan_produk'),
  'deskripsi'=>$this->request->getVar('deskripsi'),
  'nama_toko'=>$this->request->getVar('nama_toko'),
  'kondisi'=>$this->request->getVar('kondisi'),
  'min_order'=>$this->request->getVar('min_order'),
  'sistem_bayar'=>$this->request->getVar('sistem_bayar'),
  'brand'=>$this->request->getVar('brand'),
  'nama_produsen'=>$this->request->getVar('nama_produsen'),
  'alamat_produsen'=>$this->request->getVar('alamat_produsen'),
  'image'=>$namaImage
  ]);

  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Produk Berhasil Diedit.');
  
  return redirect()->to('/users/myProduk');
  
}
  


  
    
}
	    


