<?php namespace App\Controllers;

class Rmd extends BaseController
{

public function index()
{	    
$data = [
    'title'=>'RMD'];	   
		return view('rmd/index',$data);}

public function izun()
{	    
$data = [
    'title'=>'RMD'];	   
		return view('rmd/izun',$data);}

public function iwanKaya()
{	    
$data = [
    'title'=>'RMD'];	   
		return view('rmd/iwanKaya',$data);}
			
public function parlinKaya()
{	    
$data = [
    'title'=>'RMD'];	   
		return view('rmd/parlinKaya',$data);}
							
public function sukidiKaya()
{	    
$data = [
    'title'=>'RMD'];	   
		return view('rmd/sukidiKaya',$data);}
			
public function hendriKaya()
{	    
$data = [
    'title'=>'RMD'];	   
		return view('rmd/hendriKaya',$data);}

public function mTaslan()
{	    
$data = [
    'title'=>'RMD'];	   
		return view('rmd/mTaslan',$data);}

public function dwieZoel()
{	    
$data = [
    'title'=>'RMD'];	   
		return view('rmd/dwieZoel',$data);}

public function kuswito()
{	    
$data = [
    'title'=>'RMD'];	   
		return view('rmd/kuswito',$data);}

public function hendro()
{	    
$data = [
    'title'=>'RMD'];	   
		return view('rmd/hendro',$data);}

public function eviPanjang()
{	    
$data = [
    'title'=>'RMD'];	   
		return view('rmd/eviPanjang',$data);}


						
					
}		