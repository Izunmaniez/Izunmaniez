<?php namespace App\Controllers;

use App\Models\ProdukModel;
use App\Models\VicharModel;
use App\Models\DjosModel;
use App\Models\DjosdokModel;

class Platform extends BaseController

{

protected $produkModel;
protected $vicharModel;
protected $djosModel;
protected $djosdokModel;

public function __construct()
{
$this->produkModel = new ProdukModel();
$this->vicharModel = new VicharModel();
$this->djosModel = new DjosModel();
$this->djosdokModel = new DjosdokModel();
}



public function index()
{	    
$data = [
    'title'=>'PT. HHC INDONESIA'];	   
		return view('platform/index',$data);
}


public function swizh()
{	    
$data = [
    'title'=>'Swizh HHC'];	   
    
    return view('platform/swizh/index',$data);
}


public function charger()
{	    
$data = [
    'title'=>'Charger - Character Generating HHC'];	   
    
    return view('platform/charger/index',$data);
}


public function vichar()
{

$vichar = $this->vicharModel->orderBy('id desc')->paginate(30, 'platform/vichar');

$data = [
    'title'=>'Vichar - Video Charity HHC',
    'vichar'=>$vichar
    ];	 
          
    return view('platform/vichar/index',$data);
}


public function empathy()
{	    
$data = [
    'title'=>'Empathy HHC'];	   
     
     return view('platform/empathy/index',$data);
}


public function publishEmpathy()
{
$djos = $this->djosModel->orderBy('id desc')->paginate(30, 'platform/empathy/publishEmpathy');

$currentPage = $this->request->getVar('page_platform/empathy/publishEmpathy') ? $this->request->getVar('page_platform/empathy/publishEmpathy') : 1;
    	    
$data = [
    'title'=>'Publikasi Cashflow Empathy',
    'djos'=>$djos,
    'pager'=>$this->djosModel->pager,
    'currentPage'=>$currentPage   
    ];	 
          
    return view('platform/empathy/publishEmpathy',$data);}
    

public function galeryEmpathy()
{

$djosdok = $this->djosdokModel->orderBy('id desc')->paginate(30, 'platform/empathy/galeryEmpathy');

$currentPage = $this->request->getVar('page_platform/empathy/galeryEmpathy') ? $this->request->getVar('page_platform/empathy/galeryEmpathy') : 1;
    	    
$data = [
    'title'=>'Galery Empathy HHC',
    'djosdok'=>$djosdok,
    'pager'=>$this->djosdokModel->pager,
    'currentPage'=>$currentPage       
    ];	 
          
    return view('platform/empathy/galeryEmpathy',$data);}


}





