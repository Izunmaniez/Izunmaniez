<?php namespace App\Controllers;

use App\Models\TokoModel;

class Toko extends BaseController
{

protected $tokoModel;

public function __construct()

{
$this->tokoModel = new TokoModel();
}


public function index()
{
     	    
session();
    	   	    
$toko = $this->tokoModel->findAll;
      	    
$data = [
    'title'=>'My Toko',
    'toko'=>$toko
     ];	 
   	
    return view('toko/index',$data);
}

    
 
 public function tambah()
{
    	   	    
session();
    	   	    
$toko = $this->tokoModel->find($id);
      	    
$data = [
    'title'=>'Tambah Toko',
    'toko'=>$toko,
    'validation'=> \Config\Services::validation()
    ];	 
   	
    return view('toko/tambah',$data);
}


public function save()
   
{

if (!$this->validate ([

'logoToko'=>['rules'=>'max_size[logoToko,1024]|is_image[logoToko]|mime_in[logoToko,image/jpg,image/jpeg,image/png]',

  'errors'=> [
  'max_size'=>'Gambar terlalu besar (maks:1 MB)',
  'is_image'=>'Yang Anda pilih bukan gambar',
  'mime_in'=>'Yang Anda pilih bukan gambar'
   
  ]]]))  {
  
return redirect()->to ('/toko')->withInput();
}


// ambil gambar
$fileLogoToko = $this->request->getFile ('logoToko');

if ($fileLogoToko->getError() == 4)
{ $namaLogoToko ='default_profile.png'; }

else {

//ambil nama file random
$namaLogoToko = $fileLogoToko->getRandomName();

// pindahkan gambar ke folder gbr-cashflow
$fileLogoToko->move('logo_toko', $namaLogoToko);

}


$this->tokoModel->save([
  'id_toko'=>$id_toko,
  
  'nama_toko'=>$this->request->getVar('nama_toko'),  
  'logoToko'=>$namaLogoToko
  
  ]);

  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Toko Berhasil Diubah.');
  
  return redirect()->to('/toko');
  
}
   
    
public function delete($id_toko)

{

// cari foto
$toko = $this->tokoModel->find($id_toko);

// periksa jika foto bukan default
if ($toko ['logoToko'] != 'default_profile.png') {

unlink('logo_toko/' .$toko['logoToko']);
}

$this->tokoModel->delete($id_toko);

session()->setFlashdata('pesan', 'Aye..!😆😀😎 Berhasil Dihapus.');
  
return redirect()->to('/toko');

} 

    
public function edit($id_toko)
{
    	   	    
session();
    	   	    
$toko = $this->tokoModel->find($id_toko);
      	    
$data = [
    'title'=>'Edit My Shop',
    'toko'=>$toko,
    'validation'=> \Config\Services::validation()
    ];	 
   	
    return view('toko/edit',$data);
}


public function update($id_toko)
   
{

if (!$this->validate ([

'logoToko'=>['rules'=>'max_size[logoToko,1024]|is_image[logoToko]|mime_in[logoToko,image/jpg,image/jpeg,image/png]',

  'errors'=> [
  'max_size'=>'Gambar terlalu besar (maks:1 MB)',
  'is_image'=>'Yang Anda pilih bukan gambar',
  'mime_in'=>'Yang Anda pilih bukan gambar'
   
  ]]]))  {
  
return redirect()->to ('/toko')->withInput();
}



// ambil gambar
$fileLogoToko = $this->request->getFile ('logoToko');

if ($fileLogoToko->getError() == 4)
{ $namaLogoToko ='default_profile.png'; }

else {

//ambil nama file random
$namaLogoToko = $fileLogoToko->getRandomName();

// pindahkan gambar ke folder gbr-cashflow
$fileLogoToko->move('logo_toko', $namaLogoToko);

unlink('logo_toko/' .$toko['logoToko']);
}

$this->tokoModel->save([
  'id_toko'=>$id_toko,
  
  'nama_toko'=>$this->request->getVar('nama_toko'),  
  'logoToko'=>$namaLogoToko
  
  ]);

  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Toko Berhasil Diubah.');
  
  return redirect()->to('/toko');
  
}
   
 
public function invoice()
{
     	    
$data = [
    'title'=>'My Invoice'
     ];	 
   	
    return view('toko/invoice',$data);
}


public function detail_produk()
{
     	    
$data = [
    'title'=>'Detail Produk'
     ];	 
   	
    return view('toko/detail_produk',$data);
}
 
    
}
	    


