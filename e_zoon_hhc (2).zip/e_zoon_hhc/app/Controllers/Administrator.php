<?php namespace App\Controllers;

use App\Models\DjosModel;
use App\Models\BlogsModel;
use App\Models\VicharModel;
use App\Models\UsersModel;

class Administrator extends BaseController

{
protected $vicharModel;
protected $djosModel;
protected $blogsModel;
protected $db, $builder, $usersModel;

public function __construct()

{
$this->vicharModel = new VicharModel();
$this->djosModel = new DjosModel();
$this->blogsModel = new BlogsModel();

$this->usersModel = new UsersModel();
$this->db      = \Config\Database::connect();
$this->builder = $this->db->table('users'); 
}


public function index()
{	
    $data = ['title'=>'Administrator'];	
    return view('administrator/index',$data);
}

public function adminKeuangan()
{	
    $data = ['title'=>'Admin Keuangan'];	
    return view('administrator/adminKeuangan/index',$data);
}

public function adminHapee()
{	
    $data = ['title'=>'Admin Hapee'];	
    return view('administrator/adminHapee/index',$data);
}

public function adminSwizh()
{	
    $data = ['title'=>'Admin Swizh'];	
    return view('administrator/adminSwizh/index',$data);
}


public function adminEmpathy()
{

$djos = $this->djosModel->orderBy('id desc')->findAll();
 
$data = [
    'title'=>'Admin Empathy',
    'djos'=>$djos
    ];	          
    return view('administrator/adminEmpathy/index',$data);
}


public function list_blog()
{

$blogs = $this->blogsModel->orderBy('id desc')->findAll();
	    
$data = [
    'title'=>'List Blogs',
    'blogs'=>$blogs
    ];	   
     return view('administrator/blogs/list_blog',$data);}
     

public function tambah_blog()
{

$blogs = $this->blogsModel->orderBy('id desc')->findAll();
	    
$data = [
    'title'=>'Tambah Blog HHC',
    'blogs'=>$blogs
    ];	   
     return view('administrator/blogs/tambah_blog',$data);}


public function save_blog()

{

 $this->blogsModel->save([
  
  'judul'=>$this->request->getVar('judul'),
  'blogger'=>$this->request->getVar('blogger'),
  'isi_blog'=>$this->request->getVar('isi_blog')
   ]);
  
  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Blog Berhasil Ditambahkan.');
  
  return redirect()->to('/administrator/list_blog');
  
}


public function delete_blog($id)

{
$this->blogsModel->delete($id);

session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Blog Berhasil Dihapus.');
  

return redirect()->to('/administrator/list_blog');

}


public function edit_blog($id)
{
    	   	    
$blogs = $this->blogsModel->find($id);
      	    
$data = [
    'title'=>'Edit Info / Promo',
    'blogs'=>$blogs
    ];	 
  
  return view('administrator/blogs/edit_blog',$data);}
          

public function update_blog($id)
{

$this->blogsModel->save([
  'id'=>$id, 
  'judul'=>$this->request->getVar('judul'),
  'blogger'=>$this->request->getVar('blogger'),
  'isi_blog'=>$this->request->getVar('isi_blog')
  ]);

  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Blog Berhasil Diedit.');
  
  return redirect()->to('/administrator/list_blog'); 
}
 

public function list_vichar()
{

$vichar = $this->vicharModel->orderBy('id desc')->findAll();
	    
$data = [
    'title'=>'List Vichar',
    'vichar'=>$vichar
    ];	   
     return view('administrator/vichar/list_vichar',$data);
}
     

public function tambah_vichar()
{

$vichar = $this->vicharModel->orderBy('id desc')->findAll();
	    
$data = [
    'title'=>'Vichar Editor',
    'vichar'=>$vichar
    ];	   
     return view('administrator/vichar/tambah_vichar',$data);
}


public function save_vichar()

{

 $this->vicharModel->save([
  
  'tanggal'=>$this->request->getVar('tanggal'),
  'judul'=>$this->request->getVar('judul'),
  'link_video'=>$this->request->getVar('link_video')
  
   ]);
  
  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Video Berhasil Ditambahkan.');
  
  return redirect()->to('/administrator/list_vichar');  
}


public function delete_vichar($id)

{
$this->vicharModel->delete($id);

session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Video Berhasil Dihapus.');
  
return redirect()->to('/administrator/list_vichar');
}


public function edit_vichar($id)
{
    	   	    
$vichar = $this->vicharModel->find($id);
      	    
$data = [
    'title'=>'Edit Video',
    'vichar'=>$vichar
    ];	 
  
  return view('administrator/vichar/edit_vichar',$data);
}
          

public function update_vichar($id)
{

$this->vicharModel->save([
  'id'=>$id,
  
  'tanggal'=>$this->request->getVar('tanggal'),
  'judul'=>$this->request->getVar('judul'),  
  'link_video'=>$this->request->getVar('link_video')
  ]);

  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Video Berhasil Diedit.');
  
  return redirect()->to('/administrator/list_vichar');  
}



public function list_member()
{

$data ['title'] = 'Data Member';

$this->builder->select('users.id as userid, fullname, telp, sponsor, foto, created_at');

$query = $this->builder->get();

$data['users'] = $query->getResult();
   	
    return view('administrator/membership/list_member',$data);
}

public function all_member()
{	    
$data ['title'] = 'All Member';
    
//    $users= new\Myth\Auth\Models\UserModel();
//    $data['users']= $users->findAll();

$this->builder->select('users.id as userid, username, email, name');
$this->builder->join('auth_groups_users', 'auth_groups_users.user_id = users.id');
$this->builder->join('auth_groups', 'auth_groups.id = auth_groups_users.group_id');
$query = $this->builder->get();

$data['users'] = $query->getResult();
   	
    return view('membership/all_member',$data);
}

public function member_detail($id=0)
{	    
$data ['title'] = 'Detail Member';

$this->builder->select('users.id as userid, username, email, fullname, foto, created_at, telp, peringkat, jenkel, sponsor, alamat, propinsi, kabupaten, kecamatan, deskel, negara, agama, mabank, norek, an');
//$this->builder->join('auth_groups_users', 'auth_groups_users.user_id = users.id');
//$this->builder->join('auth_groups', 'auth_groups.id = auth_groups_users.group_id');

$this->builder->where('users.id', $id);
$query = $this->builder->get();

$data['user'] = $query->getRow();

if (empty ($data['user'])) {
    return redirect()->to('/administrator/list_member');
}
  	
    return view('administrator/membership/member_detail',$data);
}



}