<?php namespace App\Controllers;

use App\Models\ProdukModel;
use App\Models\BlogsModel;

class Hapee extends BaseController
{

protected $produkModel;
protected $blogsModel;

public function __construct()

{
$this->produkModel = new ProdukModel();
$this->db      = \Config\Database::connect();
$this->builder = $this->db->table('produk'); 
$this->blogsModel = new BlogsModel();
}

public function index()
{

$produk = $this->produkModel->orderBy('id asc')->findAll();

$data = [
    'title'=>'Hapee - Market Place HHC',
    'produk'=>$produk   
    ];	 
          
    return view('platform/hapee/home',$data);
}

    
    
public function benefit()
{	    
$data = [
    'title'=>'Benefit Hapee HHC'];	
return view('platform/hapee/benefit',$data);
}

   
public function blogs()
{

$blogs = $this->blogsModel->orderBy('id desc')->findAll();

$data = [
    'title'=>'Bloggers HHC',
    'blogs'=>$blogs
    ];	 
          
    return view('platform/hapee/blogs',$data);
} 
   
   
public function produk_detail($id=0)
{	    
$data ['title'] = 'Detail Produk';

$this->builder->select('produk.id as idproduk, image, nama_produk, kategori, created_at, berat, harga, pv, nama_toko, deskripsi, kondisi, min_order, brand, satuan_produk');
//$this->builder->join('produk_foto', 'produk_foto.id_foto = produk.id');
//$this->builder->join('auth_groups', 'auth_groups.id = auth_groups_users.group_id');

$this->builder->where('produk.id', $id);
$query = $this->builder->get();

$data['produk'] = $query->getRow();
  	
    return view('platform/hapee/produk_detail',$data);
}
 
  
public function invoice()
{	    
$data = [
    'title'=>'Invoice Hapee'];	
return view('platform/hapee/invoice',$data);
} 
  
   
} 