<?php namespace App\Controllers;

use App\Models\ProdukModel;
use App\Models\BlogsModel;

class AdminHapee extends BaseController
{

protected $produkModel;
protected $blogsModel;

public function __construct()

{
$this->produkModel = new ProdukModel();
$this->blogsModel = new BlogsModel();
}


public function listProduk()
{

$produk = $this->produkModel->orderBy('id desc')->findAll();

$data = [
    'title'=>'Daftar Produk',
    'produk'=>$produk
    ];	   
     return view('administrator/adminHapee/listProduk',$data);}
    
    
public function tambahProduk()
{

session();
	    
$data = [
    'title'=>'Form Tambah Produk',
    'validation'=> \Config\Services::validation()
    ];	   
     return view('administrator/adminHapee/tambahProduk',$data);}


public function saveProduk()

{

if (!$this->validate ([

'image'=>['rules'=>'max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/png]',

  'errors'=> [
  'max_size'=>'Gambar terlalu besar (maks:1 MB)',
  'is_image'=>'Yang Anda pilih bukan gambar',
  'mime_in'=>'Yang Anda pilih bukan gambar'
   
  ]]]))  {
  
return redirect()->to ('/adminHapee/tambahProduk')->withInput();
   
   }



// ambil gambar
$fileImage = $this->request->getFile ('image');


//ambil nama file
$namaImage = $fileImage->getName();

// pindahkan gambar ke folder gbr-cashflow
$fileImage->move('aset/img/produkHome', $namaImage);



 $this->produkModel->save([ 
 
  'nama_produk'=>$this->request->getVar('nama_produk'),
  'kategori'=>$this->request->getVar('kategori'),
  'brand'=>$this->request->getVar('brand'),
  'produsen'=>$this->request->getVar('produsen'),
  'berat'=>$this->request->getVar('berat'),
  'harga'=>$this->request->getVar('harga'),
  'satuan_produk'=>$this->request->getVar('satuan_produk'),
  'pv'=>$this->request->getVar('pv'),
  'deskripsi'=>$this->request->getVar('deskripsi'),
  'nama_toko'=>$this->request->getVar('nama_toko'),
  'kondisi'=>$this->request->getVar('kondisi'),
  'min_order'=>$this->request->getVar('min_order'),
  'sistem_bayar'=>$this->request->getVar('sistem_bayar'),
  'brand'=>$this->request->getVar('brand'),
  'nama_produsen'=>$this->request->getVar('nama_produsen'),
  'alamat_produsen'=>$this->request->getVar('alamat_produsen'),
  'image'=>$namaImage
  ]);
  
  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Produk Berhasil Ditambahkan.');
  
  return redirect()->to('/adminHapee/listProduk');
  
}


public function deleteProduk($id)

{

// cari gbr
$produk = $this->produkModel->find($id);

// periksa jika foto bukan default
if ($produk ['image'] != 'default.png') {

unlink('aset/img/produkHome/' .$produk['image']);
}

$this->produkModel->delete($id);

session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Produk Berhasil Dihapus.');
  

return redirect()->to('/adminHapee/listProduk');

}


public function editProduk($id)
{
 
 session();
    	   	    
$produk = $this->produkModel->find($id);
      	    
$data = [
    'title'=>'Edit Produk',
    'produk'=>$produk,
    'validation'=> \Config\Services::validation()
    ];	 
  
  return view('administrator/adminHapee/editProduk',$data);}
          

public function updateProduk($id)
{

if (!$this->validate ([

'image'=>['rules'=>'max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/png]',

  'errors'=> [
  'max_size'=>'Gambar terlalu besar (maks:1 MB)',
  'is_image'=>'Yang Anda pilih bukan gambar',
  'mime_in'=>'Yang Anda pilih bukan gambar'
   
  ]]]))  {
  
// $validation= \Config\Services :: validation();

//   return redirect()->to ('/djosdok/tambah_djosdok')->withInput()->with('validation', $validation);
   
   return redirect()->to ('/adminHapee/editProduk')->withInput();
   
   }

// ambil gambar
$fileImage = $this->request->getFile ('image');

if ($fileImage->getError() == 4)
{ $namaImage = $this->request->getVar('imageLama'); }

else {

//ambil nama file random
$namaImage = $fileImage->getName();

// pindahkan gambar ke folder gbr-cashflow
$fileImage->move('aset/img/produkHome', $namaImage);

// hapus file lama
unlink('aset/img/produkHome/' .$this->request->getVar('imageLama'));

}

 $this->produkModel->save([ 
  'id'=>$id,
  'nama_produk'=>$this->request->getVar('nama_produk'),
  'kategori'=>$this->request->getVar('kategori'),
  'brand'=>$this->request->getVar('brand'),
  'produsen'=>$this->request->getVar('produsen'),
  'berat'=>$this->request->getVar('berat'),
  'harga'=>$this->request->getVar('harga'),
  'pv'=>$this->request->getVar('pv'),
  'satuan_produk'=>$this->request->getVar('satuan_produk'),
  'deskripsi'=>$this->request->getVar('deskripsi'),
  'nama_toko'=>$this->request->getVar('nama_toko'),
  'kondisi'=>$this->request->getVar('kondisi'),
  'min_order'=>$this->request->getVar('min_order'),
  'sistem_bayar'=>$this->request->getVar('sistem_bayar'),
  'brand'=>$this->request->getVar('brand'),
  'nama_produsen'=>$this->request->getVar('nama_produsen'),
  'alamat_produsen'=>$this->request->getVar('alamat_produsen'),
  'image'=>$namaImage
  ]);

  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Produk Berhasil Diedit.');
  
  return redirect()->to('/adminHapee/listProduk');
  
}
  

  
   
    
}
