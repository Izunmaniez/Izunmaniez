<?= $this-> extend('platform/template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this-> include('platform/template/navbar'); ?>


        <!-- account section start -->
    <div class="account-section bg_img" data-background="/aset/img/gold/bg6.jpg">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-xl-5 col-lg-7">
            <div class="account-card">
              <div class="account-card__header bg_img overlay--one" data-background="/aset/img/gold/bg5.jpg">
                <h2 class="section-title">Login to <span class="base--color">HHC</span></h2>
                <p>Satu akun untuk semua platform. </p>
              </div>
              <div class="account-card__body">
              
              <?= view('Myth\Auth\Views\_message_block') ?>					
                                 
<form action="<?= route_to('login') ?>" method="post">
<?= csrf_field() ?>

<?php if ($config->validFields === ['email']): ?>
                                 
<div class="form-group">              
<label>Username</label>
<input type="email" class="form-control <?php if(session('errors.login')) : ?>is-invalid<?php endif ?>" name="login" placeholder="contoh@gmail.com" value="<?= old('email') ?>" autofocus> 

<div class="invalid-feedback">
<?= session('errors.login') ?>
</div>
</div>
<?php else: ?>

<div class="form-group">              
<label>Username</label>
<input type="text" class="form-control <?php if(session('errors.login')) : ?>is-invalid<?php endif ?>" name="login" placeholder="Username" value="<?= old('login') ?>" autofocus>
 
<div class="invalid-feedback">
<?= session('errors.login') ?>
</div>
</div>
<?php endif; ?>             
                                    
                  
<div class="form-group">
<label>Password</label>
<input type="password" class="form-control <?php if(session('errors.password')) : ?>is-invalid<?php endif ?>" name="password" placeholder="Enter password">
<div class="invalid-feedback">
<?= session('errors.password') ?>
</div>
</div>               
               
                  
<div class="form-group d-flex justify-content-center">
</div>
<div class="form-group">
<link href="https://fonts.googleapis.com/css?family=Henny+Penny&display=swap" rel="stylesheet"><div style="height: 46px; line-height: 46px; width:100%; text-align: center; background-color: #003; color: #CCA354!important; font-size: 26px; font-weight: bold; letter-spacing: 20px; font-family: 'Henny Penny', cursive;  -webkit-user-select: none; -moz-user-select: none;-ms-user-select: none;user-select: none;  display: flex; justify-content: center;" class="captcha"><span style="    float:left;     -webkit-transform: rotate(5deg);">5</span><span style="    float:left;     -webkit-transform: rotate(54deg);">9</span><span style="    float:left;     -webkit-transform: rotate(-14deg);">1</span><span style="    float:left;     -webkit-transform: rotate(-36deg);">2</span><span style="    float:left;     -webkit-transform: rotate(-53deg);">3</span><span style="    float:left;     -webkit-transform: rotate(-57deg);">2</span></div><input type="hidden" name="captcha_secret" value="1a7d12be824eba411e13d23d76ebdb9a901b311db75adacfe91b638b5d522077">    </div>


    <div class="form-group">
        <input type="text" name="captcha" class="form-control" placeholder="Enter code">
    </div>


                  <div class="mt-3">
                    <button type="submit" class="cmn-btn">Login</button>
                  </div>
                  <div class="form-row mt-2">
                    <div class="col-sm-6">
                      <div class="form-group form-check pl-0">
                        <p class="f-size-14">Lupa Password? <a href="<?= route_to('forgot') ?>" class="base--color">Reset Password</a></p>
                      </div>
                    </div>
                    <div class="col-sm-6 text-sm-right">
                      <p class="f-size-14">Belum terdaftar? <a href="<?= route_to('register') ?>" class="base--color">Yuk! Registrasi Sekarang! </a></p>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- account section end -->
    

<?= $this-> endSection(); ?>
