<?php namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php'))
{
	require SYSTEMPATH . 'Config/Routes.php';
}

/**
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

/**
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.


$routes->get('/', 'Hapee::index');
$routes->group('', ['filter' => 'login'], function($routes){
//$routes->get('home', 'Pages::home');
//$routes->get('/administrator', 'Administrator::index');

//}); 

$routes->group('/administrator', 'Administrator::index', ['filter' => 'role:owner, super_admin']);
$routes->get('/administrator/index', 'Administrator::index', ['filter' => 'role:owner, super_admin']);
$routes->get('/administrator/adminKeuangan', 'Administrator::adminKeuangan', ['filter' => 'role:admin_keuangan']);
$routes->get('/administrator/adminKeuangan/index', 'Administrator::adminKeuangan/index', ['filter' => 'role:admin_keuangan']);
$routes->get('/administrator/adminHapee', 'Administrator::adminHapee', ['filter' => 'role:admin_hapee']);
$routes->get('/administrator/adminHapee/index', 'Administrator::adminHapee/index', ['filter' => 'role:admin_hapee']);
$routes->get('/administrator/adminSwizh', 'Administrator::adminSwizh', ['filter' => 'role:admin_swizh']);
$routes->get('/administrator/adminSwizh/index', 'Administrator::adminSwizh/index', ['filter' => 'role:admin_swizh']);
$routes->get('/administrator/adminShotoo', 'Administrator::adminShotoo', ['filter' => 'role:admin_shotoo']);
$routes->get('/administrator/adminShotoo/index', 'Administrator::adminShotoo/index', ['filter' => 'role:admin_shotoo']);
$routes->get('/administrator/adminEmpathy', 'Administrator::adminEmpathy', ['filter' => 'role:admin_empathy']);
$routes->get('/administrator/adminEmpathy/index', 'Administrator::adminEmpathy/index', ['filter' => 'role:admin_empathy']);


$routes->get('/administrator/list_vichar', 'Administrator::list_vichar', ['filter' => 'role:owner, super_admin']);
$routes->get('/administrator/tambah_vichar', 'Administrator::tambah_vichar', ['filter' => 'role:owner, super_admin']);
$routes->get('/administrator/edit_vichar', 'Administrator::edit_vichar', ['filter' => 'role:owner, super_admin']);
$routes->get('/administrator/edit_vichar/(:num)', 'Administrator::edit_vichar/$1', ['filter' => 'role:owner, super_admin']);
$routes->get('/administrator/delete_vichar/(:num)', 'Administrator::delete_vichar/$1', ['filter' => 'role:owner, super_admin']);

//$routes->get('/administrator/list_blog', 'Administrator::list_blog', ['filter' => 'role:owner, super_admin']);
$routes->get('/administrator/tambah_blog', 'Administrator::tambah_blog', ['filter' => 'role:owner, super_admin']);
$routes->get('/administrator/edit_blog', 'Administrator::edit_blog', ['filter' => 'role:owner, super_admin']);
$routes->get('/administrator/edit_blog/(:num)', 'Administrator::edit_blog/$1', ['filter' => 'role:owner, super_admin']);
$routes->get('/administrator/delete_blog/(:num)', 'Administrator::delete_blog/$1', ['filter' => 'role:owner, super_admin']);


$routes->get('/membership', 'Membership::index', ['filter' => 'role:admin_keuangan, admin_hapee, admin_swizh, admin_shotoo, admin_empathy']);
$routes->get('/membership/index', 'Membership::index', ['filter' => 'role:admin_keuangan, admin_hapee, admin_swizh, admin_shotoo, admin_empathy']);
$routes->get('/membership/(:num)', 'Membership::detail/$1', ['filter' => 'role:admin_keuangan, admin_hapee, admin_swizh, admin_shotoo, admin_empathy']);


$routes->get('/administrator/adminHapee/listProduk', 'AdminHapee::listProduk', ['filter' => 'role:admin_hapee']);
$routes->get('/administrator/adminHapee/tambahProduk', 'AdminHapee::tambahProduk', ['filter' => 'role:admin_hapee, users']);
$routes->get('/administrator/adminHapee/editProduk', 'AdminHapee::editProduk', ['filter' => 'role:admin_hapee, users']);
$routes->get('/administrator/adminHapee/editProduk/(:num)', 'AdminHapee::editProduk/$1', ['filter' => 'role:admin_hapee, users']);
$routes->get('/administrator/adminHapee/deleteProduk/(:num)', 'AdminHapee::deleteProduk/$1', ['filter' => 'role:admin_hapee']);


$routes->get('/adminEmpathy/listCashflow', 'AdminEmpathy::listCashflow', ['filter' => 'role:admin_empathy']);
$routes->get('/administrator/adminEmpathy/tambahCashflow', 'AdminEmpathy::tambahCashflow', ['filter' => 'role:admin_empathy']);
$routes->get('/administrator/adminEmpathy/editCashflow', 'AdminEmpathy::editCashflow', ['filter' => 'role:admin_empathy']);
$routes->get('/administrator/adminEmpathy/editCashflow/(:num)', 'AdminEmpathy::editCashflow/$1', ['filter' => 'role:admin_empathy']);
$routes->get('/administrator/adminEmpathy/deleteCashflow/(:num)', 'AdminEmpathy::deleteCashflow/$1', ['filter' => 'role:admin_empathy']);

$routes->get('/administrator/adminEmpathy/listGalery', 'AdminEmpathy::listGalery', ['filter' => 'role:admin_empathy']);
$routes->get('/administrator/adminEmpathy/tambahGalery', 'AdminEmpathy::tambahGalery', ['filter' => 'role:admin_empathy']);
$routes->get('/administrator/adminEmpathy/editGalery', 'AdminEmpathy::editGalery', ['filter' => 'role:admin_empathy']);
$routes->get('/administrator/adminEmpathy/editGalery/(:num)', 'AdminEmpathy::editGalery/$1', ['filter' => 'role:admin_empathy']);
$routes->get('/administrator/adminEmpathy/deleteGalery/(:num)', 'AdminEmpathy::deleteGalery/$1', ['filter' => 'role:admin_empathy']);




/**
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php'))
{
	require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
