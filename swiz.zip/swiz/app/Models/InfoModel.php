<?php

namespace App\Models;

use CodeIgniter\Model;

class InfoModel extends Model
{
    protected $table         = 'info';
    protected $allowedFields = ['judul', 'isi_info'];
    protected $useTimestamps = true;
    
}