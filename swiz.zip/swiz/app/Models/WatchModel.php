<?php

namespace App\Models;

use CodeIgniter\Model;

class WatchModel extends Model
{
    protected $table         = 'watch';
    protected $allowedFields = ['tanggal', 'judul', 'link_video'];
    protected $useTimestamps = true;
       
}