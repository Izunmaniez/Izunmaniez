<?php namespace App\Models;

use CodeIgniter\Model;

class FatwaYmuModel extends Model
{

protected $table ='fatwaYmu';

protected $useTimestamps = true;

protected $allowedFields = ['id', 'judul', 'fatwaTextYmu',  'fatwaGbrYmu', 'fatwaVideoYmu', 'created_at'];



}