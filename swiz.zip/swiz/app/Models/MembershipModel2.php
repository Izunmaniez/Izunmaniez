<?php

namespace App\Models;

use CodeIgniter\Model;

class MembershipModel extends Model
{
protected $table ='users';

protected $useTimestamps = true;

protected $allowedFields = ['peringkat', 'username', 'email', 'fullname', 'telp', 'inviter', 'jenkel', 'tanglah', 'templah', 'alamat', 'deskel', 'kecamatan', 'kabupaten', 'negara', 'agama', 'norek', 'mabank', 'an'];

}