<?php namespace App\Models;

use CodeIgniter\Model;

class UsersModel extends Model
{

protected $table ='users';

protected $useTimestamps = true;

protected $allowedFields = ['fullname', 'telp', 'inviter', 'peringkat', 'email', 'jenkel', 'foto', 'templah', 'tanglah', 'alamat', 'deskel', 'kecamatan', 'kabupaten', 'propinsi', 'negara', 'agama', 'norek', 'mabank', 'an'];


}