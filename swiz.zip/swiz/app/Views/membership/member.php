<?= $this-> extend('template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this-> include('template/topbar'); ?>

<?= $this-> include('template/sidebar'); ?>


 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>DATA MEMBER</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#"><?= date('d M Y'); ?></a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
           <div class="card">
              <div class="card-body" style="overflow:auto;">
                <table id="example1" class="table table-bordered table-stripped">
                  <thead class="table-primary">
                  <tr>
                    <th>#</th>
                    <th>Nama_Lengkap</th>  
                    <th>Telepon</th>       
                    <th>Peringkat</th>  
                    <th>Inviter</th>  
                    <th>Toko</th>
                    <th>Detail</th>
                   
                  </tr>
                  </thead>
                  <tbody>
 
 
 <?php $i=1; ?>
  <?php foreach ($users as $user) : ?>   
  <?php if ($user->userid >=9) : ?> 
  
                  <tr>
                    <td><?= $user->userid; ?></td>
                    <td><?= $user->fullname; ?></td>
                   <td> <a class="d-flex" href="https://api.whatsapp.com/send?phone=62<?= $user->telp; ?>&text=Hallo..%20Assalamu'alaikum <?= $user->telp; ?> "><span class="badge badge-light"><?= $user->telp; ?></span>
                <i class="fab fa-whatsapp-square text-success"></i></a>   
                 </td>
                   <td><span class="badge badge-info">WHITE</span></td>
                   <td><?= $user->inviter; ?></td>
                   <td></td>
                   <td><a href="<?= base_url ('membership/' . $user->userid); ?>" class="img">
                  <img class="img-circle" style="width:33px; height:33px;" src="/foto_profile/<?= $user->foto; ?>"></a>
                    </td>                                      
                  </tr>                 
  <?php endif; ?> 
  <?php endforeach; ?>   
 
      
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
</div>
</div>
</div>
</section>
</div>
            


<?= $this-> include('template/footer'); ?>


<?= $this-> endSection(); ?>



                   
 
