<?= $this-> extend('template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this-> include('template/topbar'); ?>

<?= $this-> include('template/sidebar'); ?>


 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>ALL MEMBER</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#"><?= date('d M Y'); ?></a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
           <div class="card">
              <div class="card-header">
                 
    <!-- SEARCH FORM -->
    <form class="form-inline">
      <div class="input-group input-group-sm">
        <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
          <div class="input-group-append">
          <button class="btn btn-info" type="submit">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div>
    </form>
             
             
              </div><!-- /.card-header -->
              <div class="card-body" style="overflow:auto;">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>#</th>
  <!--                    <th>Peringkat</th>  -->
                    <th>User Name</th>       
   <!--                   <th>Nama Lengkap</th>  -->
  <!--                    <th>Telp.</th>    -->                          
                   <th>Email</th>
 <!--                    <th>Inviter</th>   -->
                    <th>Role</th>
                   <th>Option</th>
 <!--                  <th>Jenis Kelamin</th>  -->
  <!--                  <th>Desa/Kelurahan</th>   -->
  <!--                  <th>Kecamatan</th>   -->
  <!--                  <th>Kabupaten</th>  -->
 <!--                   <th>Propinsi</th>  -->
  <!--                  <th>Negara</th>   -->
   <!--                 <th>Agama</th     -->
   <!--                 <th>Tanggal Join</th>   -->
<!--      <th>Nomor Rekening</th>   -->
 <!--                    <th>Nama Bank</th>    -->
 <!--                   <th>Atas Nama</th>   -->
                   
                  </tr>
                  </thead>
                  <tbody>
                  
                   
  <?php $i=1; ?>
  <?php foreach ($users as $user) : ?>   
  
                  <tr>
                    <td><?= $i++; ?></td>
                    <td><?= $user->username; ?></td>
                   <td><?= $user->email; ?>  </td>
                   <td><?= $user->name; ?></td>
                    <td><a href="<?= base_url ('membership/' . $user->userid); ?>" class="toggle-down">Detail</a>
                    </td>                                      
                  </tr>                 
  
  <?php endforeach; ?>   
   
                 
              
                  
                  </tbody>
                  
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
</div>
</div>
</div>
</section>
</div>
            


<?= $this-> include('template/footer'); ?>


<?= $this-> endSection(); ?>
