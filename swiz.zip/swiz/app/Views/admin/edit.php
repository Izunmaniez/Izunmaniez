<?= $this-> extend('template/index'); ?>

<?= $this-> section('content'); ?>


<div class="container mt-2">
    
         <div class="card card-warning card-outline">
              <div class="card-header">
                <h3 class="card-title">
                  <i class="fas fa-edit"></i>
                  Edit My Profile
                </h3>
              </div>
          <div class="card-body">
              
<form action="/admin/update/<?= user()->id; ?>" method="post" enctype="multipart/form-data">
<?= csrf_field(); ?>

 
<div class="card" style="width: 17rem;">
  <img src="/foto_profile/<?= user()->foto; ?>" class="card-img-top" alt="">
   
<center><i style="color:coral;">Ukuran foto maksimal 1 MB</i></center>
 
</div>

<div class="btn btn-warning my-2">
  <input type="file"  id="foto" name="foto" value="<?= user()->foto; ?>" >
</div>



<table>
<tr><td colspan="3"><br /><b>BIO DATA</b></td></tr>

<tr><td>Nama Lengkap</td>
<td>
<input type="text" class="form-control mb-2"  id="fullname" name="fullname" value="<?= user()->fullname; ?>" autofocus>
</td>
</tr> 
 
<tr><td>Handphone</td>
<td>
<input type="text" class="form-control mb-2" id="telp" name="telp" value="<?= user()->telp; ?>"   >
</td>
</tr> 

<tr><td>Email</td>
<td>
<input type="email" class="form-control mb-2" id="email" name="email" value="<?= user()->email; ?>"   >
</td>
</tr> 

<tr><td colspan="3"><br /><b>ACCOUNT BANK</b></td></tr>

<tr><td>Nama Bank</td>
<td>
<input type="text" class="form-control mb-2" id="mabank" name="mabank" value="<?= user()->mabank; ?>" >
</td>
</tr> 

<tr><td>Nomor Rekening</td>
<td>
<input type="integer" class="form-control mb-2" id="norek" name="norek" value="<?= user()->norek; ?>" >
</td>
</tr> 

<tr><td>Atas Nama</td>
<td>
<input type="text" class="form-control mb-2" id="an" name="an" value="<?= user()->an; ?>" >
</td>
</tr> 

</table>                    
      
  <p><p>

  <button type="submit" class="btn btn-warning">Simpan</button>
  
  <a href="/admin" class="btn btn-secondary ml-7">Cancel</a>
         

</form>     
              
  </div><!-- /.container-fluid -->
     
<?= $this-> include('template/footer'); ?>
<?= $this-> endSection(); ?>










