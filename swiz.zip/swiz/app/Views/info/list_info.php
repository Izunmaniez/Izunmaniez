<?= $this-> extend('template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this->include('template/topbar');?>

<?= $this->include('template/sidebar');?>

<div class="container">
    <div class="row">
        <div class="col">
 <p>   

 <?php if(session()->getFlashdata('pesan')) : ?>

<div class="alert alert-success" role="alert">

<?= session()->getFlashdata('pesan');?>

</div>
  
<?php endif; ?>
<form action="" method="post">
 <?= csrf_field(); ?> 
 
 <?php foreach ($info as $inf) : ?>
 
       
<h5>Judul : <?=$inf['judul']; ?></h5>

<tr>
<td>   
<a href="/info/edit/<?= $inf['id']; ?> " class="btn btn-warning">Edit</a>
</td>

<a href="/membership" class="btn btn-secondary btn-md float-right mr-1">Back</a>
                  
<td>
<form action="/info/delete/<?= $inf['id']; ?>" method="post">
<?= csrf_field(); ?>
<input type="hidden" name="_method" value="delete">

<button type="submit" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus info ini?');">Hapus</button>
</form>
</td>
</tr>        
                   
 <hr>
 
   <?php endforeach; ?>
       
    </form>
  
   </div>
    </div>
</div> 

<?= $this->include('template/footer');?>

<?= $this-> endSection(); ?>