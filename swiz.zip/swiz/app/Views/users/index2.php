<?= $this-> extend('users/template/index'); ?>


<?= $this-> section('content'); ?>  

<?= $this-> include('users/topbar'); ?>

<?= $this-> include('users/sidebar'); ?>
               

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
       <!-- Main content -->        
    <section class="content">
          <div class="card card-solid">
        <div class="card-body">
    
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
           <h1 class="m-0 text-dark"> My Dashboard</h1>                    
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#"><?= date('d M Y') ; ?></a></li>            
            </ol>           
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
              
                               
<div class="top-dashboard"> 
  
<div class="foto-profile">
  <img src="<?= base_url('foto_profile/' .user()->foto); ?>"  >
 <br>  
     <small><b>Hai ...😀</b></small><br>
      <?= user()->username; ?>
  
</div>

<div class="toko">
<div class="toko-item"><a href="/toko/detail_produk"><img src="/dashboard/toko1.png"><br>Toko<br>Milik Saya</a></div>
<div class="toko-item"><a href="#"><img src="/dashboard/toko2.png"><br>Toko<br>Referal Saya</a>
</div>
</div>
</div>

</div>
</div>
</section>

      <!-- Main content -->        
    <section class="content">

      <!-- Default box -->
      <div class="card card-solid">
        <div class="card-body">
          <div class="row">
            <div class="col-12 col-sm-6">
              <h3 class="d-inline-block d-sm-none"><?= user()->username; ?></h3>
              
              </div>
      
            <a href="" class="info-box elevation-3">
              <span class="info-box-icon bg-info"><img src="/dashboard/harta.png"></i></span>
              <div class="info-box-content">
                <span class="info-box-text"><h3>Bonus Saya</h3></span>
                <span class="info-box-number">1,410</span>
              </div>           
            </a>                           
      
            <a href="" class="info-box elevation-3">
              <span class="info-box-icon bg-info"><img src="/dashboard/keranjang.png"></i></span>
              <div class="info-box-content">
                <span class="info-box-text"><h3>Belanja Saya</h3></span>
                <span class="info-box-number">1,410</span>
              </div>           
            </a>   
            
              <a href="" class="info-box elevation-3">
              <span class="info-box-icon bg-info"><img src="/dashboard/sedekah.png"></i></span>
              <div class="info-box-content">
                <span class="info-box-text"><h3>Sedekah Saya</h3></span>
                <span class="info-box-number">1,410</span>
              </div>           
            </a>   
            
            <a href="/users/grup" class="info-box elevation-3">
              <span class="info-box-icon bg-info"><img src="/dashboard/grup.png"></i></span>
              <div class="info-box-content">
                <span class="info-box-text"><h3>Grup Saya</h3></span>
                <span class="info-box-number">1,410</span>
              </div>           
            </a>    
            
            <a href="" class="info-box elevation-3">
              <span class="info-box-icon bg-info"><i class="fas fa-share text-light"></i></i></span>
              <div class="info-box-content">
                <span class="info-box-text"><h3>Share Link Referal</h3></span>
                <span class="info-box-number">1,410</span>
              </div>           
            </a>      
            
     </div>
</div>
</div>
</section>  

    
            
               <!-- Main content -->
    <section class="content ">
     
     <div class="card-body">
      <div class="card card-solid">    
        <h3 class="mb-2">Silahkan Hubungi Admin</h3>
        <div class="row">
          <div class="col-md-2 col-sm-8">
            <div class="info-box-content">
              <span class="info-box-icon bg-light"><img src="/img/wa.png"></span>

              <div class="info-box-content">
                <span class="info-box-text">Admin</span>
                <span class="info-box-number">Penjualan</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-md-2 col-sm-8 ">
            <div class="info-box">
              <span class="info-box-icon bg-light"><img src="/img/wa.png"></span>

              <div class="info-box">
                <span class="info-box-text">Admin</span>
                <span class="info-box-number">Pengiriman</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-md-2 col-sm-8 ">
            <div class="info-box">
              <span class="info-box-icon bg-light"><img src="/img/wa.png"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Admin</span>
                <span class="info-box-number">Keuangan</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-md-2 col-sm-8 ">
            <div class="info-box">
              <span class="info-box-icon bg-light"><img src="/img/wa.png"></span>

              <div class="info-box-content">
                <span class="info-box-text">Admin</span>
                <span class="info-box-number">Membership</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-md-2 col-sm-8 ">
            <div class="info-box">
              <span class="info-box-icon bg-light"><img src="/img/wa.png"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Admin</span>
                <span class="info-box-number">DJOS</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row --> 
        </div>
       </div>
        
        </section>
                
 </div>

  <p><p>                          
<?= $this-> include('template/footer'); ?>


<?= $this-> endSection(); ?>