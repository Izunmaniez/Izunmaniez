<footer>
<div class="footer">
<a href="/" class="footer-item"><img src="/img/mars.png"><br>Belanja</a>
    
<a href="" class="footer-item"><img src="/dashboard/qris.png"><br>My QRIS</a>

<div class="container">
<div class="footer-item-middle" data-toggle="modal" data-target="#community"><img src="/img/logohhc.png"></div>

  <div class="modal fade" id="community">
    <div class="modal-dialog">
      <div class="modal-content">      
        <div class="modal-body">


<div class="vmvm">        
<div class="vmvm-item"> 
  <a class="btn btn-success dropdown-toggle" href="#" role="button" id="visi" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Visi </a>

  <div class="dropdown-menu" style="background-color:#DAF7A6; text-align:center; padding:5px 9px;" aria-labelledby="visi">
    <h3>VISI</h3>
Menjadi komunitasnya Para Leader yang Berakhlakul Karimah, Dermawan dan memiliki penghasilan minimal Satu Juta Rupiah per hari.

<p><p><p><p>

<div class="btn btn-success">Aye..?!!😀</div><p><p>
</div>
</div>




<div class="vmvm-item"> 
  <a class="btn btn-success dropdown-toggle" href="#" role="button" id="misi" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Misi </a>

    <div class="dropdown-menu" style="background-color:#DAF7A6; text-align:center; padding:5px 9px;" aria-labelledby="misi">
    <h3>MISI</h3>
1. Menjalankan semua program/platform HHC dengan didasari rasa penuh syukur dan suka-cita.<br>

2. Beradaptasi terhadap segala perkembangan teknologi dan Berinovasi tanpa batas.


<p><p><p><p>

<div class="btn btn-success">Aye..?!!😀</div><p><p>
</div>
</div>


<div class="vmvm-item"> 
  <a class="btn btn-success dropdown-toggle" href="#" role="button" id="value" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Value</a>

    <div class="dropdown-menu" style="background-color:#DAF7A6; text-align:center; padding:5px 9px;" aria-labelledby="value">
    <h3>VALUE</h3>
<b>7 PRINCESS  HHC</b> (PRINCiple of SuccESS)<br>
1. Teguhkan Impian dan Fokus.<br>
2. Bersyukur, bersuka-cita dan tidak mengeluh.<br>
3. Rutin bersedekah.<br>
4. Konsumsi yang halal.<br>
5. Tulus, Rendah hati, Respek dan Empati.<br>
6. Menjaga Integritas.<br>
7. Menjadi Leader yang menginspirasi.


<p><p><p><p>

<div class="btn btn-success">Aye..?!!😀</div><p><p>
</div>
</div>


<div class="vmvm-item"> 
  <a class="btn btn-success dropdown-toggle" href="#" role="button" id="motto" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Motto</a>

    <div class="dropdown-menu" style="background-color:#DAF7A6; text-align:center; padding:5px 9px;" aria-labelledby="motto">
    <h3>MOTTO</h3>
Kami Sangat Bersyukur!<br>
Kami Sangat Bahagia!<br>
Kami Sangat Sukses!

<p><p><p><p>

<div class="btn btn-success">Aye..?!!😀</div><p><p>
</div>
</div>



</div>  






           
 <h2 class="platform-judul-item">HHC PLATFORM</h2>

<div class="container-platform">
    
<a href="/pages/djos"class="platform-item"><img src="/content/platform_item.png"><br>H~DJOS</a>

<a href="#"class="platform-item"><img src="/content/platform_item.png"><br>H~NEWS</a>

<a href="/pages/watch"class="platform-item"><img src="/content/platform_item.png"><br>H~WATCH</a>

<a href="/pages/charger"class="platform-item"><img src="/content/platform_item.png"><br>H-CHARGER</a>

<a href="/pages/hp"class="platform-item"><img src="/content/platform_item.png"><br>H~POIN</a>

<a href="#"class="platform-item" style="color:black"><img src="/content/platform_item.png"><br>H~BARLEB</a>

<a href="#"class="platform-item"style="color:black"><img src="/content/platform_item.png"><br>H~COOPERATION</a>

<a href="#"class="platform-item"style="color:black"><img src="/content/platform_item.png"><br>H~CURRENCY</a>

<a href="#"class="platform-item"style="color:black"><img src="/content/platform_item.png"><br>H~TRADE</style></a>        

</div>
  
        <div class="modal-footer">
          <button type="button" class="btn btn-success" data-dismiss="modal">Aye..?!!😀</button>
        </div>   
           
      </div>
    </div>
  </div>
</div>
</div>



<a href="" class="footer-item"><img src="/dashboard/qris2.png"><br>Scan QRIS</a>


<a href="/logout" class="footer-item" onclick="return confirm('Yakin ingin keluar dari halaman dashboard?');"><img src="/dashboard/logout.png"><br>Logout</a>


</div>

</footer>

  
  
  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
  
  
  
  
  
  
  
  
  
  

  



<!-- jQuery -->
<script src="<?= base_url(); ?>/plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?= base_url(); ?>/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?= base_url(); ?>/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="<?= base_url(); ?>/plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="<?= base_url(); ?>/plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="<?= base_url(); ?>/plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="<?= base_url(); ?>/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="<?= base_url(); ?>/plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="<?= base_url(); ?>/plugins/moment/moment.min.js"></script>
<script src="<?= base_url(); ?>/plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?= base_url(); ?>/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="<?= base_url(); ?>/plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?= base_url(); ?>/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?= base_url(); ?>/dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?= base_url(); ?>/dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?= base_url(); ?>/dist/js/demo.js"></script>
</body>
</html>