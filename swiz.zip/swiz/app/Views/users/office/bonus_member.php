<?= $this-> extend('layout/template2'); ?>


<?= $this-> section('content'); ?>



<div class="container">
    <div class="row">
        <div class="col">
            
         <h1>Pendapatan Saya</h1>   
            
            
        </div>
    </div>
</div>
    
<?= $this-> endSection(); ?>
