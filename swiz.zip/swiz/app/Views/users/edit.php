<?= $this-> extend('template/index'); ?>

<?= $this-> section('content'); ?>


<div class="container mt-2">

      
      
<div class="card card-warning card-outline">
              <div class="card-header">
                <h3 class="card-title">
                  <i class="fas fa-edit"></i>
                  Edit My Profile
                </h3>
              </div>
              <div class="card-body">
              
<form action="/users/update/<?= user()->id; ?>" method="post" enctype="multipart/form-data">
<?= csrf_field(); ?>

<input type="hidden" name="fotoLama" value="<?= $users['foto']; ?>" >            
 
<div class="card" style="width: 17rem;">
  <img src="/foto_profile/<?= user()->foto; ?>" class="card-img-top">
   
<center><i style="color:coral;">Ukuran foto maksimal 1 MB</i></center>
</div>

<div class="form-group row">  
   <label for="foto" class="col-sm-2 col-form-label">Ganti Foto?</label>  
        
<div class="col-sm-6">   
  <div class="custom-file">                         
   <input type="file" class="custom-file-input <?= ($validation->hasError('foto')) ? 'is-invalid' : ''; ?>" id="foto" name="foto" onchange="previewImg()">
  <div class="invalid-feedback">
     <?= $validation->getError('foto'); ?>
  </div>  
<label class="custom-file-label" for="foto"><?= user()->foto; ?></label>
                           </div>
                        </div>  
                    </div>



<table>
<tr><td colspan="3"><br /><b>BIO DATA</b></td></tr>

<tr><td>Nama Lengkap</td>
<td>
<input type="text" class="form-control mb-2"  id="fullname" name="fullname" value="<?= user()->fullname; ?>" autofocus>
</td>
</tr> 

<tr><td>Telepon</td>
<td>
<div class="input-group">
                  <div class="input-group-prepend">
                    <small><span class="input-group-text"><b>+62</b></span></small>
                  </div>
<input type="text" class="form-control mb-2" id="telp" name="telp" value="<?= user()->telp; ?>" data-inputmask='"mask": "(999) 999-9999"' data-mask>
</div>
</td>
</tr> 

<tr><td>Gender</td>
<td>

<div class="row">
                    <div class="col-sm-12">
                      <!-- select -->
                      <div class="form-group">                       
                        <select class="form-control mb-2" id="jenkel" name="jenkel">
                          <option><?= user()->jenkel; ?></option>
                          <option>Pria</option>
                          <option>Wanita</option>                      
                        </select>
                      </div>
                    </div>                   
            </div>
</td>
</tr> 

<tr><td>Nama Toko</td>
<td>
<input type="text" class="form-control mb-2" id="nama_toko" name="nama_toko" value="<?= user()->nama_toko; ?>"   >
</td>
</tr> 

<tr><td>Email</td>
<td>
<input type="email" class="form-control mb-2" id="email" name="email" value="<?= user()->email; ?>"   >
</td>
</tr> 

<tr><td>Alamat</td>
<td>
<input type="textarea" class="form-control mb-2" id="alamat" name="alamat" value="<?= user()->alamat; ?>" >
</td>
</tr> 


<tr><td colspan="3"><br /><b>ACCOUNT BANK</b></td></tr>

<tr><td>Nama Bank</td>
<td>
<div class="form-group">

                  <select input type="text" class="form-control select2bs4" style="width: 100%;" id="mabank" name="mabank" value="<?= user()->mabank; ?>" >
                    <option><?= user()->mabank; ?></option>
                    <option>BRI</option>
                    <option>BCA</option>
                    <option>MANDIRI</option>
                    <option>BSI</option>
                    <option>BNI</option>
                    
                  </select>
                </div>

</td>
</tr> 

<tr><td>Nomor Rekening</td>
<td>
<input type="integer" class="form-control mb-2" id="norek" name="norek" value="<?= user()->norek; ?>" >
</td>
</tr> 

<tr><td>Atas Nama</td>
<td>
<input type="text" class="form-control mb-2" id="an" name="an" value="<?= user()->an; ?>" >
</td>
</tr> 

</table>                    
      
  <p><p>
   <div class="modal-footer justify-content-around">
  <button type="submit" class="btn btn-warning">Simpan</button>
  <a href="/users" class="btn btn-secondary  pl-7">Cancel</a>
   </div>   
</form>     
              </div>
              </div>
              <!-- /.card -->          
      </div><!-- /.container-fluid -->
     
 

</div>
</div>
</div>


<?= $this-> include('template/footer'); ?>
<?= $this-> endSection(); ?>










