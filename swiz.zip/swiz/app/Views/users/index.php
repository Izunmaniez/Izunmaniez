<?= $this-> extend('template/index'); ?>

<?= $this-> section('content'); ?>

 <?= $this-> include('users/topbar'); ?>
 
 <?= $this-> include('users/sidebar'); ?>
 
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
<!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card card-solid">
        <div class="card-body">
          <div class="row">
          
            <div class="col-12 col-sm-6 mt-3">                                                 
            <!-- Widget: user widget style 1 -->          
            <div class="card card-widget widget-user">
              <!-- Add the bg color to the header using any of the bg-* classes -->
              <div class="widget-user-header text-light"
                   style="background: url('../img/bg.jpg') center center;">
                <h4 class="widget-user-desc text-right"><b>Mars</b> <i>Pelopor Market Place NAFTING System</i></h4>
                </div>
              <div class="widget-user-image">              
              <img class="user-image img-circle elevation-2 style="width:200px; height:200px;" src="/foto_profile/<?= user()->foto; ?>">                                
               </div>
               <p>
               <div class="card-footer text-info">                                                        
                <center>
                <b><?= user()->fullname; ?></b><br>
                <b><?= user()->username; ?></b><br>
                <small>Member since <?= user()->created_at; ?></small>
                <h6 class="widget-user-desc"><i>On Stage</i> : <b>WHITE</b></h6>            
                
               <p>
   <button type="button" class="btn btn-info mt-3" data-toggle="modal" data-target="#modal-xl">Lihat Profile</button>
   </p>
             </center>                
               </div> 
               <!-- /.footer -->  
               </div>
                  </div>         
               <!-- /.col -->                 
               
       <div class="modal fade" id="modal-xl">
        <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">My Profile</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
            
            <!-- Profile Image -->
            <div class="card card-info card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                  <img class="profile-user-img img-fluid img-circle bg-info"
                       src="<?= base_url('foto_profile/' .user()->foto); ?>"
                       alt="User profile picture">
           </div>
                <center>
                <h3 class="profile-username text-center text-info">
                <?= user()->fullname; ?></h3>
                <h4><?= user()->username; ?>  </h4>                             
                <small>Member since <?= user()->created_at; ?></small>
              <h6 class="widget-user-desc">Stage : 
              <span class="badge badge-info">WHITE</span></h6>
                </center>

                <ul class="list-group list-group-unbordered mb-3">
                 <li class="list-group-item">
                  <i class="fas fa-mobile-alt text-info mr-1"></i>
                    <b>Telepon</b> <a class="float-right"><?= user()->telp; ?></b></a>
                  </li>
                  <li class="list-group-item">
                  <i class="fas fa-envelope-open-text text-info mr-1"></i>
                    <b>Email</b> <a class="float-right"><?= user()->email; ?></b></a>
                  </li>
                  <li class="list-group-item">
                  <i class="fas fa-home text-info mr-1"></i>
                    <b>Pemilik Toko</b> <a class="float-right"><?= user()->nama_toko; ?></b></a>
                  </li>
                </ul>

                </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

            <!-- About Me Box -->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">More About Me</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <strong><i class="fas fa-user text-info mr-1"></i>Gender</strong>
                <a class="float-right">
                <?= user()->jenkel; ?>
                </a>               
                <hr>
                <strong><i class="fas fa-map-marker-alt text-info mr-1"></i>Alamat</strong>
                <a class="float-right"><?= user()->alamat; ?>
                </a>
                
                
               </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card-info-->
            
         <!-- Bank Account -->
            <div class="card card-info">
              <div class="card-header">
            <i class="fas fa-money-check-alt text-info mr-1"></i>
                <h3 class="card-title">Bank Account</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <strong><i class="fas fa-sort-numeric-up text-info mr-1"></i>Nomor Rekening</strong>
                <a class="float-right">
                <?= user()->norek; ?>
                </a>
                <hr>
                <strong><i class="fas fa-user text-info mr-1"></i> Pemilik Rekening</strong>
                <a class="float-right"><?= user()->an; ?></a>
                <hr>
                <strong><i class="fas fa-university text-info mr-1"></i> Nama Bank</strong>
                <a class="float-right">
                  <?= user()->mabank; ?>
                </a>               
                
               </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card-info-->
             
    <!-- Inviter Data -->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Your Inviter</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <strong><i class="fas fa-user text-info mr-1"></i>Nama Inviter</strong>
                <a class="float-right">
                <?= user()->inviter; ?>
                </a>
                <hr>
                <strong><i class="fas fa-mobile-alt text-info mr-1"></i>
                   Telp. Inviter</strong>
                <a class="float-right"><?= user()->telp_inviter; ?></a>             
                
               </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card-info-->
            
    <center>
   
    <button class="btn btn-info mb-3" data-dismiss="modal" aria-label="Close"><b>Cocok..?</b></button>
    <a href="/users/edit/<?= user()->id; ?>" class="btn btn-warning mb-3"><b>Edit?</b></a>
    </center>
            
            </div> 
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->
 
 
      
        <div class="col-12 col-sm-6 mt-3">  
           
              <a href="" class="info-box elevation-3">
              <span class="info-box-icon bg-info"><img src="/dashboard/harta.png"></i></span>
              <div class="info-box-content">
                <span class="info-box-text text-info"><h3>Data Bonus</h3></span>
                <span class="info-box-number">1,410</span>
                </div>               
             </a>  
             
            <a href="" class="info-box elevation-3">
              <span class="info-box-icon bg-info"><img src="/dashboard/keranjang.png"></i></span>
              <div class="info-box-content">
                <span class="info-box-text text-info"><h3>Data Belanja</h3></span>
                <span class="info-box-number">1,410</span>
              </div>           
            </a>   
            
              <a href="" class="info-box elevation-3">
              <span class="info-box-icon bg-info"><img src="/dashboard/sedekah.png"></i></span>
              <div class="info-box-content">
                <span class="info-box-text text-info"><h3>Data Sedekah</h3></span>
                <span class="info-box-number">1,410</span>
              </div>           
            </a>   
            
            <a href="/users/grup" class="info-box elevation-3">
              <span class="info-box-icon bg-info"><img src="/dashboard/grup.png"></i></span>
              <div class="info-box-content">
                <span class="info-box-text text-info"><h3>Data Grup</h3></span>
                <span class="info-box-number">1,410</span>
              </div>           
            </a>    
         </div>   
         
         
      
  <div class="col-12 col-sm-6 mt-3">
      
        <!-- Small boxes (Stat box) -->
        <div class="row">
        
        <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-light">
              <div class="inner">
                <a href="/toko/index"><img src="/dashboard/toko2.png"><br>Kelola<br>Toko Saya</a>
              </div>
              <a href="/toko/index" class="small-box-footer bg-info">Cekidot..<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-light">
              <div class="inner">
                <a href="#"><img src="/dashboard/toko1.png"><br>Toko<br>Referal Saya</a>
              </div>
             <a href="#" class="small-box-footer bg-info">Cekidot..<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->                                       

             
       <div class="col-12 col-sm-12 mt-3">  
           
              <a href="/" class="info-box bg-danger elevation-3">
              <div class="info-box-content">
                <span class="info-box-text text-light">
                <i>Ayo kita jelajahi</i>
                 <b style="font-size:29px;">MARS</b>                
                 </span>
                <span class="info-box-text text-light"><i>Go To Market And Share</i></span>
              </div>  
              
               <span class="col-4 text-center">
                      <img src="/img/undraw_rocket.svg">
                    </span>
                  </a>   
             
            <a class="info-box bg-danger elevation-3" data-toggle="modal" data-target="#community">
              <div class="info-box-content">
                <span class="info-box-text text-light"><h5><b>MARS</b> <i>ZOOMERS</i></h5></span>
                <span class="info-box-text text-light"><i>That's Our Nice Community</i></span>
              </div>  
               <span class="col-4 text-center">
                      <img src="/img/mz.png" alt="" class="img-circle img-fluid">
                    </span>
                  </a>   
          </div>               
         </div>
          </div>                                     
         
           
            
       <div class="col-12 col-sm-6">
         <div class="row mt-4">
            <div class="card card-info card-tabs">
              <div class="card-header p-1 pt-0">
                <ul class="nav nav-tabs" id="custom-tabs-one-tab" role="tablist">
                  <li class="nav-item">
                    <a class="nav-link active" id="custom-tabs-one-home-tab" data-toggle="pill" href="#custom-tabs-one-home" role="tab" aria-controls="custom-tabs-one-home" aria-selected="true"><b>Promosi Standar</b>                   </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="custom-tabs-one-profile-tab" data-toggle="pill" href="#custom-tabs-one-profile" role="tab" aria-controls="custom-tabs-one-profile" aria-selected="false"><b>Improve</b></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="custom-tabs-one-messages-tab" data-toggle="pill" href="#custom-tabs-one-messages" role="tab" aria-controls="custom-tabs-one-messages" aria-selected="false"></i><b>Edit</b></a>
                  </li>
                  
                </ul>
              </div>
              <div class="card-body">
                <div class="tab-content" id="custom-tabs-one-tabContent">
                  <div class="tab-pane fade show active" id="custom-tabs-one-home" role="tabpanel" aria-labelledby="custom-tabs-one-home-tab">
  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin malesuada lacus ullamcorper dui molestie, sit amet congue quam finibus. Etiam ultricies nunc non magna feugiat commodo. Etiam odio magna, mollis auctor felis vitae, ullamcorper ornare ligula. Proin pellentesque tincidunt nisi, vitae ullamcorper felis aliquam id. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin id orci eu lectus blandit suscipit. Phasellus porta, ante et varius ornare, sem enim sollicitudin eros, at commodo leo est vitae lacus. Etiam ut porta sem. Proin porttitor porta nisl, id tempor risus rhoncus quis. In in quam a nibh cursus pulvinar non consequat neque. Mauris lacus elit, condimentum ac condimentum at, semper vitae lectus. Cras lacinia erat eget sapien porta consectetur. 
  
  <p>
  <div class="col-12 mt-3">  
                  <a href="" class="info-box elevation-3">
              <span class="info-box-icon bg-info"><i class="fas fa-share text-light"></i></span>
              <div class="info-box-content">
                <span class="info-box-text text-info"><h3>Share Now!</h3></span>
                <span class="info-box-number">1,410</span>
              </div>           
            </a>                             
            </div>                   
              
                  </div>
                                                
                  <div class="tab-pane fade" id="custom-tabs-one-profile" role="tabpanel" aria-labelledby="custom-tabs-one-profile-tab">
                     Mauris tincidunt mi at erat gravida, eget tristique urna bibendum. Mauris pharetra purus ut ligula tempor, et vulputate metus facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Maecenas sollicitudin, nisi a luctus interdum, nisl ligula placerat mi, quis posuere purus ligula eu lectus. Donec nunc tellus, elementum sit amet ultricies at, posuere nec nunc. Nunc euismod pellentesque diam. 
                    
  <p>
  <div class="col-12 mt-3">  
                  <a href="" class="info-box elevation-3">
              <span class="info-box-icon bg-info"><i class="fas fa-share text-light"></i></span>
              <div class="info-box-content">
                <span class="info-box-text text-info"><h3>Share Now!</h3></span>
                <span class="info-box-number">1,410</span>
              </div>           
            </a>                             
            </div>              
                     
                  </div>  
                   <div class="tab-pane fade" id="custom-tabs-one-messages" role="tabpanel" aria-labelledby="custom-tabs-one-messages-tab">
                     Morbi turpis dolor, vulputate vitae felis non, tincidunt congue mauris. Phasellus volutpat augue id mi placerat mollis. Vivamus faucibus eu massa eget condimentum. Fusce nec hendrerit sem, ac tristique nulla. Integer vestibulum orci odio. Cras nec augue ipsum. Suspendisse ut velit condimentum, mattis urna a, malesuada nunc. Curabitur eleifend facilisis velit finibus tristique. Nam vulputate, eros non luctus efficitur, ipsum odio volutpat massa, sit amet sollicitudin est libero sed ipsum. Nulla lacinia, ex vitae gravida fermentum, lectus ipsum gravida arcu, id fermentum metus arcu vel metus. Curabitur eget sem eu risus tincidunt eleifend ac ornare magna. 
    
  <p>
  <div class="col-12 mt-3">  
                  <a href="" class="info-box elevation-3">
              <span class="info-box-icon bg-info"><i class="fas fa-save text-light"></i></span>
              <div class="info-box-content">
                <span class="info-box-text text-info"><h3>Simpan</h3></span>
                
              </div>           
            </a>                             
            </div>                              
                     
                  </div>       
                </div>
              </div>
              <!-- /.card -->
            </div>
          </div>  
                 
                                   
      </div>
      </div>
         
      
                   <!-- Contact Admin -->
      <div class="col-12">
     <center><button class="btn btn-success mt-5 mb-3">Hubungi Admin Jika diperlukan</button></center>
        <div class="row">
        
          <div class="col-md-4 col-sm-8 ">
            <div class="info-box">
              <span class="info-box-icon"><img class="img-thumbnail" src="/img/wa.png"></i></span>
              <div class="info-box-content bg-success">
                <span class="info-box-text">Admin</span>
                <span class="info-box-number">Pertokoan</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          
          <div class="col-md-4 col-sm-8 ">
            <div class="info-box">
              <span class="info-box-icon"><img class="img-thumbnail" src="/img/wa.png"></i></span>
              <div class="info-box-content bg-success">
                <span class="info-box-text">Admin</span>
                <span class="info-box-number">Pengiriman</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          
          <div class="col-md-4 col-sm-8 ">
            <div class="info-box">
              <span class="info-box-icon"><img class="img-thumbnail" src="/img/wa.png"></i></span>
              <div class="info-box-content bg-success">
                <span class="info-box-text">Admin</span>
                <span class="info-box-number">Keuangan</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          </div>
          <!-- /.row -->
          
          <div class="row">
          <div class="col-md-4 col-sm-8 ">
            <div class="info-box">
              <span class="info-box-icon"><img class="img-thumbnail" src="/img/wa.png"></span>
              <div class="info-box-content bg-success">
                <span class="info-box-text">Admin</span>
                <span class="info-box-number">Membership</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          
          <div class="col-md-4 col-sm-8 ">
          <a href="https://api.whatsapp.com/send?phone=62 81370769831&text=Hallo..%20Assalamu'alaikum%20Abangnda%20Kuswito.%20Saya %20ingin%20bicara%20tentang%20Hamdalah%20DJOS😊🙏">

            <div class="info-box">
              <span class="info-box-icon bg-success"><img class="img-thumbnail" src="/img/wa.png"></i></span>
              <div class="info-box-content bg-success">
                <span class="info-box-text">Admin</span>
                <span class="info-box-number">DJOS</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
            </a>
          </div>
          <!-- /.col -->
          
          <div class="col-md-4 col-sm-8">
            <div class="info-box">
              <span class="info-box-icon"><img class="img-thumbnail" src="/img/wa.png"></i></span>
              <div class="info-box-content bg-success">
                <span class="info-box-text">Kotak</span>
                <span class="info-box-number">Saran</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          
        </div>
        <!-- /.row --> 
        </div>
                                  

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
  
  <div class="container">
  <div class="modal fade" id="community">
    <div class="modal-dialog">
      <div class="modal-content">      
        <div class="modal-body">


<div class="vmvm">        
<div class="vmvm-item"> 
  <a class="btn btn-success dropdown-toggle" href="#" role="button" id="visi" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Visi </a>

  <div class="dropdown-menu" style="background-color:#DAF7A6; text-align:center; padding:5px 9px;" aria-labelledby="visi">
    <h3>VISI</h3>
Menjadi komunitasnya Para Leader yang Berakhlakul Karimah, Dermawan dan memiliki penghasilan minimal Satu Juta Rupiah per hari.

<p><p><p><p>

<div class="btn btn-success">Aye..?!!😀</div><p><p>
</div>
</div>




<div class="vmvm-item"> 
  <a class="btn btn-success dropdown-toggle" href="#" role="button" id="misi" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Misi </a>

    <div class="dropdown-menu" style="background-color:#DAF7A6; text-align:center; padding:5px 9px;" aria-labelledby="misi">
    <h3>MISI</h3>
1. Menjalankan semua program/platform HHC dengan didasari rasa penuh syukur dan suka-cita.<br>

2. Beradaptasi terhadap segala perkembangan teknologi dan Berinovasi tanpa batas.


<p><p><p><p>

<div class="btn btn-success">Aye..?!!😀</div><p><p>
</div>
</div>


<div class="vmvm-item"> 
  <a class="btn btn-success dropdown-toggle" href="#" role="button" id="value" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Value</a>

    <div class="dropdown-menu" style="background-color:#DAF7A6; text-align:center; padding:5px 9px;" aria-labelledby="value">
    <h3>VALUE</h3>
<b>7 PRINCESS  HHC</b> (PRINCiple of SuccESS)<br>
1. Teguhkan Impian dan Fokus.<br>
2. Bersyukur, bersuka-cita dan tidak mengeluh.<br>
3. Rutin bersedekah.<br>
4. Konsumsi yang halal.<br>
5. Tulus, Rendah hati, Respek dan Empati.<br>
6. Menjaga Integritas.<br>
7. Menjadi Leader yang menginspirasi.


<p><p><p><p>

<div class="btn btn-success">Aye..?!!😀</div><p><p>
</div>
</div>


<div class="vmvm-item"> 
  <a class="btn btn-success dropdown-toggle" href="#" role="button" id="motto" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Motto</a>

    <div class="dropdown-menu" style="background-color:#DAF7A6; text-align:center; padding:5px 9px;" aria-labelledby="motto">
    <h3>MOTTO</h3>
Kami Sangat Bersyukur!<br>
Kami Sangat Bahagia!<br>
Kami Sangat Sukses!

<p><p><p><p>

<div class="btn btn-success">Aye..?!!😀</div><p><p>
</div>
</div>



</div>  






           
 <h2 class="platform-judul-item">HHC PLATFORM</h2>

<div class="container-platform">
    
<a href="/pages/djos"class="platform-item"><img src="/content/platform_item.png"><br>DJOS</a>

<a href="#"class="platform-item"><img src="/content/platform_item.png"><br>NEWS</a>

<a href="/watch"class="platform-item"><img src="/content/platform_item.png"><br>WATCH</a>

<a href="/pages/charger"class="platform-item"><img src="/content/platform_item.png"><br>CHARGER</a>

<a href="/pages/mars"class="platform-item"><img src="/content/platform_item.png"><br>MARS</a>

<a href="#"class="platform-item" style="color:black"><img src="/content/platform_item.png"><br>BARLEB</a>

<a href="#"class="platform-item"style="color:black"><img src="/content/platform_item.png"><br>COOPERATION</a>

<a href="#"class="platform-item"style="color:black"><img src="/content/platform_item.png"><br>CURRENCY</a>

<a href="#"class="platform-item"style="color:black"><img src="/content/platform_item.png"><br>TRADE</style></a>        

</div>
    
<p><p><p><p>
        
          <a href="" class="btn btn-info">Tentang Kami</a>
        
       
          <button type="button" class="btn btn-success" data-dismiss="modal">Aye..?!!😀</button>
       
       
      </div>
    </div>
  </div>
</div>
</div>
  
 <?= $this-> include('template/footer'); ?>
  
 <?= $this-> endSection(); ?>
  
  
  
  