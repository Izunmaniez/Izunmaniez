<?= $this-> extend('layout/template_general'); ?>

<?= $this-> section('content'); ?>

<?= $this->include('layout/navbar_djos');?>

<p class="card header">
    <center><h4>Dokumentasi DJOS</h4></center>
</p>


    
      <form action="" method="post" enctype="multipart/form-data">
 <?= csrf_field(); ?> 
 

   <section class="content">
      <!-- Default box -->
      <div class="card card-solid">
      
        <div class="card-body bg-warning">      
     
          <div class="row">
          
      <?php foreach ($djosdok as $dok) : ?>  
          
            <div class="col-12 col-sm-6 mb-5">          
             <center> <h3 class="d-inline-block "><?=$dok['judul']; ?></h3></center>
              <div class="col-12">
                <img src="/dok_djos/<?=$dok['foto']; ?>" class="product-image" style="border-radius:7px;" alt="Dok. DJOS">
              </div>
              <small class="float-right"><i>posted : <?=$dok['created_at']; ?></i></small>
              <h6 class="d-inline-block"><?=$dok['ket']; ?></h6>
             </div>
             
    <?php endforeach; ?>   
</form>                              
            </div>
          </div>
        </div>    
    </section>   
     
              </div>
           </div>               
        
        
        
        
      
            


<?= $this-> endSection(); ?>