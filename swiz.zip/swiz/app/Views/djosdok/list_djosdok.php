<?= $this-> extend('template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this->include('template/topbar');?>

<?= $this->include('template/sidebar');?>

<div class="container">
    <div class="row">
        <div class="col">
 <p>   

 <?php if(session()->getFlashdata('pesan')) : ?>

<div class="alert alert-success" role="alert">

<?= session()->getFlashdata('pesan');?>

</div>
  
<?php endif; ?>
<form action="" method="post">
 <?= csrf_field(); ?> 
 

<a href="/djos" class="btn btn-secondary btn-md float-right mr-1"><i class="fas fa-angle-double-left"></i> Back</a>
                  
<a class="btn btn-primary mb-4" href="/djosdok/tambah_djosdok"><i class="fas fa-plus"></i> Tambah Dokumentasi</a>

 <hr>

 <?php foreach ($djosdok as $dok) : ?>
 
 <div class="card-body p-0">
 <div class="products-list product-list-in-card pl-2 pr-2">                  
  <div class="item">
                    <div class="product-img">
                      <img src="/dok_djos/<?=$dok['foto']; ?>" >
                    </div>
                    <div class="product-info">
                    <span class="product-description">
                        <h6>Judul : <?=$dok['judul']; ?></h6>
                      </span>
                     
                     <small> <i>uploaded : <span>
                         <?=$dok['created_at']; ?>
                      </span></i></small>   
                                                  
                      
                    </div>
                  </div>
                  </div>
                  </div>
                       

<p>
<table>
<tr>
<td class="project-actions text-right">   
<a href="/djosdok/edit/<?= $dok['id']; ?> " class="btn btn-warning btn-sm">
<i class="fas fa-pencil-alt"></i> Edit </a>
</td>

<td>
<form action="/djosdok/delete/<?= $dok['id']; ?>" method="post">
<?= csrf_field(); ?>
<input type="hidden" name="_method" value="delete">

 <button type="submit" class="btn btn-danger btn-sm ml-2" onclick="return confirm('Yakin ingin menghapus data ini?');">
   <i class="fas fa-trash"></i> Delete</button>
                          
</form>
</td>
</tr>        
</table>                  
 <hr>
 <hr>
  
 
   <?php endforeach; ?>
       
    </form>
  
   </div>
    </div>
</div> 

<?= $this->include('template/footer');?>

<?= $this-> endSection(); ?>


