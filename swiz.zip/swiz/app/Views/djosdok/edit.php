<?= $this-> extend('template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this-> include('template/topbar'); ?>

<?= $this-> include('template/sidebar'); ?>

<div class="container">
   <div class="row">   
      <div class="col">
      
<p>   

<h3>Edit Dokumentasi</h3>


<form action="/djosdok/update/<?= $djosdok['id']; ?>" method="post" enctype="multipart/form-data">

<?= csrf_field(); ?>

<input type="hidden" name="fotoLama" value="<?= $djosdok['foto']; ?>" >            
 
  <div class="form-grup row">
    <label for="judul" class="col-sm-2 col-form-label">Judul</label>
    <div class="col-sm-10">
<input type="text" class="form-control" id="judul" name="judul" value="<?= $djosdok['judul']; ?>" >            
</div>
</div>
<p>

<div class="form-group row">  
   <label for="foto" class="col-sm-2 col-form-label">Foto</label>  
        <div class="col-sm-2 ">
           <img src="/dok_djos/<?= $djosdok['foto']; ?>" class="img-thumbnail img-preview">
        </div>   
<div class="col-sm-8">   
  <div class="custom-file">                         
   <input type="file" class="custom-file-input <?= ($validation->hasError('foto')) ? 'is-invalid' : ''; ?>" id="foto" name="foto" onchange="previewImg()">
  <div class="invalid-feedback">
     <?= $validation->getError('foto'); ?>
  </div>  
<label class="custom-file-label" for="foto"><?= $djosdok['foto']; ?></label>
                           </div>
                        </div>  
                    </div>
<p>

<div class="form-grup row">  
<label for="ket" class="col-sm-2 col-form-label">Deskripsi Foto</label>
 <div class="col-sm-10">        
      
<textarea type="text" class="form-control" rows="3" id="ket" name="ket"><?= $djosdok['ket']; ?></textarea>
    </div>
</div>

<p>
  <p>

<a href="/djosdok/list_djosdok" class="btn btn-secondary btn-md float-right mr-1">Back</a>
                  
  <button type="submit" class="btn btn-warning">Simpan</button>
 
</form>

</p>

</div>
</div>
</div>

<?= $this-> include('template/footer'); ?>

<?= $this-> endSection(); ?>
