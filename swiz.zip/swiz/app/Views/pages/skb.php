<?= $this-> extend('layout/template_general'); ?>


<?= $this-> section('content'); ?>


     
        </div>
    </div>
</div>
    
<?= $this-> endSection(); ?>
