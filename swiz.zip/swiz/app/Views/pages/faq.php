<?= $this-> extend('layout/template_general'); ?>




<?= $this-> section('content'); ?>

<?= $this->include('layout/navbar_faq');?>


<div class="col">

<br>
<nav class="navbar navbar-expand-lg navbar-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Daftar Istilah</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#hp" aria-controls="hp" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="hp">
      <div class="navbar-nav">
            
        <a class="nav-link active" aria-current="page" href="#"><b>HP </b>itu apa ya?        
  <button class="btn btn-success btn-md float-right" data-toggle="modal" data-target="#faq1">
    <b>Jawaban</b>
  </button>
 
  <div class="modal fade" id="faq1">
    <div class="modal-dialog">
      <div class="modal-content">
        
        <div class="modal-body">
        HP adalah singkatan dari <b>Hamdalah Poin</b><br>
        lebih jelas tentang HP silahkan <a href="/pages/hp">klik disini</a>
        </div>
  
        <div class="modal-footer">
          <button type="button" class="btn btn-success" data-dismiss="modal">Aye..?!!😀🤣😎</button>
        </div>      
      </div>
    </div>
  </div>
</a>

        <a class="nav-link" href="#"><b>pH </b>itu apa ya?

  <button class="btn btn-success btn-md float-right " data-toggle="modal" data-target="#faq2">
    <b>Jawaban</b>
  </button>

  <div class="modal fade" id="faq2">
    <div class="modal-dialog">
      <div class="modal-content">
        
        <div class="modal-body">
        pH adalah singkatan dari <b>poin Hamdalah.</b><br>
        atau bisa juga dikatakan "fee marketing" yang diberikan oleh penjual produk di HP secara sukarela. pH tersebut, 75% nya akan dikembalikan ke Member Hamdalah Community (HHC) berbentuk Bonus-bonus & Reward sesuai Marketing Plan HHC.</div>
  
        <div class="modal-footer">
          <button type="button" class="btn btn-success" data-dismiss="modal">Aye..?!!😀🤣😎</button>
        </div>       
      </div>
    </div>
  </div>
  </a>       
  
      </div>
    </div>
  </div>
</nav>
  

<p>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Pendaftaran</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#djos" aria-controls="djos" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="djos">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="#">Cara daftarnya gimana?

  
  <button class="btn btn-success btn-md float-right" data-toggle="modal" data-target="#faq101">
    <b>Jawaban</b>
  </button>
 
  <div class="modal fade" id="faq101">
    <div class="modal-dialog">
      <div class="modal-content">
        
        <div class="modal-body">
        Gampang! Klik tombol <b>Daftar Gratisss...</b> dipojok kanan atas halaman, lalu isi semua kolomnya dan klik tombol <b>Registrasi</b>.
        </div>
  
        <div class="modal-footer">
          <button type="button" class="btn btn-success" data-dismiss="modal">Aye..?!!😀🤣😎</button>
        </div>      
      </div>
    </div>
  </div>
</a>

        <a class="nav-link" href="#">Kalo udah daftar, trus? ngapain?

  <button class="btn btn-success btn-md float-right" data-toggle="modal" data-target="#faq102">
    <b>Jawaban</b>
  </button>

  <div class="modal fade" id="faq102" style="z-index:9999;">
    <div class="modal-dialog">
      <div class="modal-content">
        
        <div class="modal-body">   
        
        Ya Terserah.... hehe..<br>
        1. Ada cashback dari setiap perbelanjaan Anda di HP sesuai Marketing Plan HHC.<br>
        2. Anda bisa jual produk yang anda punya di HP.<br>
        3. Anda juga bisa tak perlu jual produk tapi hanya mempromosikan Hamdalah Poin kepada
        sebanyak-banyaknya orang secara online maupun offline. Setiap orang yang bergabung
        melalui rekomendasi Anda, maka selamanya setiap perbelanjaan mereka di HP akan menjadi
        bonus-bonus sesuai Marketing Plan HP.<br>
        4. Mau nimrung di bidang sosial HHC? Anda bisa berkontribusi di
        <a href="/pages/djos/hamdalah_djos">Hamdalah DJOS,</a>
        <a href="/pages/hamdalah_charger">Hamdalah Charger,</a>
        <a href="/pages/hamdalah_watch">Hamdalah Watch,</a> dan
        <a href="/pages/hamdalah_news">Hamdalah News.</a><br>
        5. Atau..setelah mendaftar tapi nggak ngapa-ngapain juga nggak papa kok..hehe...
        
        </div>
  
        <div class="modal-footer">
          <button type="button" class="btn btn-success" data-dismiss="modal">Aye..?!!😀🤣😎</button>
        </div>       
      </div>
    </div>
  </div>
  </a>       
  
      </div>
    </div>
  </div>
</nav>
  
      </div>
  
     
<?= $this-> endSection(); ?>
