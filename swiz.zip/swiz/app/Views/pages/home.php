<?= $this-> extend('layout/template_index'); ?>


<?= $this-> section('content'); ?>

<div class="container">
          
<marquee behavior=”scroll” direction=”right” class="running-text"><b>Mars</b> ~ Market Place Nafting System ~ Daftar Gratis ~ Gratis Toko Online ~ Membangun Aset hanya dengan share (bagikan) link website Hamdalah Poin ~ Dapatkan berbagai macam Bonus dan Reward dari perbelanjaan pribadimu dan temen-temenmu, juga dari hasil jualan toko online temen-temen rekomendasimu.</marquee>
    
    
  
         
<div class="container-home">

<a href="https://api.whatsapp.com/send?phone=62 85275305301&text=Hallo..%20Admin%20Saya %20ingin%20bicara%20tentang%20Sewa%20Lokasi Strategis LS01 di *Mars*%20😊🙏" class="product"><img src="/produk/disewakan.png"><br>
<br>LS01
<h5>DISEWAKAN</h5></a>
    
<a href="#" class="product"><img src="/produk/swiz30ml.jpg"><br>
Parfum SWIZ<br>30 ML<br>Rp. 60.000,-</a>

<a href="https://api.whatsapp.com/send?phone=62 85275305301&text=Hallo..%20Admin%20Saya %20ingin%20bicara%20tentang%20Sewa%20Lokasi Strategis LS03 di *Mars*%20😊🙏" class="product"><img src="/produk/disewakan.png"><br>
<br>LS03
<h5>DISEWAKAN</h5></a>

<a href="#" class="product"><img src="/produk/sari_kedelai.jpg"><br>
Sari Kedelai - Satu Tiga<br>100 gr<br>Rp. 20.000,-</a>

<a href="#" class="product"><img src="/produk/beras1kg.jpg"><br>
Beras Kampung - Kemasan 1 kg<br>Rp. 12.000,-</a>

<a href="#" class="product"><img src="/produk/minyak_idaman.jpg"><br>
Minyak Kelapa Hijau<br>30 ML<br>Rp. 50.000,-</a>

<a href="#" class="product"><img src="/produk/waiteu.jpg"><br>
WAITEU Collagen<br>150 gr<br>Rp. 175.000,-</a>

<a href="#" class="product"><img src="/produk/kaos_lilik.jpg"><br>
Kaos Dakwah - Lilik Cloth<br>Rp. 90.000,-</a>

<a href="#" class="product"><img src="/produk/kamal_feed.jpg"><br>
Pakan Ayam - Kamal Feed<br>50 Kg<br>Rp. 60.000,-</a>

<a href="#" class="product"><img src="/produk/sabun513.jpg"><br>
Sabun Cuci Piring - 513<br>250 ml<br>Rp. 7.000,-</a>

<a href="#" class="product"><img src="/produk/jus_lemon.jpg"><br>
Juice Lemon<br>250 ml<br>Rp. 25.000,-</a>

<a href="#" class="product"><img src="/produk/kutus.jpg"><br>
Minyak Kutus-Kutus<br>30 ML<br>Rp. 60.000,-</a>

<a href="https://api.whatsapp.com/send?phone=62 85275305301&text=Hallo..%20RMD%20Saya %20ingin%20membeli%20Kopi%20RMD" class="product"><img src="/produk/kopirmd.png"><br>
<small>PT. Remedi Global Indonesia</small><br>
Kopi RMD<br>1 box<br>Rp. 335.000,-</a>

<a href="https://api.whatsapp.com/send?phone=62 85275305301&text=Hallo..%20RMD%20Saya %20ingin%20membeli%20Susu%20RMD" class="product"><img src="/produk/susurmd.png"><br>
<small>PT. Remedi Global Indonesia</small><br>
Susu RMD<br>1 box<br>Rp. 200.000,-</a>

</div>



<hr><hr><hr>






</div>
<?= $this-> endSection(); ?>
