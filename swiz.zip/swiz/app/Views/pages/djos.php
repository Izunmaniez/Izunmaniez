<?= $this-> extend('layout/template_general'); ?>


<?= $this-> section('content'); ?>

<?= $this->include('layout/navbar_djos');?>

<?= $this->include('layout/slider_djos');?>


<div class="container">

        
         <h3>DJOS</h3>   
<h5><i>DONASI JARIYAH ONLINE SYSTEM</i></h5>

<div class="rekening-djos">Bank BRI<br><b>032301001983306</b><br>an. <b>HHC</b></div>

<div class="bar-djos">
<a class="djos-item" href="/djos/publish">Tabel Donasi</a>
<a class="djos-item" href="/djosdok">Dokumentasi</a>


<a class="djos-item" data-toggle="modal" data-target="#team_profile">Team Profile</a>
  <div class="modal fade" id="team_profile" style="z-index:9999;">
    <div class="modal-dialog">
      <div class="modal-content">      
        <div class="modal-body">
        
<div class="container-team-profile" style="width:100%;">

<h2>Dewan Pengurus Pusat</h2>
<h4>DJOS - HHC</h4>

<div class="penasehat-djos" style="background-color:white;">
<div class="personil-djos"><img src="/team_djos/miswan.png">
  <h6>Syech Miswan Alsambahuta</h6>
  Penasehat
  </div>
</div>


<div class="pembina-djos" style="background-color:white;" >
<div class="personil-djos"><img src="/team_djos/suriono.png">
  <h6>Suriono</h6>
  Pembina</div>
  
<div class="personil-djos"><img src="/team_djos/suprapto.png">
  <h6>Suprapto</h6>
  Pembina</div>
  
<div class="personil-djos"><img src="/team_djos/aris.png">
  <h6>MH Siahaan</h6>Pembina</div>
 
<div class="personil-djos"><img src="/team_djos/muliadi.png">
  <h6>Muliadi</h6>Pembina</div>
</div>

<div class="penasehat-djos" style="background-color:white;">
<div class="personil-djos"><img src="/team_djos/kuswito.png">
  <h6>Kuswito MH. FH</h6>
  Ketua
  </div>
</div>

<div class="pembina-djos" style="background-color:white;" >
<div class="personil-djos"><img src="/team_djos/ridho.png">
  <h6>Ridho A.G.S</h6>Sekretaris</div>

<div class="personil-djos"><img src="/team_djos/dedy.png">
  <h6>Pranoto Dedy</h6>Bendahara</div>
</div>


<p>
<h4>CORE VOLUNTEERS</h4>
<h5>(CV/Relawan Inti)</h5>
CV siap sedia melayani proses dan informasi donasi dan penyalurannya  kapanpun & dimanapun.


<div class="volunteer-djos" style="background-color:#667C26;">
  
<div class="personil-djos"><img src="/team_djos/adiono.png">
  <h6>Adiono</h6>Asahan-Sumut</div>
  
<div class="personil-djos"><img src="/team_djos/mardany.png">
  <h6>Mardany</h6>Rantau Parapat - Sumut</div>

<div class="personil-djos"><img src="/team_djos/acuk.png">
  <h6>Kamaluddin</h6>Asahan-Sumut</div>
  
<div class="personil-djos"><img src="/team_djos/sarwo.png">
  <h6>Sarwo Edy Rambe</h6>Asahan - Sumut</div>
  
<div class="personil-djos"><img src="/team_djos/ali.png">
  <h6>Ali Jaya Wiguna</h6>Asahan-Sumut</div>
  
<div class="personil-djos"><img src="/team_djos/alif.png">
  <h6>Alif CDF</h6>Asahan-Sumut</div>
  
<div class="personil-djos"><img src="/team_djos/hendri.png">
  <h6>Suhendri</h6>Asahan-Sumut</div>
  
<div class="personil-djos"><img src="/team_djos/obenk.png">
  <h6>Zainal Aripin</h6>Asahan-Sumut</div>
  
<div class="personil-djos"><img src="/team_djos/lilik.png">
  <h6>Ponidi Lilik</h6>Asahan - Sumut</div>
  
<div class="personil-djos"><img src="/team_djos/hendro.png">
  <h6>Hendro</h6>Asahan - Sumut</div>

<div class="personil-djos"><img src="/team_djos/iwan.png">
  <h6>Iwan Surbakti</h6>Asahan - Sumut</div>

<div class="personil-djos"><img src="/team_djos/nazir.png">
  <h6>Mhd. Nazir</h6>Asahan - Sumut</div>
  
<div class="personil-djos"><img src="/team_djos/hasan.png">
  <h6>Hasan Basri</h6>Asahan - Sumut</div>
  
<div class="personil-djos"><img src="/team_djos/didik.png">
  <h6>Didiek Pramudytha</h6>Asahan - Sumut</div>

<div class="personil-djos"><img src="/team_djos/ipin.png">
  <h6>M. Arifin Srg</h6>Asahan - Sumut</div>

</div>
<hr>
<div class="pembina-djos" style="background-color:white;" >
<div class="personil-djos"><img src="/team_djos/izun.png">
  <h6>Nur Alfaizun</h6>Lead Developer</div>

<div class="personil-djos"><img src="/dashboard/default_profile.png">
  <h6>Indri Saputra Mrp.</h6>Web Designer</div>
</div>

</div>



        <div class="modal-footer">
          <button type="button" class="btn btn-success" data-dismiss="modal">Aye..😀😄</button>
        </div>      
      </div>
    </div>
  </div>
</div>


<a class="djos-item" data-toggle="modal" data-target="#sumber_donasi">Potensi Sumber Donasi</a>
  <div class="modal fade" id="sumber_donasi" style="z-index:9999;">
    <div class="modal-dialog">
      <div class="modal-content">      
        <div class="modal-body">


<h5>Potensi sumber dana DJOS berasal dari :</h5>

1. Masyarakat Umum
<p>

2. Member HHC
<br> Fitur donasi juga akan disediakan didalam setiap akun/walet member.
</p>

3. Monetisasi chanel youtube 
<br>
- <a href="https://www.youtube.com/channel/UChczBosBiGwtDBJxDgAfGXw">Hamdalah Watch.</a>
<br>
Dengan hanya nonton, like, comment & share video di chanel youtube <a href="https://www.youtube.com/channel/UChczBosBiGwtDBJxDgAfGXw">Hamdalah Watch</a>
berpotensi menghasilkan nilai ibadah ubudiyah bagi Anda karena hasilnya 100% akan disalurkan ke Divisi Sosial HHC (DJOS) dan <a href="/pages/charger">Charger HHC<a/>(Divisi Pembanguanan Karakter). Kami juga membuka peluang ubudiyah bagi member yang memiliki skill sebagai content creator video yang bernilai positif dan mendukung Visi, Misi & Value <a href="/pages/community">HHC</a> untuk turut berkontribusi mengembangkan chanel youtube <a href="https://www.youtube.com/channel/UChczBosBiGwtDBJxDgAfGXw">Hamdalah Watch.</a></p>
    
4. Alokasi Dana Sosial dari Unit Usaha HHC <a href="/pages/about">(Mars)</a>
</p>

5. Instansi/Perusahaan Lainnya
 </p>
    
6. Instansi Pemerintah.
<p><p>

Demi menjaga integritas kita bersama, informasi saldo, sumber dana dan penyalurannya akan dipubikasikan secara transparan di halaman situs <a href="/djos">ini.</a>

        <div class="modal-footer">
          <button type="button" class="btn btn-success" data-dismiss="modal">Aye..?!!</button>
        </div>      
      </div>
    </div>
  </div>
</div>
    




<a class="djos-item" href="/users">Cek Bonus & Donasi Saya</a>

</div>     
      
</div>



    
    




    
<?= $this-> endSection(); ?>
