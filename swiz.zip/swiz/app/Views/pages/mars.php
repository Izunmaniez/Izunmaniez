<?= $this-> extend('layout/template_general'); ?>


<?= $this-> section('content'); ?>

<?= $this->include('layout/navbar_mars');?>


<div class="container">
            

<img src="/img/mars_green.png" alt="mars" width="30%">
<p>
<b>Go To Market And Get To Share.</b> Adalah Pusat dari segala aktifitas promosi toko online  dengan konsep NAFTING SYSTEM (Network Affiliate Marketing). Seperti ketika Anda menjalankan bisnis Afiliasi pada umumnya, Anda hanya mempromosikan produk-produk dari suatu perusahaan. Jika ada yang closing (membeli) maka perusahaan yang mengemas dan mengirim produknya. Lalu Anda akan memperoleh keuntungan berupa fee/bonus dan atau reward. Bedanya di Mars dengan konsep Nafting systemnya, Anda memiliki fasilitas membangun tim (network/jaringan) hanya dengan nge_share (membagikan) <b><i>link website Mars</b></i> yang sudah tertanam secara otomatis jika Anda sudah mendaftar secara GRATIS sebagai Mars Zoomer.<p>

<h4>Toko Online nya UMKM Indonesia</h4>



Produk-produk yang ada di Mars akan didominasi oleh produk-produk UMKM Indonesia. Banyak pengusaha UMKM Indonesia memiliki kemampuan dan kreatifitas menciptakan karya-karya produk asli Indonesia namun masih banyak juga yang belum mampu mengikuti trend atau pola pemasaran yang relevan di era sekarang ini (Era Industri 4.0).<br>
<u>Laris Manis..</u>
Di Mars,
barang/jasa yang Anda jual otomatis akan ikut terpromosikan ke semua penjuru dunia seiring berkembangnya Mars Zoomer dengan konsep Multiply (Consumer get Consumer/virus system/zombie system). Setiap dari satu orang konsumen sangat berpotensi memiliki peran sekaligus sebagai Promoter yang akan cepat berkembang menjadi ratusan bahkan ribuan promoter lainnya di barisan kedua. Dari barisan kedua masing-masing berpotensi untuk berkembang membawa ratusan bahkan ribuan promoter berikutnya di barisan ketiga. Begitu seterusnya tak terhentikan dan tak terbatas. Jadi pastikan produk/jasa Anda sudah ada di Market Place Mars dengan segala kesiapan Anda dalam hal memberikan kualitas produk dan pelayanan terbaik terhadap para konsumen yang sekaligus berperan sebagai Promoter (Mars Zoomer).
<p>



<h4>Membangun Aset</h4>

<i>Mengubah belanja kebutuhan harian Anda menjadi Sumber Penghasilan Pasif Anda.</i>
<br>
Semua member memiliki hak yang sama. Bukan hanya sebagai Konsumen, Kita semua berhak untuk berperan sebagai Penjual dan berkarir sebagai Market Zoomer (Para Pembesar Pasar) /Network Affiliate Marketer.<br>

Disatu sisi para pelaku UMKM sangat terbantu dalam hal pemasarannya, disisi lain para Network Affiliate Marketer (Penggiat Bisnis Jaringan) akan sangat mudah sekali bisnisnya diterima oleh masyarakat (prospek) dalam proses perekrutannya. Selama ini pebisnis Network Marketing dan atau Affiliate Marketing hanya bisa memasarkan produk-produk khusus (ekslusif/terbatas) yang hanya disediakan oleh produsen tertentu, yang berefek konsistensi harus memberikan edukasi khusus untuk calon customer dan downline-downlinenya, dan itu memakan energi yang cukup melelahkan. Kini dengan hadirnya Mars dengan konsep NAFTING System, mereka akan merasa sangat termanjakan dalam menjalankan bisnis membangun asetnya mereka. Karena semua produk kebutuhan harian dengan varian yang tak terbatas, harga produk bersaing dipasar umum, dan itu semua mengandung omset pM (poin Mars). Hal-hal tersebut adalah Impian para Network Builder selama ini yang telah menjadi nyata. Mereka tidak perlu melakukan penjualan produk secara langsung ke costumer, cukup hanya 'share' link Mars, dan jika para customer membeli barang/jasa yang ada di Market Place Mars, bukan mereka yang kirim, tapi si penjual (seller), lalu bonus otomatis masuk kedalam akun/walet mereka. Secara logika umum siapa sih orang yang tidak ingin turut berbisnis membangun jaringan customer di Mars?. Semua Orang Pasti MAU!

<p>
<h4>Marketing Plan</h4>
Marketing Plan Mars sengaja di design begitu sederhana, dinamis namun kokoh, adil, transparan, anti colaps, dan sangat pro Konsumen/User. Ini luar biasa dan benar-benar memberikan kenyamanan dan kesenangan bagi semua pihak yang yang bergabung dengan 
<b><a href="/">
Mars Zoomer (MZ Community)</a></b>
<br>
<p>

<h6 style="color:coral"><u>1. Bonus JAPRI (belanJA PRIbadi)/Cashback : 5% - 15%</u></h6>
Anda memperoleh 5%  s/d 15% pM (poin Mars) setiap Anda melakukan belanJA PRIbadi di Mars. Bahkan ada <b><a href="/">
Special Produk</a></b> yang secara fantastis memberikan <b>Cashback 10% dari harga produk secara berulang</b> setiap bulan selama 7 bulan, 10 bulan & 15 bulan (Melebihi nilai uang belanja Anda).
<p>
<h6 style="color:coral"><u>2. Bonus Promosi 5% - 15%</u></h6>
Anda memperoleh 5%  s/d 15% pM (poin Mars) jika dari setiap perbelanjaan orang yang Anda ajak bergabung di MZ Community.
<p>
<h6 style="color:coral"><u>3. Bonus Get Seller : 5%</u></h6>
Anda memperoleh 5% (poin Mars) per produk yg terjual dari Toko Online yang telah Anda rekomendasikan. Silahkan Anda merekomendasikan penjual yang profesional di Mars sebanyak-banyaknya.
<p>

<h6 style="color:coral"><u>4. REWARD (Total 50%)</u></h6>
YELLOW : Hand Phone (Rp. 2 Juta)<br>
GREEN : Motor (Rp. 30 Juta)<br>
BLUE : Mobil (Rp. 250 Juta)<br>
RED : Mobil (Rp. 500 Juta)<br>
BLACK : Rumah (Rp. 2 Milyar)<br>
<p>
<h6 style="color:coral"><u>5. Bonus THR (Tunjangan Hari Raya - Total 5%)</u></h6>
Khusus bagi Anda yang berperingkat MASTER. Anda akan dianggap sebagai pemilik saham perusahaan dengan memperoleh Profit National Sharing yang dibagikan setiap menjelang Lebaran.
<p>
<p>
<i>CATATAN :<br>
# Bonus ditransfer ke rekening Anda setiap tanggal 1 dan 15 setiap bulannya.<br>

# Minimal transfer Rp. 45.000,- Admin fee 5% per transaksi.<br>
#Salah satu keunggulan teknis konsep Marketing Plan Mars yaitu Compress Dynamis System, maksudnya jika di salah satu level Generasi yang berPeringkat Sama (GPS) nya Anda tidak aktif maka perhitungan Bonus GPS yang dibawahnya mengggantikan posisi GPS yang tidak aktif tersebut. Dengan konsep ini sangat memungkinkan bahwa Seorang Leader Aktif bisa memperoleh Bonus dari kedalaman tak terbatas tanpa mengurangi alokasi dana (budget) bonus-bonus yang telah ditetapkan oleh perusahaan. Untuk membuktikan keaktifan seorang Leader, kami memberikan parameter kewajiban melakukan belanJA PRIbadi bagi seorang leader yang berperingkat mulai GREEN hingga BLACK jika ingin memperoleh Bonus-bonus di Mars. Kewajiban JAPRI Anda dihitung secara bulanan. JAPRI bulan ini untuk perhitungan Bonus bulan depan.</i><br>
GREEN : pM≥Rp. 20.000,-/bulan
<br>
BLUE : pM ≥Rp. 30.000,-/bulan
<br>
RED : pM ≥Rp. 40.000,-/bulan
<br>
BLACK : pM ≥Rp. 50.000,-/bulan
<p><i>
Demi memberikan pelayanan yang maksimal, akan disediakan fitur AutoJAPRI yang bisa diaktifkan di setiap akun Anda.</i>





<p>
<b>
<i>Mars sebagai pelopor Market Place NAFTING System telah membuat culture (budaya) baru di era digital (Industri 4.0). Membuat siklus produsen dan konsumen menjadi sangat efektif & efisien, memangkas jalur distribusi dan biaya iklan, transparansi terkait harga  jual terhadap biaya produksi dan fee marketing yang tersentralisasi (terpusat) dengan munculnya istilah pM (poin Mars). Dimana besar kecilnya pM ditentukan sendiri oleh member penjual (Seller), bukan pihak perusahaan.
Disempurnakan dengan platform non profitnya MZ Community yaitu DJOS, Charger, Blogs & Watch. Semoga dengan Ridho Allah SWT kita semua dapat meraih Kemenangan Finansial, Kemenangan Emosional dan Kemenangan Spiritual.</i></b><p>
    <a href="/pages/mars">Kembali keatas</a>
    
</div>

    
<?= $this->endSection();?>
