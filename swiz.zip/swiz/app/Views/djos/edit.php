

<?= $this-> extend('layout/template_admin_djos'); ?>


<?= $this-> section('content'); ?>

<div class="container">
   <div class="row">   
      <div class="col">
      
<p>   

<h3>Form Edit Data</h3>


<form action="/djos/update/<?= $djos['id']; ?>" method="post">

<?= csrf_field(); ?>

 
  <div class="form-grup row">
    <label for="tanggal" class="col-sm-2 col-form-label">Tanggal</label>
    <div class="col-sm-10">
<input type="date" class="form-control" id="tanggal" name="tanggal"  value="<?= $djos['tanggal']; ?>"  autofocus>            
</div>
</div>
<p>

  <div class="form-grup row">
    <label for="masuk" class="col-sm-2 col-form-label">Uang Masuk</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="masuk" name="masuk"  value="<?= $djos['masuk']; ?>"   >
    </div>
  </div>
<p> 
  <div class="form-grup row">
    <label for="donatur" class="col-sm-2 col-form-label">Donatur</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="donatur" name="donatur" value="<?= $djos['donatur']; ?>"   >
    </div>
  </div>
<p> 
  <div class="form-grup row">
    <label for="keluar" class="col-sm-2 col-form-label">Uang Keluar</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="keluar" name="keluar" value="<?= $djos['keluar']; ?>"  >
    </div>
  </div>
<p> 
  <div class="form-grup row">
    <label for="volunteer" class="col-sm-2 col-form-label">Volunteer</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="volunteer" name="volunteer"  value="<?= $djos['volunteer']; ?>"  >
    </div>
  </div>
<p> 
    <div class="form-grup row">
    <label for="keterangan" class="col-sm-2 col-form-label">Keterangan</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="keterangan" name="keterangan"  value="<?= $djos['keterangan']; ?>"   >
    </div>
  </div>

      



  <a href="<?= base_url(); ?>/djos/cashflow" class="btn btn-secondary float-right my-3">Back</a>
  <button type="submit" class="btn btn-warning float-left my-3">Edit Data</button>
 
</form>



</div>
</div>
</div>
<?= $this-> endSection(); ?>










