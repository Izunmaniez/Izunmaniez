.<?= $this-> extend('template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this-> include('template/topbar'); ?>

<?= $this-> include('template/sidebar'); ?>


 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>CASH FLOW DJOS</h1>
            
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#"><?= date("d-m-Y"); ?></a></li>
            </ol>
          </div>        
        </div>
      </div><!-- /.container-fluid -->
      
     <p>
     
<a href="/djos" class="btn btn-secondary btn-md float-right mr-1"><i class="fas fa-angle-double-left"></i>  Back</a>                   
   
<a class="btn btn-primary ml-1" href="/djos/tambah_cashflow"><i class="fas fa-plus"></i> Tambah Data</a>
    

<?php if(session()->getFlashdata('pesan')) : ?>

<div class="alert alert-success" role="alert">

<?= session()->getFlashdata('pesan');?>

</div>
  
<?php endif; ?>



  </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              
              <!-- /.card-header -->
              <div class="card-body" style="overflow:auto; ">
                <table id="example2" class="table table-bordered table-hover">
                  <thead class="table-info">
                  <tr>
                    <th>#</th>
                    <th>Tanggal</th>
                    <th>Donasi</th>
                    <th>Donatur</th>
                    <th>Disalurkan</th>
                    <th>Volunteer</th>
                    <th>Keterangan</th>
                                                        
                  </tr>
                  </thead>
                  <tbody>
                  

<?php $i=1 + (5 * ($currentPage - 1)); ?>                

 <?php foreach ($djos as $dj) : ?>     
                                                               
                  <tr>
                    <td><?=$i++; ?>  </td>
                    <td><?=$dj['tanggal']; ?>  </td>
                    <td><?=$dj['masuk']; ?>  </td>
                    <td><?=$dj['donatur']; ?>  </td>
                    <td><?=$dj['keluar']; ?>  </td>
                    <td><?=$dj['volunteer']; ?>  </td>
                    <td>
<div class="container">      
<div class="vmvm-item"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="ket" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i> lihat </i></a>

  <div class="dropdown-menu" style="background-color:#808000; color:white; text-align:center; padding:15px 15px 15px 35px;"  aria-labelledby="ket">
<p>
<p>
   
<?=$dj['keterangan']; ?>

<p><p><p><p>

<div class="btn btn-success">Aye..ðŸ˜„</div>
<p><p>
</div>
</div>
</div>


 </td>
 


<td class="project-actions text-right">                         
                          <a class="btn btn-warning btn-sm" href="/djos/edit/<?= $dj['id']; ?>">
                              <i class="fas fa-pencil-alt">
                              </i>
                              Edit
                          </a>
                          <p>
<form action="/djos/delete/<?= $dj['id']; ?>" method="post">
<?= csrf_field(); ?>

<input type="hidden" name="_method" value="delete">

 <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus data ini?');">
                              <i class="fas fa-trash">
                              </i>
                              Delete
                          </button>
</form>
                      </td>

</tr> 



 <?php endforeach; ?>     
       
  </tbody> 
  
  <?= $pager->links('djos','djos_pagination'); ?>
                         
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
</div>
</div>
</div>
</section>
            
</div>

<?= $this-> include('template/footer'); ?>


<?= $this-> endSection(); ?>
