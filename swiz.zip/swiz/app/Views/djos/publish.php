
<?= $this-> extend('layout/template_general'); ?>


<?= $this-> section('content'); ?>

<?= $this->include('layout/navbar_djos');?>


<div class="container">
   <div class="row">   
      <div class="col">
      
<p>   

<h4>Tabel Cashflow DJOS</h4>
<p><p><p>

<form action="" method="post">
<?= csrf_field(); ?> 

<div class="input-group mb-3">
  <input type="text" class="form-control" style="border:1px solid green; border-radius:5px;" placeholder="Cari data" name="keyword">
<div class="input-grup-append">
  <button class="btn btn-success" type="submit" name="submit">Cari</button>
</div>
</div>
</form>

<div class="table-djos">

<table class="table table-bordered">
  <thead class="table-success">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Tanggal</th>
      <th scope="col">Donasi</th>
      <th scope="col">Donatur</th>
      <th scope="col">Disalurkan</th>
      <th scope="col">Volunteer</th>
      <th scope="col">Keterangan</th>
    </tr>
  </thead>
  <tbody>

  
 <?php $i=1 + (30 * ($currentPage - 1)); ?>

 <?php foreach ($djos as $dj) : ?>
 
 <?php 

  $donasi[] =$dj['masuk'];
  $disalurkan[] =$dj['keluar'];
?> 

  <tr> 
 <th scope="col"><?=$i++; ?></th>
 <td scope="col"><?=$dj['tanggal']; ?></td>
 <td scope="col"><?=$dj['masuk']; ?></td>

 <td scope="col"><?=$dj['donatur']; ?></td>
 <td scope="col"><?=$dj['keluar']; ?></td>

 <td scope="col"><?=$dj['volunteer']; ?></td>
 <td scope="col">
<div class="container">      
<div class="vmvm-item"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="ket" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i> lihat </i></a>

  <div class="dropdown-menu" style="background-color:#808000; color:white; text-align:center; padding:15px 15px 15px 35px;"  aria-labelledby="ket">
<p>
<p>
   
<?=$dj['keterangan']; ?>

<p><p><p><p>

<div class="btn btn-success">Aye..😄</div><p><p>
</div>
</div>
</div>
</div>
 </td>
 
</tr> 
 
  
<?php endforeach; ?>   
       
</tbody>  
</table>
</div>

 <?= $pager->links('djos','djos_pagination'); ?> 



<?php
    //total
    $total_donasi =array_sum($donasi);
    $total_disalurkan   =array_sum($disalurkan);
    $saldo =$total_donasi-$total_disalurkan;
?>

<!-- Content Wrapper. Contains page content -->

    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h3 class="m-0 text-dark">Total Cashflow</h3>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Hari ini <?= date("d-m-Y"); ?>  </a></li>            
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

  <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
        
        <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-primary">
              <div class="inner">
                <p>Total Donasi Rp.</p>
                <h5><sup style="font-size: 17px"><?=number_format ($total_donasi, 0, ".", "."); ?></sup></h5>               
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
               </div>
          </div>
          <!-- ./col -->
          
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <p>Total Disalurkan Rp.</p>
                <h5><sup style="font-size: 17px"><?=number_format ($total_disalurkan, 0, ".", "."); ?></h5>               
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
               </div>
          </div>
          <!-- ./col -->
          
          <div class="col-lg-3 col-12">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <p>Saldo Rp.</p>
                <h5><sup style="font-size: 17px"><?=number_format ($saldo, 0, ".", "."); ?></h5>               
              </div>
              <div class="icon">
               <i class="ion ion-bag"></i>
               </div>
               </div>
          </div>
          <!-- ./col -->                          
        </section>       
</div>
</div>
</div>

<?= $this-> endSection(); ?>










