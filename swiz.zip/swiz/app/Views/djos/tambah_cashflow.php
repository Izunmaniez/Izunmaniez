

<?= $this-> extend('template/index'); ?>


<?= $this-> section('content'); ?>

<div class="container">
   <div class="row">   
      <div class="col">
      
<p>   

<h3>Form Tambah Data</h3>


<form action="/djos/save" method="post" enctype="multipart/form-data" >

<?= csrf_field(); ?> 
 
  
  <div class="form-grup row">
    <label for="tanggal" class="col-sm-2 col-form-label">Tanggal</label>
    <div class="col-sm-10">
      <input type="date" class="form-control" id="tanggal" name="tanggal">
    </div>
  </div>
  <p>

  <div class="form-grup row">
    <label for="masuk" class="col-sm-2 col-form-label">Donasi (Rp.) </label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="masuk" name="masuk">
      <i style="color:red;">(diisi hanya dengan angka)</i>
    </div>
  </div>
  <p>
  <div class="form-grup row">
    <label for="donatur" class="col-sm-2 col-form-label">Donatur</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="donatur" name="donatur">
    </div>
  </div>
  <p>
  <div class="form-grup row">
    <label for="keluar" class="col-sm-2 col-form-label">Disalurkan (Rp.)</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="keluar" name="keluar">
      <i style="color:red;">(diisi hanya dengan angka)</i>
    </div>
  </div>
  <p>
  <div class="form-grup row">
    <label for="volunteer" class="col-sm-2 col-form-label">Volunteer</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="volunteer" name="volunteer">
    </div>
  </div>
  <p>
    <div class="form-grup row">
    <label for="keterangan" class="col-sm-2 col-form-label">Keterangan</label>
    <div class="col-sm-10">
      <input type="textarea" class="form-control" id="keterangan" name="keterangan">
    </div>
  </div>

<a href="<?= base_url(); ?>/djos/cashflow" class="btn btn-secondary float-right my-5">Back</a>
  <button type="submit" class="btn btn-primary float-left my-5">Tambah Data</button>
 
</form>

</div>
</div>
</div>
<?= $this-> endSection(); ?>










