<?= $this-> extend('template/index'); ?>

<?= $this-> section('content'); ?>


<div class="container mt-2">

      
      
<div class="card card-warning card-outline">
              <div class="card-header">
                <h3 class="card-title">
                  <i class="fas fa-edit"></i>
                  Edit My Online Shop
                </h3>
              </div>
              <div class="card-body">
              
<form action="/toko/update/<?= toko()->id; ?>" method="post" enctype="multipart/form-data">
<?= csrf_field(); ?>

<input type="hidden" name="gambarLama" value="<?= toko()->gbr1; ?>" >            
 
<div class="card" style="width: 17rem;">
  <img src="/gbr_produk/<?= toko()->gbr1; ?>" class="card-img-top">
   
<center><i style="color:coral;">Ukuran foto maksimal 1 MB</i></center>
</div>

<div class="form-group row">  
   <label for="gbr1" class="col-sm-2 col-form-label">Ganti Foto?</label>  
        
<div class="col-sm-6">   
  <div class="custom-file">                         
   <input type="file" class="custom-file-input <?= ($validation->hasError('gbr1')) ? 'is-invalid' : ''; ?>" id="gbr1" name="gbr1" onchange="previewImg()">
  <div class="invalid-feedback">
     <?= $validation->getError('gbr1'); ?>
  </div>  
<label class="custom-file-label" for="gbr1"><?= toko()->gbr1; ?></label>
                           </div>
                        </div>  
                    </div>



<table>
<tr><td colspan="3"><br /><b>BIO DATA</b></td></tr>

<tr><td>Nama Lengkap</td>
<td>
<input type="text" class="form-control mb-2"  id="kategori" name="kategori" value="<?= toko()->kategori; ?>" autofocus>
</td>
</tr> 

</table>                    
      
  <p><p>
   <div class="modal-footer justify-content-around">
  <button type="submit" class="btn btn-warning">Simpan</button>
  <a href="/toko" class="btn btn-secondary  pl-7">Cancel</a>
   </div>   
</form>     
              </div>
              </div>
              <!-- /.card -->          
      </div><!-- /.container-fluid -->
     
 

</div>
</div>
</div>


<?= $this-> include('template/footer'); ?>
<?= $this-> endSection(); ?>
