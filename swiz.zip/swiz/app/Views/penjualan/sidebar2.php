   <aside class="main-sidebar sidebar-dark-purple elevation-4">
    <!-- Brand Logo -->
    <a class="brand-link" href="/admin">
      <img src="/img/logohhc.png" alt="Logo HP" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">HHC | Home</span>
    </a>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
            
              <i class="nav-icon fas fa-store"></i>
              <p>
                Daftar Toko
                 <i class="right fas fa-angle-double-left"></i>
                 
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="" class="nav-link ">       
                  <i class="fas fa-store text-success"></i>
                  <p>Toko Prioritas</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="penjualan/index" class="nav-link">
                  <i class="fas fa-store text-info"></i>
                  <p>Toko Regular</p>
                </a>
              </li>
              
             <div class="dropdown-divider"></div>    
                 
     <li class="nav-item">
                <a href="" class="nav-link">
                  
                  <i class="fas fa-store-slash"></i>
                  <p>Toko Blokir</p>
                </a>
              </li>
                           
            </ul>
          </li>
          
          
          <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
            
              <i class="fas fa-users"></i>
              <p>
                Data Member
                 <i class="right fas fa-angle-double-left"></i>              
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/admin/all_member" class="nav-link active">       
                  <i class="fas fa-address-card nav-icon"></i>
                  
                  <p>Semua Member</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-light"></i>
                  <p>WHITE</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-warning"></i>
                  
                  <p>YELLOW</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-success"></i>
                  <p>GREEN</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-primary"></i>
                  <p>BLUE</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-danger"></i>
                  <p>RED</p>
                </a>
              </li>
                 <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-secondary"></i>
                  <p>BLACK</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="nav-icon fas fa-user-tie text-light"></i>
                  <p>MASTER</p>
                </a>
              </li>
              <div class="dropdown-divider"></div>    
                 
     <li class="nav-item">
                <a href="" class="nav-link">
                  
                  <i class="fas fa-user-times"></i>
                  <p>Member Blokir</p>
                </a>
              </li>
     
            </ul>
          </li>
          
      
          
              <div class="dropdown-divider"></div>
                 
<a href="/logout" class="brand-link" onclick="return confirm('Yakin ingin keluar dari halaman dashboard?');"  style="background-color:#800517; color:white;">
      <img src="/dashboard/logout.png" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light"><b>Logout</b></span>
    </a>
          
          </ul>
        
      </nav>
              
      <!-- /.sidebar-menu -->
    
    <!-- /.sidebar -->
  </aside>
  
  
        
        