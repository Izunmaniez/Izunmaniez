<footer>
<div class="footer">
<a href="/" class="footer-item"><img src="/img/mars_green.png"><br>Shoping</a>
    
<a href="/pages/faq" class="footer-item" style="margin-top:7px;"><img src="/img/faq.png"><p style="padding-top:7px;">F A Q</p></a>

<div class="container">
<div class="footer-item-middle" data-toggle="modal" data-target="#community"><img src="/img/logohhc.png"></div>

  <div class="modal fade" id="community">
    <div class="modal-dialog">
      <div class="modal-content">      
        <div class="modal-body">


<div class="vmvm">        
<div class="vmvm-item"> 
  <a class="btn btn-success dropdown-toggle" href="#" role="button" id="visi" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Visi </a>

  <div class="dropdown-menu" style="background-color:#DAF7A6; text-align:center; padding:5px 9px;" aria-labelledby="visi">
    <h3>VISI</h3>
Menjadi komunitasnya Para Leader yang Berakhlakul Karimah, Dermawan Makmur dan Sejahtera.

<p><p><p><p>

<div class="btn btn-success">Aye..?!!😀</div><p><p>
</div>
</div>




<div class="vmvm-item"> 
  <a class="btn btn-success dropdown-toggle" href="#" role="button" id="misi" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Misi </a>

    <div class="dropdown-menu" style="background-color:#DAF7A6; text-align:center; padding:5px 9px;" aria-labelledby="misi">
    <h3>MISI</h3>
1. Menjalankan semua program MZ Community dengan didasari rasa penuh syukur dan suka-cita.<br>

2. Beradaptasi terhadap segala perkembangan teknologi dan Berinovasi tanpa batas.


<p><p><p><p>

<div class="btn btn-success">Aye..?!!😀</div><p><p>
</div>
</div>


<div class="vmvm-item"> 
  <a class="btn btn-success dropdown-toggle" href="#" role="button" id="value" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Value</a>

    <div class="dropdown-menu" style="background-color:#DAF7A6; text-align:center; padding:5px 9px;" aria-labelledby="value">
    <h3>VALUE</h3>
<b>7 PRINCESS  MZ Community</b> (PRINCiple of SuccESS)<br>
1. Teguhkan Impian dan Fokus.<br>
2. Bersyukur, bersuka-cita dan tidak mengeluh.<br>
3. Rutin bersedekah.<br>
4. Konsumsi yang halal.<br>
5. Tulus, Rendah hati, Respek dan Empati.<br>
6. Menjaga Integritas.<br>
7. Menjadi Leader yang menginspirasi.


<p><p><p><p>

<div class="btn btn-success">Aye..?!!😀</div><p><p>
</div>
</div>


<div class="vmvm-item"> 
  <a class="btn btn-success dropdown-toggle" href="#" role="button" id="motto" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Motto</a>

    <div class="dropdown-menu" style="background-color:#DAF7A6; text-align:center; padding:5px 9px;" aria-labelledby="motto">
    <h3>MOTTO</h3>
Kami Sangat Bersyukur!<br>
Kami Sangat Bahagia!<br>
Kami Sangat Sukses!

<p><p><p><p>

<div class="btn btn-success">Aye..?!!😀</div><p><p>
</div>
</div>



</div>  






           
 <h2 class="platform-judul-item">MZ Community</h2>

<div class="container-platform">
    
<a href="/pages/djos"class="platform-item"><img src="/content/platform_item.png"><br>DJOS</a>

<a href="/info"class="platform-item"><img src="/content/platform_item.png"><br>BLOGS</a>

<a href="/watch"class="platform-item"><img src="/content/platform_item.png"><br>WATCH</a>

<a href="/pages/charger"class="platform-item"><img src="/content/platform_item.png"><br>CHARGER</a>

<a href="/pages"class="platform-item"><img src="/content/platform_item.png"><br>MARS</a>

<a href="#"class="platform-item" style="color:black"><img src="/content/platform_item.png"><br>BARLEB</a>

<a href="#"class="platform-item"style="color:black"><img src="/content/platform_item.png"><br>COOPERATION</a>

<a href="#"class="platform-item"style="color:black"><img src="/content/platform_item.png"><br>CURRENCY</a>

<a href="#"class="platform-item"style="color:black"><img src="/content/platform_item.png"><br>TRADE</style></a>        

</div>
    
<p><p><p><p>
        
          <a href="" class="btn btn-info">Tentang Kami</a>
        
       
          <button type="button" class="btn btn-success" data-dismiss="modal">Aye..?!!😀</button>
       
       
      </div>
    </div>
  </div>
</div>
</div>


<a href="/pages/mars" class="footer-item"><img src="/img/benefit.png"><br>Benefit</a>   

<a href="/users" class="footer-item"><img src="/img/login.png"><br>Account</a>   

</div>

</footer>

  
  
  
  
  
  
  
  
  
  
  
  
  
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <!-- Option 2: jQuery, Popper.js, and Bootstrap JS
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    -->
    

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
    -->
    
    
  </body>
</html>