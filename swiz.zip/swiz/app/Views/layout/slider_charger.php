
    <section class="slider-section pt-4 pb-4">
        <div class="container">
            <div class="slider-inner">
                <div class="row">
                    
                    <div class="col">
                        <div id="carouselExampleIndicators" class="carousel slide carousel-inner" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                            </ol>
                            <div class="carousel-inner shadow-sm rounded">
                                <div class="carousel-item active">
                                    <img src="/slider_charger/slider1.jpg" class="d-block w-100"  style="height:190px; margin-bottom:13px;">
  
                                    <div class="carousel-caption d-none d-md-block">
                                        <h5>Sei Kamah Baru - Asahan</h5>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <img src="/slider_charger/slider2.jpg" class="d-block w-100"  style="height:190px; margin-bottom:13px;">
  
                                    <div class="carousel-caption d-none d-md-block">
                                        <h5>Sei Kamah Baru - Asahan</h5>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <img src="/slider_charger/slider3.jpg" class="d-block w-100"  style="height:190px; margin-bottom:13px;">
  
                                    <div class="carousel-caption d-none d-md-block">
                                        <h5>Majelis Zikir Meranti -Asahan </h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Slider -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    
