<nav class="navbar-faq"  navbar-expand-lg navbar-light">
    
 <div class="nav-faq">FAQ (PERTANYAAN & JAWABAN)</div>
     
</nav>