<nav>
<div class="navbar-index">
  <div class="navbar-brand"><img src="/img/kategori.png" alt="" loading="lazy" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
</div>


    
    <!-- SEARCH FORM -->
    <form action="" method="get"  class="form-inline-hp">
      <div class="input-group input-group-sm">
        <input class="form-control-hp form-control-navbar" type="search" placeholder="Search" aria-label="Search">
          <div class="input-group-append">
          <button class="btn btn-navbar" type="submit">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div>
    </form>

  <a href="<?= route_to('register') ?>" class="mendaftar">Daftar<br>Gratis</a>

</div>    
      
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
      
      <div class="nav-items">

<div class="nav-item">
<img src="/category/makanan.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Makanan
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Sembako</a>
    <a class="dropdown-item" href="#">Makanan Ringan</a>
    <a class="dropdown-item" href="#">Camilan</a>
  </div>
</div>   
    
<div class="nav-item">
<img src="/category/minuman.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Minuman
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Kopi</a>
    <a class="dropdown-item" href="#">Juice</a>
    <a class="dropdown-item" href="#">Energy Drink</a>
  </div>
</div>   

<div class="nav-item">
<img src="/category/herbal.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Makanan<br>Kesehatan
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Makanan Kesehatan/Food Supplemen</a>
  </div>
</div>   

<div class="nav-item">
<img src="/category/parfum.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Parfum
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Parfum</a>
  </div>
</div>   

<div class="nav-item">
<img src="/category/kecantikan.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Kecantikan
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Kosmetika</a>
    <a class="dropdown-item" href="#">Alat Saloon Wanita</a>
 <a class="dropdown-item" href="#">Alat Saloon Pria</a>
  </div>
</div>   

<div class="nav-item">
<img src="/category/rumah.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Rumah &<br>Taman
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Furniture</a>
    <a class="dropdown-item" href="#">Dapur Mania</a>
 <a class="dropdown-item" href="#">Toiletris</a>
 <a class="dropdown-item" href="#">Taman</a>
  </div>
</div>   

<div class="nav-item">
<img src="/category/pakaian_wanita.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Pakaian<br>Wanita
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Muslimah</a>
    <a class="dropdown-item" href="#">Batik</a>
 <a class="dropdown-item" href="#">Kemeja</a>
<a class="dropdown-item" href="#">Kaos</a>
<a class="dropdown-item" href="#">Rok/Celana</a>
<a class="dropdown-item" href="#">Under Ware</a>
<a class="dropdown-item" href="#">Sepatu/Sendal</a>
  </div>
</div>   

<div class="nav-item">
<img src="/category/pakaian_pria.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Pakaian<br>Pria
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Muslim</a>
    <a class="dropdown-item" href="#">Batik</a>
 <a class="dropdown-item" href="#">Kemeja</a>
<a class="dropdown-item" href="#">Kaos</a>
<a class="dropdown-item" href="#">Celana Panjang</a>
<a class="dropdown-item" href="#">Celana Pendek</a>
<a class="dropdown-item" href="#">Under Ware</a>
<a class="dropdown-item" href="#">Sepatu/Sendal</a>
  </div>
</div>   

<div class="nav-item">
<img src="/category/pakaian_anak.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Pakaian<br>Anak
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Muslimah</a>
    <a class="dropdown-item" href="#">Batik</a>
 <a class="dropdown-item" href="#">Kemeja</a>
<a class="dropdown-item" href="#">Kaos</a>
<a class="dropdown-item" href="#">Rok/Celana</a>
<a class="dropdown-item" href="#">Under Ware</a>
<a class="dropdown-item" href="#">Sepatu/Sendal</a>
  </div>
</div>   

<div class="nav-item">
<img src="/category/buku.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Buku &<br> Alat Tulis
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Buku Sekolah</a>
<a class="dropdown-item" href="#">Buku Tulis/Gambar</a>
    <a class="dropdown-item" href="#">Buku/Kitab Agama</a>
 <a class="dropdown-item" href="#">Buku Umum</a>
<a class="dropdown-item" href="#">Alat Tulis/Gambar</a>
<a class="dropdown-item" href="#">Buku/Alat Tulis Anak</a>
  </div>
</div>   

<div class="nav-item">
<img src="/category/peternakan.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Peternakan
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Pakan Ternak</a>
<a class="dropdown-item" href="#">Alat peternakan</a>
  </div>
</div>

<div class="nav-item">
<img src="/category/pertanian.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Pertanian
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Pupuk</a>
<a class="dropdown-item" href="#">Alat Pertanian</a>
    <a class="dropdown-item" href="#">Bibit</a>
<a class="dropdown-item" href="#">Buah-buahan</a>
    <a class="dropdown-item" href="#">Bunga</a>
<a class="dropdown-item" href="#">palawija</a>
  </div>
</div>

<div class="nav-item">
<img src="/category/pertukangan.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Pertukangan
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Material Bangunan </a>
<a class="dropdown-item" href="#">Alat Kerja Tukang</a>
  </div>
</div>

<div class="nav-item">
<img src="/category/listrik.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Listrik
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Material Listrik</a>
 <a class="dropdown-item" href="#">Alat Teknisi Listrik</a>
  </div>
</div>

<div class="nav-item">
<img src="/category/handphone.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Handphone &<br>Aksesoris
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Handphone</a>
<a class="dropdown-item" href="#">Aksesoris</a>
<a class="dropdown-item" href="#">Alat Teknisi HP</a>
<a class="dropdown-item" href="#">Kartu Perdana</a>
  </div>
</div>


<div class="nav-item">
<img src="/category/elektronik.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Elektronik
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
<a class="dropdown-item" href="#">Elektronik</a>
    <a class="dropdown-item" href="#">Alat Service Elektronik </a>
<a class="dropdown-item" href="#">Spare Part</a>
  </div>
</div>

<div class="nav-item">
<img src="/category/komputer.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Komputer &<br>Laptop
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Komputer (PC)</a>
    <a class="dropdown-item" href="#">Laptop</a>
  </div>
</div>   
    

<div class="nav-item">
<img src="/category/mobil.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Mobil
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Mobil</a>
    <a class="dropdown-item" href="#">Spare Part</a>
  </div>
</div>   
 
<div class="nav-item">
<img src="/category/motor.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Sepeda<br>Motor
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Sepeda Motor</a>
    <a class="dropdown-item" href="#">Spare Part</a>
  </div>
</div>   

<div class="nav-item">
<img src="/category/mesin.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Mesin
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Mesin</a>
    <a class="dropdown-item" href="#">Spare Part Mesin</a>
  </div>
</div>   


<div class="nav-item">
<img src="/category/olahraga.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Olah Raga
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Alat Olah Raga</a>
    <a class="dropdown-item" href="#">Fasilitas Olah Raga</a>
  </div>
</div>   
    
<div class="nav-item">
<img src="/category/musik.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Alat Musik
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">Alat Musik</a>
  </div>
</div>   

<div class="nav-item">
<img src="/category/souvenir.png"> 
  <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Souvenir
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="#">souvenir</a>
  </div>
</div>   

</div>



      



 </div>
</nav>