<nav>
<div class="navbar-hp">
  <a class="nav-hp" href="/"><<<</a>

<marquee behavior=”scroll” direction=”right” class="runtext-charger"><b>Mars</b> ~ Market Place Nafting System ~ Daftar Gratis ~ Gratis Toko Online ~ Membangun Aset hanya dengan share (bagikan) link website Mars ~ Dapatkan berbagai macam Bonus dan Reward dari perbelanjaan pribadimu dan temen-temenmu, juga dari hasil jualan toko online temen-temen rekomendasimu.</marquee>
    

<div class="wa"><a href="https://api.whatsapp.com/send?phone=62 85275305301&text=Hallo..%20Bang Izun,%20Saya %20ingin%20bicara%20tentang%20Hamdalah%20POIN😊🙏"><img src="/img/wa.png"></a>
</div>
     
 </div>
</nav>