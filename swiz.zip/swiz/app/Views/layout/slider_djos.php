<section class="slider-section pt-4 pb-4">
<div class="container">
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner shadow-sm rounded ">
    <div class="carousel-item active">
      <img src="/slider_djos/slider_djos1.png" class="d-block w-100" style="height:190px; margin-bottom:13px;">
    </div>
    <div class="carousel-item">
      <img src="/slider_djos/slider_djos2.png" class="d-block w-100"  style="height:190px; margin-bottom:13px;">
    </div>
  <div class="carousel-item">
      <img src="/slider_djos/slider_djos3.png" class="d-block w-100"  style="height:190px; margin-bottom:13px;">
    </div>
    
   
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>
</section>