<div class="container">

<nav class="nav-djos navbar-expand-lg navbar-light">
    
 <a class="home-djos" href="/pages/djos">Home</a>
    

 

<marquee behavior=”scroll” direction=”right” class="runtext-djos">Sedekah Seribu Rupiah lebih berarti dari pada seribu kata-kata.. </marquee>

<div class="wa"><a href="https://api.whatsapp.com/send?phone=62 81370769831&text=Hallo..%20Assalamu'alaikum%20Abangnda%20Kuswito.%20Saya %20ingin%20bicara%20tentang%20Hamdalah%20DJOS😊🙏"><img src="/img/wa.png"></a>

</div>
</nav>
</div>