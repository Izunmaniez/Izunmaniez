<nav class="navbar-faq"  navbar-expand-lg navbar-light">
    
 <div class="nav-faq"><a href="/watch"><<<</a>     Hamdalah WATCH</div>
     
</nav>