<nav class="navbar-faq"  navbar-expand-lg navbar-light">
    
 <div class="nav-faq">MZ BLOGERS</div>
     
</nav>