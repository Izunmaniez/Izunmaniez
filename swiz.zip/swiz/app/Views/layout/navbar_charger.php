<nav class="nav-charger navbar-expand-lg navbar-light">
    
 <a class="home-charger" href="/Pages/charger" >Home</a>
    

 

<marquee behavior=”scroll” direction=”right” class="runtext-charger">Kami Sangat Bersyukur - Kami Sangat Bahagia - Kami Sangat Sukses  </marquee>

  
 
  
<div class="wa"><a href="https://api.whatsapp.com/send?phone=62 85275305301&text=Hallo..%20Bang Izun,%20Saya %20ingin%20bicara%20tentang%20Hamdalah%20CHARGER😊🙏"><img src="/img/wa.png"></a>

</div>
</nav>