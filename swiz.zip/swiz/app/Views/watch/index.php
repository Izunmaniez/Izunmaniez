<?= $this-> extend('layout/template_general'); ?>


<?= $this-> section('content'); ?>

<?= $this->include('layout/navbar_watch');?>

<div class="container">
<div class="row">
<div class="col">

<p>
            
 <h5>Ibadah Mudah</h5>  

Berubudiyah hanya dengan nonton video dari channel <a href="https://www.youtube.com/channel/UChczBosBiGwtDBJxDgAfGXw">Hamdalah WATCH.</a>Karena jika channel ini telah dimonetisasi oleh youtube duitnya 100% akan di Donasikan ke Divisi Sosial HHC - DJOS & Divisi Pendidikan Non Formal HHC - CHARGER.
 <p>Anda juga berkesempatan turut berkontribusi dengan menyumbangkan karya konten youtube Anda. Kirimkan konten youtube Anda ke <i>hamdalah513@gmail.com</i></p>
 
  
  <form action="" method="post">
 <?= csrf_field(); ?> 
 
 <?php foreach ($watch as $wat) : ?>		
		
			<div class="col-sm-12 col-lg-4 text-center align-self-lg-center mt-3">
				<h4><?=$wat['judul']; ?></h4>
			</div>
			<div class="col-sm-12 col-lg-8 mt-3">
				<div class="embed-responsive embed-responsive-16by9">
					<iframe width="560" height="315" src="<?=$wat['link_video']; ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
				</div>
			</div>
		
		<hr>		
		<hr>
  
  
<?php endforeach; ?>   
       </form>       
  
    
		
  </div>
   </div>
   </div>

<?= $this-> endSection(); ?>

            
            
         

            

