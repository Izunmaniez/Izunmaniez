<?= $this-> extend('template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this-> include('template/topbar'); ?>

<?= $this-> include('template/sidebar'); ?>

<div class="container">
   <div class="row">   
      <div class="col">
      
<p>   

<h3>Edit Video</h3>


<form action="/watch/update/<?= $watch['id']; ?>" method="post">

<?= csrf_field(); ?>

<div class="form-grup row">
    <label for="tanggal" class="col-sm-2 col-form-label">Tanggal</label>
    <div class="col-sm-10">
<input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= $watch['tanggal']; ?>" autofocus>            
</div>
</div>
 <p>
 
  <div class="form-grup row">
    <label for="judul" class="col-sm-2 col-form-label">Judul</label>
    <div class="col-sm-10">
<input type="text" class="form-control" id="judul" name="judul"  value="<?= $watch['judul']; ?>" >            
</div>
</div>
<p>

  <div class="form-grup row">
    <label for="link_video" class="col-sm-2 col-form-label">Link Video</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="link_video" name="link_video"  value="<?= $watch['link_video']; ?>"   >
    </div>
  </div>
  
  <p>
  <p>

<a href="/watch/list_video" class="btn btn-secondary btn-md float-right mr-1">Back</a>
                  
  <button type="submit" class="btn btn-warning">Simpan</button>
 
</form>

</p>

</div>
</div>
</div>

<?= $this-> include('template/footer'); ?>

<?= $this-> endSection(); ?>
