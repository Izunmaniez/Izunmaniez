<!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-purple navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
     <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars text-light "></i></a>      
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Messages Dropdown Menu -->
         
    <li class="nav-item dropdown">
        <a class="nav-link text-light" data-toggle="dropdown" href="#">
          CoC       
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <span class="dropdown-item">
          1. jsjdkdjkdv <br>
          2. hsjsjdjdjjdj<br>
          3. hdjdjdjjdj<br><p>
         </span>
    </li>   
    
    <li class="nav-item dropdown user-menu">
        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
          <img src="/foto_profile/<?= user()->foto; ?>" class="user-image img-circle elevation-2" alt="User Image">
          </a>
        <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <!-- User image -->
          <li class="user-header bg-info">
            <img src="/foto_profile/<?= user()->foto; ?>" class="img-circle elevation-2" alt="User Image">
            
            <br>
              <?= user()->username; ?><br>
              <?= user()->fullname; ?><br>
              <small>Dedicated since <?= user()->created_at; ?></small>
            </br>
          </li>
          <!-- Menu Body -->
          <li class="user-body">
            <div class="row">
  <div class="container">                                      
 <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-xl">My Profile</button>
   
 <a href="<?= base_url(); ?>/logout" class="btn btn-danger">Logout</a>
  </div>
            </div>
            <!-- /.row -->
          </li>
    </ul>
  </nav>
  <!-- /.navbar -->
  
  
      <div class="modal fade" id="modal-xl">
        <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">My Profile</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                         
            <!-- Profile Image -->
            <div class="card card-info card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                  <img class="profile-user-img img-fluid img-circle bg-info"
                       src="<?= base_url('foto_profile/' .user()->foto); ?>"
                       alt="User profile picture">
                </div>
                <h3 class="profile-username text-center"><?= user()->username; ?></b></h3>
                <h3 class="profile-username text-center"><?= user()->fullname; ?></b></h3>

                <p class="text-muted text-center"><small><i>Dedicated since <?= user()->created_at; ?></i></small></p>

                <ul class="list-group list-group-unbordered mb-2">
                  <li class="list-group-item">
                  <i class="fas fa-user text-info mr-1"></i>
                   <b>Telepon</b> <a class="float-right"><?= user()->telp; ?></b></a>
                  </li>
                  <li class="list-group-item">
                  <i class="fas fa-mobile-alt text-info mr-1"></i>
                    <b>Email</b> <a class="float-right"><?= user()->email; ?></b></a>
                  </li>               
                </ul>
               </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->   
                  
         <!-- Bank Account -->
            <div class="card card-info">
              <div class="card-header">
            <i class="fas fa-money-check-alt text-info mr-1"></i>
                <h3 class="card-title">Bank Account</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <strong><i class="fas fa-sort-numeric-up text-info mr-1"></i>Nomor Rekening</strong>
                <a class="float-right">
                <?= user()->norek; ?>
                </a>
                <hr>
                <strong><i class="fas fa-user text-info mr-1"></i> Pemilik Rekening</strong>
                <a class="float-right"><?= user()->an; ?></a>
                <hr>
                <strong><i class="fas fa-university text-info mr-1"></i> Nama Bank</strong>
                <a class="float-right">
                  <?= user()->mabank; ?>
                </a>               
                
               </div>
              <!-- /.card-body -->
            </div>           
          <div class="modal-footer justify-content-around">
              <button type="button" class="btn btn-info" data-dismiss="modal">Aye..??!!</button>
           </div>
  </div> 

          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->