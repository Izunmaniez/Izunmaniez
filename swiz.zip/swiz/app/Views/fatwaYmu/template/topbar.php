<!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-info navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars text-light "></i></a>      
      </li>
    <li class="nav-item">
      <a class="nav-link" href="/fatwa">
          <i class="fas fa-home text-light "></i>         
      </a>
     </li>
     </ul>
     
      <ul class="navbar-nav ml-auto">
      <li class="nav-item">
      <b class="text-header text-light">
          BKMZ ASAHAN         
      </b>
     </li>
     </ul>
          <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">      

        <li class="nav-item dropdown">
      <a class="nav-link" href="/logout" onclick="return confirm('Yakin ingin keluar dari halaman dashboard?');">         
      <i class="fas fa-sign-out-alt text-light"></i>         
      </a>       
      </li>   
      
      </ul>
     </nav> 