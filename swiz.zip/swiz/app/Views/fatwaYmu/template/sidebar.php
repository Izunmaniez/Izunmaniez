<aside class="main-sidebar sidebar-light-info elevation-4">
  
      <div class="brand-link">
      <img src="/img/logohhc.png" alt="Logo HP" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light"><b>Fatwa YM USTADZ</b></span>
    </div>   
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
             <li class="nav-item">
                <a href="#" class="nav-link active">
                    
                  <i class="fas fa-eye text-light"></i>                 
                  <p>Lihat  <i class="right fas fa-angle-double-left"></i>                
              </p>
                </a>
              
                <ul class="nav nav-treeview">
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-dot-circle nav-icon text-info"></i>
                      <p>Fatwa Teks</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-dot-circle nav-icon text-success"></i>
                      <p>Fatwa Gambar</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-dot-circle nav-icon text-primary"></i>
                      <p>Fatwa Video</p>
                    </a>
                  </li>
              </ul>
                            
          </li>      
          </ul>       
          
          
            
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
             <li class="nav-item">
                <a href="#" class="nav-link active">
                    
                  <i class="fas fa-edit text-light"></i>                 
                  <p>Tambah/Edit  <i class="right fas fa-angle-double-left"></i>                
              </p>
                </a>
              
                <ul class="nav nav-treeview">
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-dot-circle nav-icon text-info"></i>
                      <p>Fatwa Teks</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-dot-circle nav-icon text-success"></i>
                      <p>Fatwa Gambar</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-dot-circle nav-icon text-primary"></i>
                      <p>Fatwa Video</p>
                    </a>
                  </li>
              </ul>
                            
          </li>      
          </ul>            
      
  <div class="dropdown-divider"></div>

  <div class="brand-link">
      <img src="/img/logohhc.png" alt="Logo HP" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light"><b>Fatwa YM ABU</b></span>
    </div>   
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
             <li class="nav-item">
                <a href="#" class="nav-link active">
                    
                  <i class="fas fa-eye text-light"></i>                 
                  <p>Lihat  <i class="right fas fa-angle-double-left"></i>                
              </p>
                </a>
              
                <ul class="nav nav-treeview">
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-dot-circle nav-icon text-info"></i>
                      <p>Fatwa Teks</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-dot-circle nav-icon text-success"></i>
                      <p>Fatwa Gambar</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-dot-circle nav-icon text-primary"></i>
                      <p>Fatwa Video</p>
                    </a>
                  </li>
              </ul>
                            
          </li>      
          </ul>       
                           
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
             <li class="nav-item">
                <a href="#" class="nav-link active">
                    
                  <i class="fas fa-edit text-light"></i>                 
                  <p>Tambah/Edit  <i class="right fas fa-angle-double-left"></i>                
              </p>
                </a>
              
                <ul class="nav nav-treeview">
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-dot-circle nav-icon text-info"></i>
                      <p>Fatwa Teks</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-dot-circle nav-icon text-success"></i>
                      <p>Fatwa Gambar</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-dot-circle nav-icon text-primary"></i>
                      <p>Fatwa Video</p>
                    </a>
                  </li>
              </ul>
                            
          </li>      
          </ul>            
                 
                 
 <div class="dropdown-divider"></div>             
<a href="/logout" class="brand-link" onclick="return confirm('Yakin ingin keluar dari halaman dashboard?');"  style="background-color:#800517; color:white;">
      <img src="/dashboard/logout.png" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light"><b>Logout</b></span>
    </a>
               
              
      <!-- /.sidebar-menu -->
    
    <!-- /.sidebar -->

        </aside>
               
      
            
            
             