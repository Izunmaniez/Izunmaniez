<?= $this-> extend('fatwa/template/index'); ?>


<?= $this-> section('content'); ?>

<?= $this->include('fatwa/template/topbar');?>

<?= $this->include('fatwa/template/sidebar');?>

<div class="container">
    <div class="row">
        <div class="col">
        <p>
 <h4>Tips</h4>
Buat Aplikasi HHC tanpa download & install. Caranya, ﻿klik tanda titik tiga atau tanda panah di pojok paling kanan atas, lalu scroll kebawah cari bacaan Tambahkan ke layar utama lalu beri nama aplikasi ini HHC.  Beres! selanjut Anda tinggal klik icon tersebut setiap akan masuk ke website HHC tanpa mengetik lagi "https://www.hamdalahku.com"   
 <hr>
 <hr>
 <p>
 
<form action="" method="post">
 <?= csrf_field(); ?> 
 
 <?php foreach ($fatwaYmu as $ymu) : ?>
 
       
<h5><?=$ymu['judul']; ?></h5>
    
<?=$ymu['fatwaTextYmu']; ?>
<hr>
<hr>
<hr>

<?php endforeach; ?>   
       </form>       
        </div>
    </div>
</div>
    
<?= $this-> endSection(); ?>


 