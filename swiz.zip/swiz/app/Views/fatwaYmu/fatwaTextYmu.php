<?= $this-> extend('fatwa/template/index'); ?>


<?= $this-> section('content'); ?>


<div class="container">
    <div class="row">
        <div class="col">

<form action="" method="post">
 <?= csrf_field(); ?> 
 
 <?php foreach ($fatwaYmu as $ymu) : ?>
 
       
<h5><?=$ymu['judul']; ?></h5>
    
<?=$ymu['fatwaTextYmu']; ?>
<hr>
<hr>
<hr>

<?php endforeach; ?>   
       </form>       
        </div>
    </div>
</div>
    
<?= $this-> endSection(); ?>


 