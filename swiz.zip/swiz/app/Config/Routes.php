<?php namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php'))
{
	require SYSTEMPATH . 'Config/Routes.php';
}

/**
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

/**
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.


$routes->get('/', 'Pages::index');
//$routes->group('', ['filter' => 'login'], function($routes){
//$routes->get('home', 'Pages::home');
//}); 
$routes->get('/admin', 'Admin::index', ['filter' => 'role:owner, super_admin']);
$routes->get('/admin/index', 'Admin::index', ['filter' => 'role:owner, super_admin']);

$routes->get('/keuangan', 'Keuangan::index', ['filter' => 'role:admin_keuangan']);
$routes->get('/keuangan/index', 'Keuangan::index', ['filter' => 'role:admin_keuangan']);

$routes->get('/pertokoan', 'Pertokoan::index', ['filter' => 'role:admin_pertokoan']);
$routes->get('/pertokoan/index', 'Pertokoan::index', ['filter' => 'role:admin_pertokoan']);

$routes->get('/pengiriman', 'Pengiriman::index', ['filter' => 'role:admin_pengiriman']);
$routes->get('/pengiriman/index', 'Pengiriman::index', ['filter' => 'role:admin_pengiriman']);

$routes->get('/membership', 'Membership::index', ['filter' => 'role:admin_membership']);
$routes->get('/membership/index', 'Membership::index', ['filter' => 'role:admin_membership']);
$routes->get('/membership/member', 'Membership::member', ['filter' => 'role:admin_membership, admin_keuangan, admin_pertokoan, admin_pengiriman, admin_djos']);
$routes->get('/membership/(:num)', 'Membership::detail/$1', ['filter' => 'role:admin_membership, admin_keuangan, admin_pertokoan, admin_pengiriman, admin_djos']);

$routes->get('/djos', 'Djos::index', ['filter' => 'role:admin_djos']);
$routes->get('/djos/index', 'Djos::index', ['filter' => 'role:admin_djos']);
$routes->get('/djos/cashflow', 'Djos::cashflow', ['filter' => 'role:admin_djos']);
$routes->get('/djos/tambah_cashflow', 'Djos::tambah_cashflow', ['filter' => 'role:admin_djos']);
$routes->get('/djos/edit', 'Djos::edit', ['filter' => 'role:admin_djos']);
$routes->get('/djos/edit/(:num)', 'Djos::edit/$1', ['filter' => 'role:admin_djos']);
$routes->get('/djos/delete/(:num)', 'Djos::delete/$1', ['filter' => 'role:admin_djos']);

$routes->get('/djosdok/tambah_djosdok', 'Djosdok::tambah_djosdok', ['filter' => 'role:admin_djos']);
$routes->get('/djosdok/list_djosdok', 'Djosdok::list_djosdok', ['filter' => 'role:admin_djos']);
$routes->get('/djosdok/edit', 'Djosdok::edit', ['filter' => 'role:admin_djos']);
$routes->get('/djosdok/edit/(:num)', 'Djosdok::edit/$1', ['filter' => 'role:admin_djos']);
$routes->get('/djosdok/delete/(:num)', 'Djosdok::delete/$1', ['filter' => 'role:admin_djos']);

$routes->get('/watch/list_video', 'Watch::list_video', ['filter' => 'role:admin_membership']);
$routes->get('/watch/tambah_video', 'Watch::tambah_video', ['filter' => 'role:admin_membership']);
$routes->get('/watch/edit', 'Watch::edit', ['filter' => 'role:admin_membership']);

$routes->get('/info/list_info', 'Info::list_info', ['filter' => 'role:admin_membership']);
$routes->get('/info/info_editor', 'Info::info_editor', ['filter' => 'role:admin_membership']);
$routes->get('/info/edit', 'info::edit', ['filter' => 'role:admin_membership']);



/**
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php'))
{
	require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
