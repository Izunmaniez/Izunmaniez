<?php namespace App\Controllers;

use App\Models\DjosdokModel;

class Djosdok extends BaseController
{

protected $djosModel;
public function __construct()

{
$this->djosdokModel = new DjosdokModel();
}


public function index()
{

$djosdok = $this->djosdokModel->orderBy('id desc')->paginate(30, 'djosdok');

$currentPage = $this->request->getVar('page_djosdok') ? $this->request->getVar('page_djosdok') : 1;
    	    
$data = [
    'title'=>'Dokumentasi DJOS',
    'djosdok'=>$djosdok,
    'pager'=>$this->djosdokModel->pager,
    'currentPage'=>$currentPage       
    ];	 
          
    return view('djosdok/index',$data);}
    
    
public function list_djosdok()
{

$djosdok = $this->djosdokModel->orderBy('id desc')->paginate(30, 'djosdok');
	    
$data = [
    'title'=>'List Dokumentasi',
    'djosdok'=>$djosdok
    ];	   
     return view('djosdok/list_djosdok',$data);}
    
    
public function tambah_djosdok()
{

session();
	    
$data = [
    'title'=>'Form Tambah Dokumentasi DJOS',
    'validation'=> \Config\Services::validation()
    ];	   
     return view('djosdok/tambah_djosdok',$data);}


public function save()

{

if (!$this->validate ([

'foto'=>['rules'=>'max_size[foto,1024]|is_image[foto]|mime_in[foto,image/jpg,image/jpeg,image/png]',

  'errors'=> [
  'max_size'=>'Gambar terlalu besar (maks:1 MB)',
  'is_image'=>'Yang Anda pilih bukan gambar',
  'mime_in'=>'Yang Anda pilih bukan gambar'
   
  ]]]))  {
  
// $validation= \Config\Services :: validation();

//   return redirect()->to ('/djosdok/tambah_djosdok')->withInput()->with('validation', $validation);
   
   return redirect()->to ('/djosdok/tambah_djosdok')->withInput();
   
   }


// ambil gambar
$fileFoto = $this->request->getFile ('foto');

if ($fileFoto->getError() == 4)
{ $namaFoto ='default.png'; }

else {

//ambil nama file random
$namaFoto = $fileFoto->getRandomName();

// pindahkan gambar ke folder gbr-cashflow
$fileFoto->move('dok_djos', $namaFoto);
}


 $this->djosdokModel->save([
  
  'judul'=>$this->request->getVar('judul'),
  'kategori'=>$this->request->getVar('kategori'),
  'ket'=>$this->request->getVar('ket'),
  'foto'=>$namaFoto
  
  ]);
  
  session()->setFlashdata('pesan', 'Aye..!😆😀😎 Dokumentasi Berhasil Ditambahkan.');
  
  return redirect()->to('/djosdok/list_djosdok');
  
}


public function delete($id)

{

// cari foto
$djosdok = $this->djosdokModel->find($id);

// periksa jika foto bukan default
if ($djosdok ['foto'] != 'default.png') {

unlink('dok_djos/' .$djosdok['foto']);
}

$this->djosdokModel->delete($id);

session()->setFlashdata('pesan', 'Aye..!😆😀😎 Dokumentasi Berhasil Dihapus.');
  

return redirect()->to('/djosdok/list_djosdok');

}


public function edit($id)
{
 
 session();
    	   	    
$djosdok = $this->djosdokModel->find($id);
      	    
$data = [
    'title'=>'Edit Dokumentasi DJOS',
    'djosdok'=>$djosdok,
    'validation'=> \Config\Services::validation()
    ];	 
  
  return view('djosdok/edit',$data);}
          

public function update($id)
{

if (!$this->validate ([

'foto'=>['rules'=>'max_size[foto,1024]|is_image[foto]|mime_in[foto,image/jpg,image/jpeg,image/png]',

  'errors'=> [
  'max_size'=>'Gambar terlalu besar (maks:1 MB)',
  'is_image'=>'Yang Anda pilih bukan gambar',
  'mime_in'=>'Yang Anda pilih bukan gambar'
   
  ]]]))  {
  
// $validation= \Config\Services :: validation();

//   return redirect()->to ('/djosdok/tambah_djosdok')->withInput()->with('validation', $validation);
   
   return redirect()->to ('/djosdok/edit')->withInput();
   
   }

// ambil gambar
$fileFoto = $this->request->getFile ('foto');

if ($fileFoto->getError() == 4)
{ $namaFoto = $this->request->getVar('fotoLama'); }

else {

//ambil nama file random
$namaFoto = $fileFoto->getRandomName();

// pindahkan gambar ke folder gbr-cashflow
$fileFoto->move('dok_djos', $namaFoto);

// hapus file lama
unlink('dok_djos/' .$this->request->getVar('fotoLama'));

}


$this->djosdokModel->save([
  'id'=>$id,
  'judul'=>$this->request->getVar('judul'),
  'kategori'=>$this->request->getVar('kategori'),
  'ket'=>$this->request->getVar('ket'),
  'foto'=>$namaFoto
  ]);

  session()->setFlashdata('pesan', 'Aye..!😆😀😎 Dokumentasi Berhasil Diedit.');
  
  return redirect()->to('/djosdok/list_djosdok');
  
}
   
    
    
}