<?php namespace App\Controllers;

use App\Models\PengirimanModel;

class Pengiriman extends BaseController

{

public function index()
{	    
$data = [
    'title'=>'Admin Pengiriman'
    ];	
return view('pengiriman/index',$data);}



}