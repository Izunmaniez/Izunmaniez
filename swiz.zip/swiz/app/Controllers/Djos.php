<?php namespace App\Controllers;

use App\Models\DjosModel;

class Djos extends BaseController
{

protected $djosModel;
public function __construct()

{
$this->djosModel = new DjosModel();
}


public function index()
{

$djos = $this->djosModel->orderBy('id desc')->paginate(30, 'djos');

$currentPage = $this->request->getVar('page_djos') ? $this->request->getVar('page_djos') : 1;
    	    
$data = [
    'title'=>'Dashboard Admin DJOS',
    'djos'=>$djos,
    'pager'=>$this->djosModel->pager,
    'currentPage'=>$currentPage   
    
    ];	 
          
    return view('djos/index',$data);}
    

public function publish()
{

$djos = $this->djosModel->orderBy('id desc')->paginate(30, 'djos');

$currentPage = $this->request->getVar('page_djos') ? $this->request->getVar('page_djos') : 1;
    	    
$data = [
    'title'=>'Publikasi Cashflow DJOS',
    'djos'=>$djos,
    'pager'=>$this->djosModel->pager,
    'currentPage'=>$currentPage
    
    
    ];	 
          
    return view('djos/publish',$data);}
    
    
public function cashflow()
{
      	    
$djos = $this->djosModel->orderBy('id desc')->paginate(5, 'djos');

$currentPage = $this->request->getVar('page_cashflow') ? $this->request->getVar('page_djos') : 1;
     	    
$data = [
    'title'=>'Cash Flow DJOS',
    'djos'=>$djos,
    'pager'=>$this->djosModel->pager,
    'currentPage'=>$currentPage
    ];	 
          
    return view('djos/cashflow',$data);}
    

public function tambah_cashflow()
{
	    
$data = [
    'title'=>'Form Tambah Data Cash Flow DJOS'];	   
     return view('djos/tambah_cashflow',$data);}


public function save()

{

//if (!$this->validate ([

//'dokumentasi' => [
// 'rules'=>'max_size[dokumentasi,1024]|is_image[dokumentasi]|mime_in[dokumentasi,image/jpg,image/jpeg,image/png]',

//  'errors'=> [
//  'max_size'=>'Gambar terlalu besar (maks:1 MB)',
//  'is_image'=>'Yang Anda pilih bukan gambar',
//  'mime_in'=>'Yang Anda pilih bukan gambar'
   
//  ]]]))   {
//$validation= \Config\Services :: validation();

// return redirect()->to ('djos/tambah_cashflow')->withInput();}


// ambil gambar
// $fileDokumentasi = $this->request->getFile ('dokumentasi');

// pindahkan gambar ke folder gbr-cashflow
// $fileDokumentasi->move('gbr_cashflow');

//ambil nama
// $namaDokumentasi = $fileDokumentasi->getName();


 $this->djosModel->save([
  
  'tanggal'=>$this->request->getVar('tanggal'),

  'masuk'=>$this->request->getVar('masuk'),
  'donatur'=>$this->request->getVar('donatur'),
  'keluar'=>$this->request->getVar('keluar'),
  'volunteer'=>$this->request->getVar('volunteer'),
  'keterangan'=>$this->request->getVar('keterangan'),
//  'dokumentasi'=>$namaDokumentasi

  ]);
  
  session()->setFlashdata('pesan', 'Aye..!😆😀😎 Data Berhasil Ditambahkan.');
  
  return redirect()->to('/djos/cashflow');
  
}


public function delete($id)

{
$this->djosModel->delete($id);

session()->setFlashdata('pesan', 'Aye..!😆😀😎 Data Berhasil Dihapus.');
  

return redirect()->to('/djos/cashflow');

}


public function edit($id)
{
    	   	    
$djos = $this->djosModel->find($id);
      	    
$data = [
    'title'=>'Edit Data Cashflow DJOS',
    'djos'=>$djos
    ];	 
  
  return view('djos/edit',$data);}
          

public function update($id)
{

$this->djosModel->save([
  'id'=>$id,
  
  'tanggal'=>$this->request->getVar('tanggal'),
  
  'masuk'=>$this->request->getVar('masuk'),
  'donatur'=>$this->request->getVar('donatur'),
  'keluar'=>$this->request->getVar('keluar'),
  'volunteer'=>$this->request->getVar('volunteer'),
  'keterangan'=>$this->request->getVar('keterangan'),
// 'dokumentasi'=>$this->request->getVar('dokumentasi')

  ]);

  session()->setFlashdata('pesan', 'Aye..!😆😀😎 Data Berhasil Diedit.');
  
  return redirect()->to('/djos/cashflow');
  
}





}
	    
