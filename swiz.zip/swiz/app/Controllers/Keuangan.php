<?php namespace App\Controllers;

use App\Models\KeuanganModel;

class Keuangan extends BaseController

{

public function index()
{	    
$data = [
    'title'=>'Admin Keuangan'
    ];	
return view('keuangan/index',$data);}



}