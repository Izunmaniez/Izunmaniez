<?php namespace App\Controllers;

use App\Models\PenjualanModel;

class Penjualan extends BaseController

{

public function index()
{	    
$data = [
    'title'=>'Admin Penjualan'
    ];	
return view('penjualan/index',$data);}



}