<?php namespace App\Controllers;

use App\Models\InfoModel;

class Info extends BaseController
{

protected $infoModel;
public function __construct()

{
$this->infoModel = new InfoModel();
}

public function index()
{

$info = $this->infoModel->orderBy('id desc')->paginate(30, 'info');

$data = [
    'title'=>'Info / Promo',
    'info'=>$info
    ];	 
          
    return view('info/index',$data);}
    
    
public function list_info()
{

$info = $this->infoModel->orderBy('id desc')->paginate(30, 'info');
	    
$data = [
    'title'=>'List Info',
    'info'=>$info
    ];	   
     return view('info/list_info',$data);}
     

public function info_editor()
{

$info = $this->infoModel->orderBy('id desc')->paginate(30, 'info');
	    
$data = [
    'title'=>'Info Editor',
    'info'=>$info
    ];	   
     return view('info/info_editor',$data);}


public function save()

{

//if (!$this->validate ([

//'dokumentasi' => [
// 'rules'=>'max_size[dokumentasi,1024]|is_image[dokumentasi]|mime_in[dokumentasi,image/jpg,image/jpeg,image/png]',

//  'errors'=> [
//  'max_size'=>'Gambar terlalu besar (maks:1 MB)',
//  'is_image'=>'Yang Anda pilih bukan gambar',
//  'mime_in'=>'Yang Anda pilih bukan gambar'
   
//  ]]]))   {
//$validation= \Config\Services :: validation();

// return redirect()->to ('djos/tambah_cashflow')->withInput();}


// ambil gambar
// $fileDokumentasi = $this->request->getFile ('dokumentasi');

// pindahkan gambar ke folder gbr-cashflow
// $fileDokumentasi->move('gbr_cashflow');

//ambil nama
// $namaDokumentasi = $fileDokumentasi->getName();


 $this->infoModel->save([
  
  'judul'=>$this->request->getVar('judul'),

  'isi_info'=>$this->request->getVar('isi_info')
   ]);
  
  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Info Berhasil Ditambahkan.');
  
  return redirect()->to('/info/list_info');
  
}


public function delete($id)

{
$this->infoModel->delete($id);

session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Info Berhasil Dihapus.');
  

return redirect()->to('/info/list_info');

}


public function edit($id)
{
    	   	    
$info = $this->infoModel->find($id);
      	    
$data = [
    'title'=>'Edit Info / Promo',
    'info'=>$info
    ];	 
  
  return view('info/edit',$data);}
          

public function update($id)
{

$this->infoModel->save([
  'id'=>$id,
  
  'judul'=>$this->request->getVar('judul'),
  
  'isi_info'=>$this->request->getVar('isi_info'),
  ]);

  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Info Berhasil Diedit.');
  
  return redirect()->to('/info/list_info');
  
}




}
	    
