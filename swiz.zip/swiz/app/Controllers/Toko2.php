<?php namespace App\Controllers;

use App\Models\UsersModel;
use App\Models\TokoModel;

class Toko extends BaseController

{

protected $db, $builder, $usersModel;

public function __construct()
{
$this->usersModel = new UsersModel();
$this->db      = \Config\Database::connect();
$this->builder = $this->db->table('users');   
}


public function index($id=0)
{	    
$data ['title'] = 'My Toko';
    
//    $users= new\Myth\Auth\Models\UserModel();
//    $data['users']= $users->findAll();

$this->builder->select('users.id as userid, username, email);
$this->builder->join('toko', 'toko.id = users.id');
$this->builder->where('users.id', $id);
$query = $this->builder->get();

$data['users'] = $query->getResult();
   	
    return view('toko/index',$data);
}


public function detail($id=0)
{	    
$data ['title'] = 'Detail';

$this->builder->select('users.id as userid, username, email, fullname, foto, created_at, telp, peringkat, jenkel, inviter, nama_toko, alamat, propinsi, kabupaten, kecamatan, deskel, negara, agama, mabank, norek, an');
$this->builder->join('auth_groups_users', 'auth_groups_users.user_id = users.id');
$this->builder->join('auth_groups', 'auth_groups.id = auth_groups_users.group_id');
$this->builder->where('users.id', $id);
$query = $this->builder->get();

$data['user'] = $query->getRow();

if (empty ($data['user'])) {
    return redirect()->to('/membership/member');
}
  	
    return view('membership/detail',$data);
}


}