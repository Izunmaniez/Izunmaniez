<?php namespace App\Controllers;

use App\Models\UsersModel;

class Pertokoan extends BaseController

{

public function index()
{	    
$data = [
    'title'=>'Admin Pertokoan'
    ];	
return view('pertokoan/index',$data);}



}