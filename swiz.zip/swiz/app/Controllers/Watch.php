<?php namespace App\Controllers;

use App\Models\WatchModel;

class Watch extends BaseController
{

protected $wacthModel;
public function __construct()

{
$this->watchModel = new WatchModel();
}

public function index()
{

$watch = $this->watchModel->orderBy('id desc')->paginate(30, 'watch');

$data = [
    'title'=>'Hamdalah Watch',
    'watch'=>$watch
    ];	 
          
    return view('watch/index',$data);}
  
  
  public function list_video()
{

$watch = $this->watchModel->orderBy('id desc')->paginate(30, 'watch');
	    
$data = [
    'title'=>'List Video',
    'watch'=>$watch
    ];	   
     return view('watch/list_video',$data);}
     

public function tambah_video()
{

$watch = $this->watchModel->orderBy('id desc')->paginate(30, 'watch');
	    
$data = [
    'title'=>'Watch Editor',
    'watch'=>$watch
    ];	   
     return view('watch/tambah_video',$data);}


public function save()

{

 $this->watchModel->save([
 
  'tanggal'=>$this->request->getVar('tanggal'),
  'judul'=>$this->request->getVar('judul'),
  'link_video'=>$this->request->getVar('link_video')
  
   ]);
  
  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Info Berhasil Ditambahkan.');
  
  return redirect()->to('/watch/list_video');
  
}


public function delete($id)

{
$this->watchModel->delete($id);

session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Video Berhasil Dihapus.');
  

return redirect()->to('/watch/list_video');

}


public function edit($id)
{
    	   	    
$watch = $this->watchModel->find($id);
      	    
$data = [
    'title'=>'Edit Video',
    'watch'=>$watch
    ];	 
  
  return view('watch/edit',$data);}
          

public function update($id)
{

$this->watchModel->save([
  'id'=>$id,
  
  'tanggal'=>$this->request->getVar('tanggal'),
  'judul'=>$this->request->getVar('judul'),  
  'link_video'=>$this->request->getVar('link_video')
  ]);

  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Video Berhasil Diedit.');
  
  return redirect()->to('/watch/list_video');
  
}


}

  
    

	