<?php

namespace App\Controllers;

use App\Models\ObjectModel;

class Objects extends BaseController
{
    protected $objectModel;

    public function __construct()
    {
        $this->objectModel = new ObjectModel();
        helper('form');    
    }

    public function index()
    {
        $data = [
            'title' => 'CRUD Object Model',
            'all_data' => $this->objectModel->findAll()
        ];

        return view('objects/index', $data);
    }

    public function add_data()
    {
        $data['title'] = 'Add Data';
        if ($this->request->getPost()) {
            $rules = [
                'username' => 'required|alpha_space',
                'jenkel' => 'required',
                'telp' => 'required',
                'foto' => 'uploaded[foto]|max_size[foto,2048]|is_image[foto]|mime_in[foto,image/jpg,image/jpeg,image/png]'
            ];

            if ($this->validate($rules)) {
                $foto = $this->request->getFile('foto');
                $fotoName = $foto->getRandomName();
                $foto->move('photos', $fotoName);

                $inserted = [
                    'username' => $this->request->getPost('username'),
                    'jenkel' => $this->request->getPost('jenkel'),
                    'telp' => $this->request->getPost('telp'),
                    'foto' => $fotoName
                ];

                $this->objectModel->insert($inserted);
                session()->setFlashData('success', 'data has been added to database');
                return redirect()->to('/objects');
            } else {
                session()->setFlashData('failed', \Config\Services::validation()->getErrors());
                return redirect()->back()->withInput();
            }
        }
        return view('objects/form_add', $data);
    }

    public function delete_data($id)
    {
        $fotoId = $this->objectModel->find($id);
        unlink('photos/'.$fotoId['foto']);

        $this->objectModel->delete($id);
        session()->setFlashData('success', 'data has been deleted from database.');
        return redirect()->to('/objects');
    }

    public function update_data($id)
    {
        $data = [
            'title' => 'Update Data',
            'dataById' => $this->objectModel->where('id', $id)->first()
        ];

        if ($this->request->getPost()) {
            $rules = [
                'username' => 'required|alpha_space',
                'jenkel' => 'required',
                'telp' => 'required',
                'foto' => 'max_size[foto,2048]|is_image[foto]|mime_in[foto,image/jpg,image/jpeg,image/png]'
            ];

            if ($this->validate($rules)) {
                $foto = $this->request->getFile('foto');
                if ($foto->getError() == 4) {
                    $fotoName = $this->request->getPost('Oldfoto');
                } else {
                    $fotoName = $foto->getRandomName();
                    $foto->move('photos', $fotoName);
                    $foto = $this->objectModel->find($id);
                    if ($foto['foto'] == $foto['foto']) {
                        unlink('photos/' . $this->request->getPost('Oldfoto'));
                    }
                }

                $inserted = [
                    'username' => $this->request->getPost('username'),
                    'jenkel' => $this->request->getPost('jenkel'),
                    'telp' => $this->request->getPost('telp'),
                    'foto' => $fotoName
                ];

                $this->objectModel->update($id, $inserted);
                session()->setFlashData('success', 'data has been updated from database');
                return redirect()->to('/objects');
            } else {
                session()->setFlashData('failed', \Config\Services::validation()->getErrors());
                return redirect()->back()->withInput();
            }
        }
        return view('objects/form_update', $data); 
    }
}