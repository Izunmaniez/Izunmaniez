<?php namespace App\Controllers;

class Pages extends BaseController
{

// pages1 --------------------

public function index()
{	    
$data = [
    'title'=>'Home'];	   
		return view('pages/home',$data);}


public function mars()
{	    
$data = [
    'title'=>'Mars'];	
return view('pages/mars',$data);}


public function djos()
{	    
$data = [
    'title'=>'H.DJOS'];	
return view('pages/djos',$data);}

public function cashflow_djos()
{	    
$data = [
    'title'=>' Cashflow H.DJOS'];	
return view('pages/djos/cashflow_djos',$data);}


public function charger()
{	    
$data = [
    'title'=>'H.CHARGER'];	
return view('pages/charger',$data);}

public function watch()
{	    
$data = [
    'title'=>'H.WATCH'];	
return view('pages/watch',$data);}

public function info_promo()
{	    
$data = [
    'title'=>'Info & Promo'
    ];	
return view('pages/info_promo',$data);}


public function faq()
{	    
$data = [
    'title'=>'FAQ'
    ];	
return view('pages/faq',$data);}


public function skb()
{	    
$data = [
    'title'=>'S&K'
    ];	
return view('pages/skb',$data);}




}


