<?php namespace App\Controllers;

use App\Models\FatwaYmuModel;

class FatwaYmu extends BaseController
{

protected $fatwaYmuModel;
public function __construct()

{
$this->fatwaYmuModel = new FatwaYmuModel();
}


public function text/index()
{


$data = [
    'title'=>'Fatwa YMU'    
    ];	 
          
    return view('fatwaYmu/text/index',$data);}
    

public function fatwaTextYmu()
{

$fatwaYmu = $this->fatwaYmuModel->orderBy('id desc')->paginate(30, 'fatwaYmu');

$currentPage = $this->request->getVar('page_fatwaYmu') ? $this->request->getVar('page_fatwaYmu') : 1;
    	    
$data = [
    'title'=>'Fatwa YMU',
    'fatwaYmu'=>$fatwaYmu,
    'pager'=>$this->fatwaYmuModel->pager,
    'currentPage'=>$currentPage
    
    
    ];	 
          
    return view('fatwa/fatwaTextYmu',$data);}
       

public function fatwaTextEditor()
{
	    
$data = [
    'title'=>'Form Tambah Fatwa YMU Text'];	   
     return view('fatwa/fatwaTextEditor',$data);}


public function save()

{

//if (!$this->validate ([

//'dokumentasi' => [
// 'rules'=>'max_size[dokumentasi,1024]|is_image[dokumentasi]|mime_in[dokumentasi,image/jpg,image/jpeg,image/png]',

//  'errors'=> [
//  'max_size'=>'Gambar terlalu besar (maks:1 MB)',
//  'is_image'=>'Yang Anda pilih bukan gambar',
//  'mime_in'=>'Yang Anda pilih bukan gambar'
   
//  ]]]))   {
//$validation= \Config\Services :: validation();

// return redirect()->to ('djos/tambah_cashflow')->withInput();}


// ambil gambar
// $fileDokumentasi = $this->request->getFile ('dokumentasi');

// pindahkan gambar ke folder gbr-cashflow
// $fileDokumentasi->move('gbr_cashflow');

//ambil nama
// $namaDokumentasi = $fileDokumentasi->getName();


 $this->fatwaYmuModel->save([
  
  'judul'=>$this->request->getVar('judul'),
  'fatwaTextYmu'=>$this->request->getVar('fatwaTextYmu'),
  'fatwaGbrYmu'=>$this->request->getVar('fatwaGbrYmu'),
  'fatwaVideoYmu'=>$this->request->getVar('fatwaVideoYmu')

//  'dokumentasi'=>$namaDokumentasi

  ]);
  
  session()->setFlashdata('pesan', 'Aye..!😆😀😎 Data Berhasil Ditambahkan.');
  
  return redirect()->to('/fatwa/fatwaYmu');
  
}


public function delete($id)

{
$this->djosModel->delete($id);

session()->setFlashdata('pesan', 'Aye..!😆😀😎 Data Berhasil Dihapus.');
  

return redirect()->to('/djos/cashflow');

}


public function edit($id)
{
    	   	    
$djos = $this->djosModel->find($id);
      	    
$data = [
    'title'=>'Edit Data Cashflow DJOS',
    'djos'=>$djos
    ];	 
  
  return view('djos/edit',$data);}
          

public function update($id)
{

$this->djosModel->save([
  'id'=>$id,
  
  'tanggal'=>$this->request->getVar('tanggal'),
  
  'masuk'=>$this->request->getVar('masuk'),
  'donatur'=>$this->request->getVar('donatur'),
  'keluar'=>$this->request->getVar('keluar'),
  'volunteer'=>$this->request->getVar('volunteer'),
  'keterangan'=>$this->request->getVar('keterangan'),
// 'dokumentasi'=>$this->request->getVar('dokumentasi')

  ]);

  session()->setFlashdata('pesan', 'Aye..!😆😀😎 Data Berhasil Diedit.');
  
  return redirect()->to('/djos/cashflow');}

 }