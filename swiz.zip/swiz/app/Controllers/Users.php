<?php namespace App\Controllers;

use App\Models\UsersModel;

class Users extends BaseController
{

protected $usersModel;

public function __construct()

{
$this->usersModel = new UsersModel();
}


public function index()
{
     	    
$data = [
    'title'=>'My Dashboard'    
    ];	 
          
    return view('users/index',$data);}
    
 
 public function tambah_user()
{
    	   	    
session();
    	   	    
$users = $this->usersModel->find($id);
      	    
$data = [
    'title'=>'Tambah User',
    'users'=>$users,
    'validation'=> \Config\Services::validation()
    ];	 
   	
    return view('users/tambah_user',$data);
}


public function save()
   
{

if (!$this->validate ([

'foto'=>['rules'=>'max_size[foto,1024]|is_image[foto]|mime_in[foto,image/jpg,image/jpeg,image/png]',

  'errors'=> [
  'max_size'=>'Gambar terlalu besar (maks:1 MB)',
  'is_image'=>'Yang Anda pilih bukan gambar',
  'mime_in'=>'Yang Anda pilih bukan gambar'
   
  ]]]))  {
  
return redirect()->to ('/users')->withInput();
}


// ambil gambar
$fileFoto = $this->request->getFile ('foto');

if ($fileFoto->getError() == 4)
{ $namaFoto ='default_profile.png'; }

else {

//ambil nama file random
$namaFoto = $fileFoto->getRandomName();

// pindahkan gambar ke folder gbr-cashflow
$fileFoto->move('foto_profile', $namaFoto);

}


$this->usersModel->save([
  'id'=>$id,
  
  'telp'=>$this->request->getVar('telp'),  
  'fullname'=>$this->request->getVar('fullname'),
  'email'=>$this->request->getVar('email'),
   'inviter'=>$this->request->getVar('inviter'),
  'jenkel'=>$this->request->getVar('jenkel'),
  'tgl_join'=>$this->request->getVar('tgl_join'),
  'templah'=>$this->request->getVar('templah'),
  'tanglah'=>$this->request->getVar('tanglah'),
  'alamat'=>$this->request->getVar('alamat'),
  'deskel'=>$this->request->getVar('deskel'),
  'kecamatan'=>$this->request->getVar('kecamatan'),
  'kabupaten'=>$this->request->getVar('kabupaten'),
  'propinsi'=>$this->request->getVar('propinsi'),
  'negara'=>$this->request->getVar('negara'),
  'agama'=>$this->request->getVar('agama'), 
  'norek'=>$this->request->getVar('norek'),
  'mabank'=>$this->request->getVar('mabank'),
  'an'=>$this->request->getVar('an'),
  'nama_toko'=>$this->request->getVar('nama_toko'),
  'foto'=>$namaFoto
  
  ]);

  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Profil Anda Berhasil Diubah.');
  
  return redirect()->to('/users');
  
}
   
    
public function delete($id)

{

// cari foto
$users = $this->usersModel->find($id);

// periksa jika foto bukan default
if ($users ['foto'] != 'default_profile.png') {

unlink('foto_profile/' .$users['foto']);
}

$this->usersModel->delete($id);

session()->setFlashdata('pesan', 'Aye..!😆😀😎 Berhasil Dihapus.');
  
return redirect()->to('/users');

} 

    
public function edit($id)
{
    	   	    
session();
    	   	    
$users = $this->usersModel->find($id);
      	    
$data = [
    'title'=>'Edit My Profile',
    'users'=>$users,
    'validation'=> \Config\Services::validation()
    ];	 
   	
    return view('users/edit',$data);
}


public function update($id)
   
{

if (!$this->validate ([

'foto'=>['rules'=>'max_size[foto,1024]|is_image[foto]|mime_in[foto,image/jpg,image/jpeg,image/png]',

  'errors'=> [
  'max_size'=>'Gambar terlalu besar (maks:1 MB)',
  'is_image'=>'Yang Anda pilih bukan gambar',
  'mime_in'=>'Yang Anda pilih bukan gambar'
   
  ]]]))  {
  
return redirect()->to ('/users/edit')->withInput();
}


// ambil gambar
$fileFoto = $this->request->getFile ('foto');

if ($fileFoto->getError() == 4)
{ $namaFoto = $this->request->getVar('fotoLama'); }

else {

//ambil nama file random
$namaFoto = $fileFoto->getRandomName();

// pindahkan gambar ke folder gbr-cashflow
$fileFoto->move('foto_profile', $namaFoto);

// hapus file lama
unlink('foto_profile/' .$this->request->getVar('fotoLama'));

}


$this->usersModel->save([
  'id'=>$id,
  
  'telp'=>$this->request->getVar('telp'),  
  'fullname'=>$this->request->getVar('fullname'),
  'email'=>$this->request->getVar('email'),
   'inviter'=>$this->request->getVar('inviter'),
  'jenkel'=>$this->request->getVar('jenkel'),
  'tgl_join'=>$this->request->getVar('tgl_join'),
  'templah'=>$this->request->getVar('templah'),
  'tanglah'=>$this->request->getVar('tanglah'),
  'alamat'=>$this->request->getVar('alamat'),
  'deskel'=>$this->request->getVar('deskel'),
  'kecamatan'=>$this->request->getVar('kecamatan'),
  'kabupaten'=>$this->request->getVar('kabupaten'),
  'propinsi'=>$this->request->getVar('propinsi'),
  'negara'=>$this->request->getVar('negara'),
  'agama'=>$this->request->getVar('agama'), 
  'norek'=>$this->request->getVar('norek'),
  'mabank'=>$this->request->getVar('mabank'),
  'an'=>$this->request->getVar('an'),
  'nama_toko'=>$this->request->getVar('nama_toko'),
  'foto'=>$namaFoto
  
  ]);

  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Profil Anda Berhasil Diubah.');
  
  return redirect()->to('/users');
  
}
   
 
 public function grup()
{
      	    
$data = [
    'title'=>'My Groups'   
    ];	 
          
    return view('users/grup',$data);}
    
 
 
    
}
	    


