<?php namespace App\Controllers;

use App\Models\UsersModel;

class Membership extends BaseController

{

protected $db, $builder, $usersModel;

public function __construct()
{
$this->usersModel = new UsersModel();
$this->db      = \Config\Database::connect();
$this->builder = $this->db->table('users');   
}

public function index()
{	    
$data = [
    'title'=>'Membership'
    ];	
return view('membership/index',$data);}


public function member()
{

$data ['title'] = 'Data Member';

$this->builder->select('users.id as userid, fullname, telp, peringkat, inviter, foto, created_at, alamat');

$query = $this->builder->get();

$data['users'] = $query->getResult();
   	
    return view('membership/member',$data);
}

public function all_member()
{	    
$data ['title'] = 'All Member';
    
//    $users= new\Myth\Auth\Models\UserModel();
//    $data['users']= $users->findAll();

$this->builder->select('users.id as userid, username, email, name');
$this->builder->join('auth_groups_users', 'auth_groups_users.user_id = users.id');
$this->builder->join('auth_groups', 'auth_groups.id = auth_groups_users.group_id');
$query = $this->builder->get();

$data['users'] = $query->getResult();
   	
    return view('membership/all_member',$data);
}

public function detail($id=0)
{	    
$data ['title'] = 'Detail';

$this->builder->select('users.id as userid, username, email, fullname, foto, created_at, telp, peringkat, jenkel, inviter, nama_toko, alamat, propinsi, kabupaten, kecamatan, deskel, negara, agama, mabank, norek, an');
$this->builder->join('auth_groups_users', 'auth_groups_users.user_id = users.id');
$this->builder->join('auth_groups', 'auth_groups.id = auth_groups_users.group_id');
$this->builder->where('users.id', $id);
$query = $this->builder->get();

$data['user'] = $query->getRow();

if (empty ($data['user'])) {
    return redirect()->to('/membership/member');
}
  	
    return view('membership/detail',$data);
}


}