<?php namespace App\Controllers;

use App\Models\AdminModel;
use App\Models\UsersModel;

class Admin extends BaseController

{

public function index()
{	
    $data = ['title'=>'Admin'];	
    return view('admin/index',$data);}


public function admin_profile()
{
      	    
$data = [
    'title'=>'My Profile'
    
    ];	
return view('admin/admin_profile',$data);}



public function edit($id)
{
    	   	    
$users = $this->adminModel->find($id);
      	    
$data = [
    'title'=>'Edit My Profile',
    'users'=>$users
    ];	 
   	
    return view('admin/edit',$data);
}


public function update($id)
   
{
if (!$this->validate ([

'foto' => [
'rules'=>'max_size[foto,1024]|is_image[foto]|mime_in[foto,image/jpg,image/jpeg,image/png]',

'errors'=> [
'max_size'=>'Gambar terlalu besar (maks:1 MB)',
'is_image'=>'Yang Anda pilih bukan gambar',
'mime_in'=>'Yang Anda pilih bukan gambar']
  ]]))   {
$validation= \Config\Services :: validation();

return redirect()->to ('/admin/edit')->withInput();
}


// ambil gambar
$fileFoto = $this->request->getFile ('foto');

if ($fileFoto->getError() == 4)
{ $namaFoto ='default_profile.png'; }

//ambil nama file random
$namaFoto = $fileFoto->getRandomName();

// pindahkan gambar ke folder gbr-cashflow
$fileFoto->move('foto_profile', $namaFoto);


$this->usersModel->save([
  'id'=>$id,
  
  'telp'=>$this->request->getVar('telp'),  
  'fullname'=>$this->request->getVar('fullname'),
  'email'=>$this->request->getVar('email'),
  'norek'=>$this->request->getVar('norek'),
  'mabank'=>$this->request->getVar('mabank'),
  'an'=>$this->request->getVar('an'),
  'foto'=>$namaFoto
  
  ]);

  session()->setFlashdata('pesan', 'Aye..!ðŸ˜†ðŸ˜€ðŸ˜Ž Profil Anda Berhasil Diubah.');
  
  return redirect()->to('/users/detail_profile');
  
}


}